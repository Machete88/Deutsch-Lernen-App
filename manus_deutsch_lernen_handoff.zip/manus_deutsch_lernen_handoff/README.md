# DEUTSCH LERNEN - Manus Handoff Package

Dieses Paket ist für den Upload in Manus.ai vorbereitet.

## Inhalt
- `source_snapshot/deutsch_lernen/` - aktueller Quellstand als technische Basis
- `docs/PRODUCT_REQUIREMENTS.md` - Produktziel, Nutzergruppen, MVP und Ausbau
- `docs/FEATURE_STATUS.md` - was schon vorhanden ist und was Manus fertigbauen soll
- `docs/SCREEN_SPECS.md` - genaue Screens, Flows und UI-Verhalten
- `docs/ARCHITECTURE.md` - empfohlene Zielarchitektur
- `docs/DATA_MODELS.md` - Domänenmodelle und Persistenzregeln
- `docs/API_SPEC.md` - Backend- und KI-Endpunkte
- `docs/DESIGN_SYSTEM.md` - UI- und UX-Regeln
- `docs/BUILD_PLAN.md` - Reihenfolge für die Umsetzung
- `docs/ACCEPTANCE_CRITERIA.md` - Definition of Done
- `docs/MANUS_PROMPT.md` - direkt nutzbarer Prompt für Manus
- `docs/KNOWN_GAPS.md` - offene Punkte, die noch nicht echt implementiert sind

## Ziel
Manus soll auf Basis dieses Pakets die App produktionsnäher fertigstellen, fehlende technische Integrationen ergänzen und die UI/UX vereinheitlichen.

## Erwartung an Manus
1. Bestehenden Code analysieren und weiterverwenden, wo sinnvoll.
2. Fehlende echte Integrationen bauen.
3. Inkonsistente UI bereinigen.
4. Die App kompilierbar und testbar machen.
5. Eine saubere Abschlussversion mit Android-Fokus liefern.
