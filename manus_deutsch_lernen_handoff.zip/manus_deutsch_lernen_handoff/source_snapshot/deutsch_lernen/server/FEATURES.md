# Backend-Vorbereitung

Diese Datei dokumentiert die vorbereiteten Endpunkte für spätere echte Backend-Integration.

## Aktuell vorhanden
- `learning.dailyRecommendations`
- `learning.grammarCatalog`
- `sync.pushSnapshot`

## Geplanter Ausbau
- echte Authentifizierung mit Session-/Token-Handling
- persistente Nutzerprofile
- Sync-Konfliktlösung
- serverseitige KI-Antworten
- Lernfortschritt und Problemwort-Analysen
