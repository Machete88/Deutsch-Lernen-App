import { COOKIE_NAME } from "../shared/const.js";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  learning: router({
    dailyRecommendations: publicProcedure.query(() => ({
      items: [
        { focus: 'Review', action: '10 Wiederholungen heute' },
        { focus: 'Grammatik', action: '1 Lektion zu Artikeln' },
        { focus: 'Satzbau', action: '3 kurze Satzbau-Aufgaben' },
      ],
      generatedAt: Date.now(),
    })),
    grammarCatalog: publicProcedure.query(() => ({
      levels: ['A1', 'A2', 'B1'],
      modules: ['Artikel', 'Verbposition', 'Akkusativ'],
    })),
  }),

  sync: router({
    pushSnapshot: publicProcedure.mutation(({ input }) => ({
      success: true,
      acceptedAt: Date.now(),
      snapshot: input ?? null,
    })),
  }),

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // TODO: add feature routers here, e.g.
  // todo: router({
  //   list: protectedProcedure.query(({ ctx }) =>
  //     db.getUserTodos(ctx.user.id)
  //   ),
  // }),
});

export type AppRouter = typeof appRouter;
