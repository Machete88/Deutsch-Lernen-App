import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface LearningPath {
  id: string;
  name: string;
  description: string;
  difficulty: 'easy' | 'medium' | 'hard';
  topics: string[];
  progress: number;
  estimatedTime: number;
  recommended: boolean;
}

interface AdaptiveRecommendation {
  type: 'vocabulary' | 'grammar' | 'practice' | 'review';
  content: string;
  reason: string;
  priority: 'high' | 'medium' | 'low';
}

interface AdaptiveLearningContextType {
  learningPaths: LearningPath[];
  recommendations: AdaptiveRecommendation[];
  currentDifficulty: 'easy' | 'medium' | 'hard';
  generateLearningPath: (userLevel: string) => Promise<void>;
  getRecommendations: (stats: any) => Promise<AdaptiveRecommendation[]>;
  adjustDifficulty: (performance: number) => Promise<void>;
  updateLearningPath: (pathId: string, progress: number) => Promise<void>;
  getAdaptiveContent: () => LearningPath[];
  isLoading: boolean;
  error: string | null;
  clearError: () => void;
}

const AdaptiveLearningContext = createContext<AdaptiveLearningContextType | undefined>(undefined);

function buildPaths(userLevel: string): LearningPath[] {
  if (userLevel === 'beginner') {
    return [
      { id: 'path_a1_alltag', name: 'A1 Alltag', description: 'Begrüßung, Termine, Einkaufen, Familie', difficulty: 'easy', topics: ['Grüße', 'Einkaufen', 'Familie', 'Termine'], progress: 0, estimatedTime: 90, recommended: true },
      { id: 'path_a1_grammatik', name: 'A1 Grammatik-Basis', description: 'Artikel, Plural, Verbposition', difficulty: 'easy', topics: ['Artikel', 'Plural', 'Verbposition'], progress: 0, estimatedTime: 75, recommended: true },
    ];
  }
  if (userLevel === 'intermediate') {
    return [
      { id: 'path_a2_job', name: 'A2 Beruf & Alltag', description: 'Arbeit, Wohnen, Arzt, Behörden', difficulty: 'medium', topics: ['Arbeit', 'Wohnen', 'Arzt', 'Behörden'], progress: 0, estimatedTime: 140, recommended: true },
      { id: 'path_a2_grammatik', name: 'A2 Satzbau & Zeiten', description: 'Perfekt, Präpositionen, Satzklammer', difficulty: 'medium', topics: ['Perfekt', 'Präpositionen', 'Satzbau'], progress: 0, estimatedTime: 110, recommended: true },
    ];
  }
  return [
    { id: 'path_b1_pruefung', name: 'B1 Prüfungstraining', description: 'Lesen, Hören, Sprechen und Argumentieren', difficulty: 'hard', topics: ['Lesen', 'Hören', 'Sprechen', 'Argumentieren'], progress: 0, estimatedTime: 180, recommended: true },
    { id: 'path_b1_grammatik', name: 'B1 Grammatik-Fokus', description: 'Nebensätze, Passiv, Konjunktiv-Basis', difficulty: 'hard', topics: ['Nebensätze', 'Passiv', 'Konjunktiv'], progress: 0, estimatedTime: 150, recommended: false },
  ];
}

export function AdaptiveLearningProvider({ children }: { children: ReactNode }) {
  const [learningPaths, setLearningPaths] = useState<LearningPath[]>([]);
  const [recommendations, setRecommendations] = useState<AdaptiveRecommendation[]>([]);
  const [currentDifficulty, setCurrentDifficulty] = useState<'easy' | 'medium' | 'hard'>('easy');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadAdaptiveData = async () => {
      try {
        const stored = await AsyncStorage.getItem('learning_paths');
        if (stored) setLearningPaths(JSON.parse(stored));
        const difficulty = await AsyncStorage.getItem('current_difficulty');
        if (difficulty) setCurrentDifficulty(difficulty as 'easy' | 'medium' | 'hard');
      } catch (err) {
        console.error('Error loading adaptive data:', err);
      } finally {
        setIsLoading(false);
      }
    };
    loadAdaptiveData();
  }, []);

  const generateLearningPath = async (userLevel: string) => {
    const paths = buildPaths(userLevel);
    setLearningPaths(paths);
    await AsyncStorage.setItem('learning_paths', JSON.stringify(paths));
  };

  const getRecommendations = async (stats: any): Promise<AdaptiveRecommendation[]> => {
    const recs: AdaptiveRecommendation[] = [];
    const accuracy = stats?.averageAccuracy ?? 0;
    const streak = stats?.currentStreak ?? 0;
    if (accuracy < 65) recs.push({ type: 'review', content: 'Heute zuerst Problemwörter wiederholen', reason: 'Deine Trefferquote ist noch instabil', priority: 'high' });
    if (accuracy >= 65 && accuracy < 85) recs.push({ type: 'practice', content: '10 Minuten Satzbau und 10 Minuten Vokabeltraining', reason: 'Gute Basis, aber noch nicht konstant', priority: 'medium' });
    if (accuracy >= 85) recs.push({ type: 'vocabulary', content: 'Neue Wörter und Probeprüfung kombinieren', reason: 'Deine Basis ist stark genug für neues Material', priority: 'medium' });
    if (streak === 0) recs.push({ type: 'practice', content: 'Starte mit einer kurzen 5-Minuten-Einheit', reason: 'Eine kleine Einheit hilft beim Wiedereinstieg', priority: 'high' });
    recs.push({ type: 'grammar', content: 'Wiederhole Artikel immer zusammen mit dem Nomen', reason: 'Das stabilisiert Wortschatz und Satzbau gleichzeitig', priority: 'low' });
    setRecommendations(recs);
    return recs;
  };

  const adjustDifficulty = async (performance: number) => {
    let newDifficulty: 'easy' | 'medium' | 'hard' = currentDifficulty;
    if (performance > 90) newDifficulty = currentDifficulty === 'easy' ? 'medium' : 'hard';
    if (performance < 60) newDifficulty = currentDifficulty === 'hard' ? 'medium' : 'easy';
    setCurrentDifficulty(newDifficulty);
    await AsyncStorage.setItem('current_difficulty', newDifficulty);
  };

  const updateLearningPath = async (pathId: string, progress: number) => {
    const updatedPaths = learningPaths.map(p => (p.id === pathId ? { ...p, progress: Math.min(progress, 100) } : p));
    setLearningPaths(updatedPaths);
    await AsyncStorage.setItem('learning_paths', JSON.stringify(updatedPaths));
  };

  const getAdaptiveContent = (): LearningPath[] => learningPaths.filter(p => p.difficulty === currentDifficulty || p.recommended);
  const clearError = () => setError(null);

  return (
    <AdaptiveLearningContext.Provider value={{ learningPaths, recommendations, currentDifficulty, generateLearningPath, getRecommendations, adjustDifficulty, updateLearningPath, getAdaptiveContent, isLoading, error, clearError }}>
      {children}
    </AdaptiveLearningContext.Provider>
  );
}

export function useAdaptiveLearning() {
  const context = useContext(AdaptiveLearningContext);
  if (!context) throw new Error('useAdaptiveLearning must be used within AdaptiveLearningProvider');
  return context;
}
