import { describe, it, expect } from 'vitest';
import { getExamQuestionsByLevel, getVocabularyByLevel } from './vocabulary-data-extended';
import { CEFRLevel } from './types-extended';

describe('Exam Mode - CEFR Levels', () => {
  it('should return questions for A1 level', () => {
    const questions = getExamQuestionsByLevel('A1');
    expect(questions.length).toBeGreaterThan(0);
    expect(questions.every(q => q.cefrLevel === 'A1')).toBe(true);
  });

  it('should return questions for A2 level', () => {
    const questions = getExamQuestionsByLevel('A2');
    expect(questions.length).toBeGreaterThan(0);
    expect(questions.every(q => q.cefrLevel === 'A2')).toBe(true);
  });

  it('should return questions for B1 level', () => {
    const questions = getExamQuestionsByLevel('B1');
    expect(questions.length).toBeGreaterThan(0);
    expect(questions.every(q => q.cefrLevel === 'B1')).toBe(true);
  });

  it('should return questions for B2 level', () => {
    const questions = getExamQuestionsByLevel('B2');
    expect(questions.length).toBeGreaterThan(0);
    expect(questions.every(q => q.cefrLevel === 'B2')).toBe(true);
  });

  it('should have correct answer for each question', () => {
    const levels: CEFRLevel[] = ['A1', 'A2', 'B1', 'B2'];
    
    for (const level of levels) {
      const questions = getExamQuestionsByLevel(level);
      
      for (const question of questions) {
        expect(question.correctAnswer).toBeDefined();
        expect(question.correctAnswer.length).toBeGreaterThan(0);
        
        if (question.options) {
          expect(question.options.includes(question.correctAnswer)).toBe(true);
        }
      }
    }
  });

  it('should return vocabulary for each CEFR level', () => {
    const levels: CEFRLevel[] = ['A1', 'A2', 'B1', 'B2'];
    
    for (const level of levels) {
      const vocab = getVocabularyByLevel(level);
      expect(vocab.length).toBeGreaterThan(0);
      expect(vocab.every(w => w.cefrLevel === level)).toBe(true);
    }
  });

  it('should calculate exam score correctly', () => {
    // Test scoring logic
    const totalQuestions = 10;
    const correctAnswers = 7;
    const score = Math.round((correctAnswers / totalQuestions) * 100);
    
    expect(score).toBe(70);
    expect(score >= 70).toBe(true); // Should pass
  });

  it('should fail exam with score below 70%', () => {
    const totalQuestions = 10;
    const correctAnswers = 6;
    const score = Math.round((correctAnswers / totalQuestions) * 100);
    
    expect(score).toBe(60);
    expect(score >= 70).toBe(false); // Should fail
  });

  it('should pass exam with score of 70% or higher', () => {
    const testCases = [
      { correct: 7, total: 10, expected: true },
      { correct: 8, total: 10, expected: true },
      { correct: 10, total: 10, expected: true },
      { correct: 6, total: 10, expected: false },
      { correct: 5, total: 10, expected: false },
    ];

    for (const testCase of testCases) {
      const score = Math.round((testCase.correct / testCase.total) * 100);
      const passed = score >= 70;
      expect(passed).toBe(testCase.expected);
    }
  });

  it('should have unique question IDs', () => {
    const levels: CEFRLevel[] = ['A1', 'A2', 'B1', 'B2'];
    const allQuestions: string[] = [];
    
    for (const level of levels) {
      const questions = getExamQuestionsByLevel(level);
      const ids = questions.map(q => q.id);
      allQuestions.push(...ids);
    }
    
    const uniqueIds = new Set(allQuestions);
    expect(uniqueIds.size).toBe(allQuestions.length);
  });
});
