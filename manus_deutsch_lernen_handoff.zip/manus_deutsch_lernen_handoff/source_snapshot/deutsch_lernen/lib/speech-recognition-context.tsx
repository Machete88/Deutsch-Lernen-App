import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Platform } from 'react-native';
import * as Audio from 'expo-audio';

interface SpeechRecognitionContextType {
  isListening: boolean;
  isRecording: boolean;
  recordedUri: string | null;
  startListening: () => Promise<void>;
  stopListening: () => Promise<void>;
  startRecording: () => Promise<void>;
  stopRecording: () => Promise<string | null>;
  playAudio: (uri: string) => Promise<void>;
  speakText: (text: string, language: string) => Promise<void>;
  isLoading: boolean;
}

const SpeechRecognitionContext = createContext<SpeechRecognitionContextType | undefined>(undefined);

function getSpeechSynthesis(): SpeechSynthesis | null {
  if (typeof globalThis === 'undefined') return null;
  return (globalThis as any).speechSynthesis ?? null;
}

export function SpeechRecognitionProvider({ children }: { children: ReactNode }) {
  const [isListening, setIsListening] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedUri, setRecordedUri] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [recording, setRecording] = useState<any>(null);

  const startListening = async () => {
    setIsLoading(true);
    setIsListening(true);
    setIsLoading(false);
  };

  const stopListening = async () => {
    setIsListening(false);
  };

  const startRecording = async () => {
    try {
      setIsLoading(true);
      const permission = await (Audio as any).requestPermissionsAsync?.();
      if (permission && !permission.granted) {
        throw new Error('Audio permission not granted');
      }
      await (Audio as any).setAudioModeAsync?.({ allowsRecordingIOS: true, playsInSilentModeIOS: true });

      const newRecording = new (Audio as any).Recording();
      await newRecording.prepareToRecordAsync((Audio as any).RecordingPresets.HIGH_QUALITY);
      await newRecording.startAsync();
      setRecording(newRecording);
      setRecordedUri(null);
      setIsRecording(true);
    } catch (error) {
      console.error('Error starting recording:', error);
      setIsRecording(false);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const stopRecording = async (): Promise<string | null> => {
    try {
      setIsLoading(true);
      if (!recording) {
        throw new Error('No recording in progress');
      }
      await recording.stopAndUnloadAsync();
      const uri = recording.getURI?.() ?? null;
      setRecording(null);
      setIsRecording(false);
      setRecordedUri(uri);
      return uri;
    } catch (error) {
      console.error('Error stopping recording:', error);
      setIsRecording(false);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const playAudio = async (uri: string) => {
    try {
      setIsLoading(true);
      if (/^https?:\/\//.test(uri) && Platform.OS === 'web') {
        const audio = new globalThis.Audio(uri);
        await audio.play();
        setIsLoading(false);
        return;
      }

      const sound = new (Audio as any).Sound();
      await sound.loadAsync({ uri });
      await sound.playAsync();
      sound.setOnPlaybackStatusUpdate?.((status: any) => {
        if (status?.isLoaded && status.didJustFinish) {
          sound.unloadAsync?.();
          setIsLoading(false);
        }
      });
    } catch (error) {
      console.error('Error playing audio:', error);
      setIsLoading(false);
    }
  };

  const speakText = async (text: string, language: string) => {
    try {
      setIsLoading(true);
      const synth = getSpeechSynthesis();
      if (Platform.OS === 'web' && synth && typeof SpeechSynthesisUtterance !== 'undefined') {
        synth.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = language || 'de-DE';
        utterance.rate = 0.95;
        utterance.onend = () => setIsLoading(false);
        utterance.onerror = () => setIsLoading(false);
        synth.speak(utterance);
        return;
      }
      await new Promise(resolve => setTimeout(resolve, Math.min(1200, 350 + text.length * 25)));
    } catch (error) {
      console.error('Error speaking text:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SpeechRecognitionContext.Provider
      value={{ isListening, isRecording, recordedUri, startListening, stopListening, startRecording, stopRecording, playAudio, speakText, isLoading }}
    >
      {children}
    </SpeechRecognitionContext.Provider>
  );
}

export function useSpeechRecognition() {
  const context = useContext(SpeechRecognitionContext);
  if (!context) {
    throw new Error('useSpeechRecognition must be used within SpeechRecognitionProvider');
  }
  return context;
}
