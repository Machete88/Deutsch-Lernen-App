import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as SecureStore from 'expo-secure-store';
import { generateSalt, hashPassword, normalizeEmail, verifyPassword } from './security';

interface User {
  id: string;
  email: string;
  name: string;
  createdAt: number;
  level: 'beginner' | 'intermediate' | 'advanced';
}

interface StoredCredentialRecord {
  user: User;
  salt: string;
  passwordHash: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  register: (email: string, password: string, name: string) => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (name: string, level: string) => Promise<void>;
  error: string | null;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);
const AUTH_USER_KEY = 'auth_user';
const AUTH_EMAIL_KEY = 'auth_email';
const secureCredentialKey = (email: string) => `secure_user_${normalizeEmail(email)}`;

async function loadStoredCredentials(email: string): Promise<StoredCredentialRecord | null> {
  const secureValue = await SecureStore.getItemAsync(secureCredentialKey(email));
  if (secureValue) {
    return JSON.parse(secureValue) as StoredCredentialRecord;
  }

  const legacyValue = await AsyncStorage.getItem(`user_${normalizeEmail(email)}`);
  if (!legacyValue) return null;

  const parsed = JSON.parse(legacyValue) as { password?: string; user: User };
  if (!parsed.user) return null;

  const salt = generateSalt();
  const passwordHash = hashPassword(parsed.password || '', salt);
  const upgraded: StoredCredentialRecord = { user: parsed.user, salt, passwordHash };
  await SecureStore.setItemAsync(secureCredentialKey(email), JSON.stringify(upgraded));
  await AsyncStorage.removeItem(`user_${normalizeEmail(email)}`);
  return upgraded;
}

async function persistSession(user: User): Promise<void> {
  await AsyncStorage.setItem(AUTH_USER_KEY, JSON.stringify(user));
  await AsyncStorage.setItem(AUTH_EMAIL_KEY, normalizeEmail(user.email));
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const storedUser = await AsyncStorage.getItem(AUTH_USER_KEY);
        if (storedUser) {
          setUser(JSON.parse(storedUser));
        }
      } catch (err) {
        console.error('Error loading user:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadUser();
  }, []);

  const register = async (email: string, password: string, name: string) => {
    try {
      setError(null);
      setIsLoading(true);

      const normalizedEmail = normalizeEmail(email);
      if (!normalizedEmail || !password || !name.trim()) {
        throw new Error('Alle Felder sind erforderlich');
      }
      if (password.length < 6) {
        throw new Error('Passwort muss mindestens 6 Zeichen lang sein');
      }

      const existingUser = await loadStoredCredentials(normalizedEmail);
      if (existingUser) {
        throw new Error('Diese Email ist bereits registriert');
      }

      const newUser: User = {
        id: `user_${Date.now()}`,
        email: normalizedEmail,
        name: name.trim(),
        createdAt: Date.now(),
        level: 'beginner',
      };

      const salt = generateSalt();
      const passwordHash = hashPassword(password, salt);
      const storedRecord: StoredCredentialRecord = { user: newUser, salt, passwordHash };

      await SecureStore.setItemAsync(secureCredentialKey(normalizedEmail), JSON.stringify(storedRecord));
      await persistSession(newUser);
      setUser(newUser);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Registrierung fehlgeschlagen';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (email: string, password: string) => {
    try {
      setError(null);
      setIsLoading(true);

      const normalizedEmail = normalizeEmail(email);
      if (!normalizedEmail || !password) {
        throw new Error('Email und Passwort sind erforderlich');
      }

      const record = await loadStoredCredentials(normalizedEmail);
      if (!record) {
        throw new Error('Benutzer nicht gefunden');
      }
      if (!verifyPassword(password, record.salt, record.passwordHash)) {
        throw new Error('Passwort ist falsch');
      }

      await persistSession(record.user);
      setUser(record.user);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Login fehlgeschlagen';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      setIsLoading(true);
      await AsyncStorage.multiRemove([AUTH_USER_KEY, AUTH_EMAIL_KEY]);
      setUser(null);
    } catch (err) {
      console.error('Error logging out:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const updateProfile = async (name: string, level: string) => {
    try {
      setError(null);
      if (!user) throw new Error('Kein Benutzer angemeldet');

      const updatedUser: User = {
        ...user,
        name: name.trim() || user.name,
        level: level as 'beginner' | 'intermediate' | 'advanced',
      };

      const record = await loadStoredCredentials(updatedUser.email);
      if (record) {
        const updatedRecord: StoredCredentialRecord = { ...record, user: updatedUser };
        await SecureStore.setItemAsync(secureCredentialKey(updatedUser.email), JSON.stringify(updatedRecord));
      }

      await persistSession(updatedUser);
      setUser(updatedUser);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Profil-Update fehlgeschlagen';
      setError(errorMessage);
      throw err;
    }
  };

  const clearError = () => setError(null);

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        register,
        login,
        logout,
        updateProfile,
        error,
        clearError,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}
