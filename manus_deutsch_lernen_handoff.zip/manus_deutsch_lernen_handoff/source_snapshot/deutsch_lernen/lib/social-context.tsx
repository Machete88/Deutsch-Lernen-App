import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface Friend { id: string; username: string; avatar?: string; level: string; points: number; lastActive: number; isFriend: boolean; }
interface LearningGroup { id: string; name: string; description: string; members: Friend[]; createdAt: number; admin: string; isJoined: boolean; }
interface SocialContextType {
  friends: Friend[];
  learningGroups: LearningGroup[];
  friendRequests: Friend[];
  addFriend: (userId: string) => Promise<void>;
  removeFriend: (userId: string) => Promise<void>;
  acceptFriendRequest: (userId: string) => Promise<void>;
  rejectFriendRequest: (userId: string) => Promise<void>;
  createLearningGroup: (name: string, description: string) => Promise<void>;
  joinLearningGroup: (groupId: string) => Promise<void>;
  leaveLearningGroup: (groupId: string) => Promise<void>;
  shareLearningProgress: (friendId: string) => Promise<void>;
  getFriendLeaderboard: () => Friend[];
  isLoading: boolean;
  error: string | null;
  clearError: () => void;
}

const SocialContext = createContext<SocialContextType | undefined>(undefined);
const SEEDED_FRIENDS: Friend[] = [
  { id: 'anna', username: 'Anna', level: 'A1', points: 120, lastActive: Date.now(), isFriend: true },
  { id: 'dmitri', username: 'Dmitri', level: 'A2', points: 180, lastActive: Date.now() - 3600000, isFriend: true },
];

export function SocialProvider({ children }: { children: ReactNode }) {
  const [friends, setFriends] = useState<Friend[]>([]);
  const [learningGroups, setLearningGroups] = useState<LearningGroup[]>([]);
  const [friendRequests, setFriendRequests] = useState<Friend[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadSocialData = async () => {
      try {
        const stored = await AsyncStorage.getItem('user_friends');
        setFriends(stored ? JSON.parse(stored) : SEEDED_FRIENDS);
        const groups = await AsyncStorage.getItem('learning_groups');
        if (groups) setLearningGroups(JSON.parse(groups));
        const requests = await AsyncStorage.getItem('friend_requests');
        if (requests) setFriendRequests(JSON.parse(requests));
      } catch (err) {
        console.error('Error loading social data:', err);
      } finally {
        setIsLoading(false);
      }
    };
    loadSocialData();
  }, []);

  const addFriend = async (userId: string) => {
    const newFriend: Friend = { id: userId, username: userId, level: 'A1', points: 25, lastActive: Date.now(), isFriend: false };
    const updatedRequests = [...friendRequests, newFriend];
    setFriendRequests(updatedRequests);
    await AsyncStorage.setItem('friend_requests', JSON.stringify(updatedRequests));
  };
  const removeFriend = async (userId: string) => { const updatedFriends = friends.filter(f => f.id !== userId); setFriends(updatedFriends); await AsyncStorage.setItem('user_friends', JSON.stringify(updatedFriends)); };
  const acceptFriendRequest = async (userId: string) => {
    const request = friendRequests.find(r => r.id === userId);
    if (!request) throw new Error('Anfrage nicht gefunden');
    const newFriend = { ...request, isFriend: true, points: Math.max(request.points, 50) };
    const updatedFriends = [...friends, newFriend];
    const updatedRequests = friendRequests.filter(r => r.id !== userId);
    setFriends(updatedFriends); setFriendRequests(updatedRequests);
    await AsyncStorage.setItem('user_friends', JSON.stringify(updatedFriends));
    await AsyncStorage.setItem('friend_requests', JSON.stringify(updatedRequests));
  };
  const rejectFriendRequest = async (userId: string) => { const updated = friendRequests.filter(r => r.id !== userId); setFriendRequests(updated); await AsyncStorage.setItem('friend_requests', JSON.stringify(updated)); };
  const createLearningGroup = async (name: string, description: string) => {
    const newGroup: LearningGroup = { id: `group_${Date.now()}`, name, description, members: friends.slice(0, 2), createdAt: Date.now(), admin: 'current_user', isJoined: true };
    const updated = [...learningGroups, newGroup];
    setLearningGroups(updated); await AsyncStorage.setItem('learning_groups', JSON.stringify(updated));
  };
  const joinLearningGroup = async (groupId: string) => { const updated = learningGroups.map(g => g.id === groupId ? { ...g, isJoined: true } : g); setLearningGroups(updated); await AsyncStorage.setItem('learning_groups', JSON.stringify(updated)); };
  const leaveLearningGroup = async (groupId: string) => { const updated = learningGroups.map(g => g.id === groupId ? { ...g, isJoined: false } : g); setLearningGroups(updated); await AsyncStorage.setItem('learning_groups', JSON.stringify(updated)); };
  const shareLearningProgress = async (friendId: string) => {
    const updatedFriends = friends.map(friend => friend.id === friendId ? { ...friend, points: friend.points + 5, lastActive: Date.now() } : friend);
    setFriends(updatedFriends);
    await AsyncStorage.setItem('user_friends', JSON.stringify(updatedFriends));
  };
  const getFriendLeaderboard = () => [...friends].sort((a, b) => b.points - a.points);
  const clearError = () => setError(null);

  return <SocialContext.Provider value={{ friends, learningGroups, friendRequests, addFriend, removeFriend, acceptFriendRequest, rejectFriendRequest, createLearningGroup, joinLearningGroup, leaveLearningGroup, shareLearningProgress, getFriendLeaderboard, isLoading, error, clearError }}>{children}</SocialContext.Provider>;
}

export function useSocial() {
  const context = useContext(SocialContext);
  if (!context) throw new Error('useSocial must be used within SocialProvider');
  return context;
}
