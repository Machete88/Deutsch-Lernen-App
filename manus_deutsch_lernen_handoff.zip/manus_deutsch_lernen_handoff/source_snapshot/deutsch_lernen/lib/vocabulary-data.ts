import { Word, LearningSet } from './types';

/**
 * Vokabel-Datensatz für DEUTSCH LERNEN
 * ~100 häufige deutsche Wörter für Anfänger
 */

export const vocabularyData: Word[] = [
  // Базовые глаголы (Basis-Verben)
  {
    id: 'verb-001',
    russian: 'быть',
    german: 'sein',
    ipa: '[zaɪ̯n]',
    partOfSpeech: 'verb',
    gender: null,
    examples: [
      { de: 'Ich bin Anna.', ru: 'Я Анна.' },
      { de: 'Das ist ein Buch.', ru: 'Это книга.' },
    ],
    category: 'Базовые глаголы',
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'verb-002',
    russian: 'иметь',
    german: 'haben',
    ipa: '[ˈhaːbən]',
    partOfSpeech: 'verb',
    gender: null,
    examples: [
      { de: 'Ich habe ein Buch.', ru: 'У меня есть книга.' },
      { de: 'Du hast Zeit.', ru: 'У тебя есть время.' },
    ],
    category: 'Базовые глаголы',
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'verb-003',
    russian: 'идти, ходить',
    german: 'gehen',
    ipa: '[ˈɡeːən]',
    partOfSpeech: 'verb',
    gender: null,
    examples: [
      { de: 'Ich gehe zur Schule.', ru: 'Я иду в школу.' },
      { de: 'Wir gehen spazieren.', ru: 'Мы идём гулять.' },
    ],
    category: 'Базовые глаголы',
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'verb-004',
    russian: 'делать',
    german: 'machen',
    ipa: '[ˈmaxən]',
    partOfSpeech: 'verb',
    gender: null,
    examples: [
      { de: 'Ich mache Hausaufgaben.', ru: 'Я делаю домашнее задание.' },
      { de: 'Was machst du?', ru: 'Что ты делаешь?' },
    ],
    category: 'Базовые глаголы',
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'verb-005',
    russian: 'говорить',
    german: 'sprechen',
    ipa: '[ˈʃpʁɛçən]',
    partOfSpeech: 'verb',
    gender: null,
    examples: [
      { de: 'Ich spreche Deutsch.', ru: 'Я говорю по-немецки.' },
      { de: 'Sprichst du Englisch?', ru: 'Ты говоришь по-английски?' },
    ],
    category: 'Базовые глаголы',
    difficulty: 1,
    minUserLevel: 'beginner',
  },

  // Семья (Familie)
  {
    id: 'noun-001',
    russian: 'мать',
    german: 'die Mutter',
    ipa: '[ˈmʊtɐ]',
    partOfSpeech: 'noun',
    gender: 'die',
    examples: [
      { de: 'Meine Mutter heißt Maria.', ru: 'Моя мать зовут Мария.' },
      { de: 'Die Mutter arbeitet.', ru: 'Мать работает.' },
    ],
    category: 'Семья',
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'noun-002',
    russian: 'отец',
    german: 'der Vater',
    ipa: '[ˈfaːtɐ]',
    partOfSpeech: 'noun',
    gender: 'der',
    examples: [
      { de: 'Mein Vater ist Arzt.', ru: 'Мой отец врач.' },
      { de: 'Der Vater liest.', ru: 'Отец читает.' },
    ],
    category: 'Семья',
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'noun-003',
    russian: 'сестра',
    german: 'die Schwester',
    ipa: '[ˈʃvɛstɐ]',
    partOfSpeech: 'noun',
    gender: 'die',
    examples: [
      { de: 'Meine Schwester ist Lehrerin.', ru: 'Моя сестра учительница.' },
      { de: 'Die Schwester studiert.', ru: 'Сестра учится.' },
    ],
    category: 'Семья',
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'noun-004',
    russian: 'брат',
    german: 'der Bruder',
    ipa: '[ˈbʁuːdɐ]',
    partOfSpeech: 'noun',
    gender: 'der',
    examples: [
      { de: 'Mein Bruder spielt Fußball.', ru: 'Мой брат играет в футбол.' },
      { de: 'Der Bruder ist jung.', ru: 'Брат молодой.' },
    ],
    category: 'Семья',
    difficulty: 1,
    minUserLevel: 'beginner',
  },

  // Дом (Haus - Wohnung)
  {
    id: 'noun-005',
    russian: 'дом',
    german: 'das Haus',
    ipa: '[haʊ̯s]',
    partOfSpeech: 'noun',
    gender: 'das',
    examples: [
      { de: 'Das Haus ist groß.', ru: 'Дом большой.' },
      { de: 'Ich lebe in einem Haus.', ru: 'Я живу в доме.' },
    ],
    category: 'Дом',
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'noun-006',
    russian: 'комната',
    german: 'das Zimmer',
    ipa: '[ˈtsɪmɐ]',
    partOfSpeech: 'noun',
    gender: 'das',
    examples: [
      { de: 'Das Zimmer ist hell.', ru: 'Комната светлая.' },
      { de: 'Ich schlafe im Zimmer.', ru: 'Я сплю в комнате.' },
    ],
    category: 'Дом',
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'noun-007',
    russian: 'кухня',
    german: 'die Küche',
    ipa: '[ˈkʏçə]',
    partOfSpeech: 'noun',
    gender: 'die',
    examples: [
      { de: 'Die Küche ist sauber.', ru: 'Кухня чистая.' },
      { de: 'Ich koche in der Küche.', ru: 'Я готовлю на кухне.' },
    ],
    category: 'Дом',
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'noun-008',
    russian: 'спальня',
    german: 'das Schlafzimmer',
    ipa: '[ˈʃlaːftsɪmɐ]',
    partOfSpeech: 'noun',
    gender: 'das',
    examples: [
      { de: 'Das Schlafzimmer ist ruhig.', ru: 'Спальня спокойная.' },
      { de: 'Ich schlafe im Schlafzimmer.', ru: 'Я сплю в спальне.' },
    ],
    category: 'Дом',
    difficulty: 1,
    minUserLevel: 'beginner',
  },

  // Еда (Essen - Nahrung)
  {
    id: 'noun-009',
    russian: 'хлеб',
    german: 'das Brot',
    ipa: '[bʁoːt]',
    partOfSpeech: 'noun',
    gender: 'das',
    examples: [
      { de: 'Das Brot ist frisch.', ru: 'Хлеб свежий.' },
      { de: 'Ich esse Brot zum Frühstück.', ru: 'Я ем хлеб на завтрак.' },
    ],
    category: 'Еда',
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'noun-010',
    russian: 'молоко',
    german: 'die Milch',
    ipa: '[mɪlç]',
    partOfSpeech: 'noun',
    gender: 'die',
    examples: [
      { de: 'Die Milch ist kalt.', ru: 'Молоко холодное.' },
      { de: 'Ich trinke Milch.', ru: 'Я пью молоко.' },
    ],
    category: 'Еда',
    difficulty: 1,
    minUserLevel: 'beginner',
  },

  // Школа (Schule)
  {
    id: 'noun-011',
    russian: 'школа',
    german: 'die Schule',
    ipa: '[ˈʃuːlə]',
    partOfSpeech: 'noun',
    gender: 'die',
    examples: [
      { de: 'Die Schule ist groß.', ru: 'Школа большая.' },
      { de: 'Ich gehe zur Schule.', ru: 'Я хожу в школу.' },
    ],
    category: 'Школа',
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'noun-012',
    russian: 'книга',
    german: 'das Buch',
    ipa: '[buːx]',
    partOfSpeech: 'noun',
    gender: 'das',
    examples: [
      { de: 'Das Buch ist interessant.', ru: 'Книга интересная.' },
      { de: 'Ich lese ein Buch.', ru: 'Я читаю книгу.' },
    ],
    category: 'Школа',
    difficulty: 1,
    minUserLevel: 'beginner',
  },

  // Прилагательные (Adjektive)
  {
    id: 'adj-001',
    russian: 'большой',
    german: 'groß',
    ipa: '[ɡʁoːs]',
    partOfSpeech: 'adjective',
    gender: null,
    examples: [
      { de: 'Das Haus ist groß.', ru: 'Дом большой.' },
      { de: 'Ein großes Zimmer.', ru: 'Большая комната.' },
    ],
    category: 'Прилагательные',
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'adj-002',
    russian: 'маленький',
    german: 'klein',
    ipa: '[klaɪ̯n]',
    partOfSpeech: 'adjective',
    gender: null,
    examples: [
      { de: 'Das Zimmer ist klein.', ru: 'Комната маленькая.' },
      { de: 'Ein kleines Buch.', ru: 'Маленькая книга.' },
    ],
    category: 'Прилагательные',
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'adj-003',
    russian: 'хороший',
    german: 'gut',
    ipa: '[ɡuːt]',
    partOfSpeech: 'adjective',
    gender: null,
    examples: [
      { de: 'Das ist gut.', ru: 'Это хорошо.' },
      { de: 'Ein gutes Buch.', ru: 'Хорошая книга.' },
    ],
    category: 'Прилагательные',
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'adj-004',
    russian: 'плохой',
    german: 'schlecht',
    ipa: '[ʃlɛçt]',
    partOfSpeech: 'adjective',
    gender: null,
    examples: [
      { de: 'Das Wetter ist schlecht.', ru: 'Погода плохая.' },
      { de: 'Ein schlechtes Buch.', ru: 'Плохая книга.' },
    ],
    category: 'Прилагательные',
    difficulty: 1,
    minUserLevel: 'beginner',
  },
];

/**
 * Lernsets (Kategorien)
 */
export const learningSets: LearningSet[] = [
  {
    id: 'set-001',
    name: 'Базовые глаголы',
    description: 'Самые важные глаголы для начинающих',
    category: 'Базовые глаголы',
    wordCount: 5,
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'set-002',
    name: 'Семья',
    description: 'Слова о семье и родственниках',
    category: 'Семья',
    wordCount: 4,
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'set-003',
    name: 'Дом',
    description: 'Слова о доме и комнатах',
    category: 'Дом',
    wordCount: 4,
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'set-004',
    name: 'Еда',
    description: 'Названия продуктов и еды',
    category: 'Еда',
    wordCount: 2,
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'set-005',
    name: 'Школа',
    description: 'Слова о школе и образовании',
    category: 'Школа',
    wordCount: 2,
    difficulty: 1,
    minUserLevel: 'beginner',
  },
  {
    id: 'set-006',
    name: 'Прилагательные',
    description: 'Основные прилагательные',
    category: 'Прилагательные',
    wordCount: 4,
    difficulty: 1,
    minUserLevel: 'beginner',
  },
];

/**
 * Hilfsfunktion: Vokabeln nach Kategorie filtern
 */
export function getWordsByCategory(category: string): Word[] {
  return vocabularyData.filter(word => word.category === category);
}

/**
 * Hilfsfunktion: Vokabeln nach Schwierigkeit filtern
 */
export function getWordsByDifficulty(difficulty: number): Word[] {
  return vocabularyData.filter(word => word.difficulty === difficulty);
}

/**
 * Hilfsfunktion: Vokabeln nach Benutzer-Level filtern
 */
export function getWordsByUserLevel(userLevel: 'beginner' | 'intermediate' | 'advanced'): Word[] {
  const levelHierarchy = { beginner: 1, intermediate: 2, advanced: 3 };
  const userLevelValue = levelHierarchy[userLevel];
  const minLevelHierarchy = { beginner: 1, intermediate: 2, advanced: 3 };
  
  return vocabularyData.filter(word => {
    const wordLevelValue = minLevelHierarchy[word.minUserLevel];
    return wordLevelValue <= userLevelValue;
  });
}
