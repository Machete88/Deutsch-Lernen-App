const API_BASE = '/api';

async function safeFetch(path: string, init?: RequestInit) {
  try {
    const response = await fetch(`${API_BASE}${path}`, {
      headers: { 'Content-Type': 'application/json', ...(init?.headers || {}) },
      ...init,
    });
    return await response.json();
  } catch {
    return null;
  }
}

export async function fetchBackendHealth() {
  return safeFetch('/trpc/system.health');
}

export async function fetchBackendRecommendations() {
  return safeFetch('/trpc/learning.dailyRecommendations');
}

export async function postSyncSnapshot(payload: unknown) {
  return safeFetch('/trpc/sync.pushSnapshot', {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}
