import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: number;
  progress: number;
  maxProgress: number;
}

interface UserRank {
  rank: number;
  points: number;
  level: string;
  nextLevelPoints: number;
}

interface AchievementsContextType {
  achievements: Achievement[];
  userRank: UserRank;
  totalPoints: number;
  unlockedCount: number;
  addPoints: (points: number) => Promise<void>;
  checkAchievements: (stats: any) => Promise<void>;
  getAchievementProgress: (id: string) => number;
  unlockAchievement: (id: string) => Promise<void>;
  getLeaderboardPosition: () => number;
  isLoading: boolean;
  error: string | null;
  clearError: () => void;
}

const AchievementsContext = createContext<AchievementsContextType | undefined>(undefined);

const DEFAULT_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_word',
    name: '🎯 Erstes Wort',
    description: 'Lerne dein erstes Wort',
    icon: '📚',
    unlocked: false,
    progress: 0,
    maxProgress: 1,
  },
  {
    id: 'ten_words',
    name: '📖 Zehn Wörter',
    description: 'Lerne 10 Wörter',
    icon: '📚',
    unlocked: false,
    progress: 0,
    maxProgress: 10,
  },
  {
    id: 'hundred_words',
    name: '📚 Hundert Wörter',
    description: 'Lerne 100 Wörter',
    icon: '📚',
    unlocked: false,
    progress: 0,
    maxProgress: 100,
  },
  {
    id: 'perfect_day',
    name: '🔥 Perfekter Tag',
    description: 'Erreiche 100% Genauigkeit an einem Tag',
    icon: '🔥',
    unlocked: false,
    progress: 0,
    maxProgress: 1,
  },
  {
    id: 'seven_day_streak',
    name: '🏆 Woche Durchgehalten',
    description: 'Lerne 7 Tage in Folge',
    icon: '🏆',
    unlocked: false,
    progress: 0,
    maxProgress: 7,
  },
  {
    id: 'exam_master',
    name: '🎓 Prüfungs-Meister',
    description: 'Bestehe eine Prüfung mit 90%+',
    icon: '🎓',
    unlocked: false,
    progress: 0,
    maxProgress: 1,
  },
];

export function AchievementsProvider({ children }: { children: ReactNode }) {
  const [achievements, setAchievements] = useState<Achievement[]>(DEFAULT_ACHIEVEMENTS);
  const [userRank, setUserRank] = useState<UserRank>({
    rank: 1,
    points: 0,
    level: 'Anfänger',
    nextLevelPoints: 100,
  });
  const [totalPoints, setTotalPoints] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Lade Achievements beim App-Start
  useEffect(() => {
    const loadAchievements = async () => {
      try {
        const stored = await AsyncStorage.getItem('user_achievements');
        if (stored) {
          setAchievements(JSON.parse(stored));
        }

        const rank = await AsyncStorage.getItem('user_rank');
        if (rank) {
          setUserRank(JSON.parse(rank));
        }

        const points = await AsyncStorage.getItem('user_points');
        if (points) {
          setTotalPoints(parseInt(points));
        }
      } catch (err) {
        console.error('Error loading achievements:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadAchievements();
  }, []);

  const addPoints = async (points: number) => {
    try {
      setError(null);

      const newTotal = totalPoints + points;
      setTotalPoints(newTotal);

      // Berechne neuen Rang
      let newLevel = 'Anfänger';
      let nextLevelPoints = 100;

      if (newTotal >= 500) {
        newLevel = 'Fortgeschrittener';
        nextLevelPoints = 1000;
      } else if (newTotal >= 1000) {
        newLevel = 'Experte';
        nextLevelPoints = 2000;
      } else if (newTotal >= 2000) {
        newLevel = 'Meister';
        nextLevelPoints = 5000;
      }

      const updatedRank: UserRank = {
        ...userRank,
        points: newTotal,
        level: newLevel,
        nextLevelPoints,
      };

      setUserRank(updatedRank);
      await AsyncStorage.setItem('user_points', newTotal.toString());
      await AsyncStorage.setItem('user_rank', JSON.stringify(updatedRank));
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Fehler beim Hinzufügen von Punkten';
      setError(errorMessage);
      throw err;
    }
  };

  const checkAchievements = async (stats: any) => {
    try {
      setError(null);

      const updatedAchievements = [...achievements];

      // Prüfe Achievements basierend auf Statistiken
      if (stats.totalWordsLearned >= 1) {
        unlockAchievementById(updatedAchievements, 'first_word');
      }
      if (stats.totalWordsLearned >= 10) {
        unlockAchievementById(updatedAchievements, 'ten_words');
      }
      if (stats.totalWordsLearned >= 100) {
        unlockAchievementById(updatedAchievements, 'hundred_words');
      }
      if (stats.averageAccuracy === 100) {
        unlockAchievementById(updatedAchievements, 'perfect_day');
      }
      if (stats.currentStreak >= 7) {
        unlockAchievementById(updatedAchievements, 'seven_day_streak');
      }

      setAchievements(updatedAchievements);
      await AsyncStorage.setItem('user_achievements', JSON.stringify(updatedAchievements));
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Fehler beim Prüfen von Achievements';
      setError(errorMessage);
      throw err;
    }
  };

  const getAchievementProgress = (id: string): number => {
    const achievement = achievements.find(a => a.id === id);
    return achievement ? (achievement.progress / achievement.maxProgress) * 100 : 0;
  };

  const unlockAchievement = async (id: string) => {
    try {
      setError(null);

      const updatedAchievements = [...achievements];
      unlockAchievementById(updatedAchievements, id);

      setAchievements(updatedAchievements);
      await AsyncStorage.setItem('user_achievements', JSON.stringify(updatedAchievements));

      // Gebe Punkte für Achievement
      await addPoints(50);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Fehler beim Freischalten von Achievement';
      setError(errorMessage);
      throw err;
    }
  };

  const getLeaderboardPosition = (): number => {
    // TODO: Integriere mit Backend für echte Leaderboard-Positionen
    return Math.floor(totalPoints / 100) + 1;
  };

  const clearError = () => setError(null);

  return (
    <AchievementsContext.Provider
      value={{
        achievements,
        userRank,
        totalPoints,
        unlockedCount: achievements.filter(a => a.unlocked).length,
        addPoints,
        checkAchievements,
        getAchievementProgress,
        unlockAchievement,
        getLeaderboardPosition,
        isLoading,
        error,
        clearError,
      }}
    >
      {children}
    </AchievementsContext.Provider>
  );
}

export function useAchievements() {
  const context = useContext(AchievementsContext);
  if (!context) {
    throw new Error('useAchievements must be used within AchievementsProvider');
  }
  return context;
}

function unlockAchievementById(achievements: Achievement[], id: string) {
  const achievement = achievements.find(a => a.id === id);
  if (achievement && !achievement.unlocked) {
    achievement.unlocked = true;
    achievement.unlockedAt = Date.now();
  }
}
