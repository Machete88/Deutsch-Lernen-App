import { describe, it, expect } from 'vitest';
import { 
  examQuestionsA1, 
  examQuestionsA2, 
  examQuestionsB1, 
  examQuestionsB2,
  getExamQuestionsByLevel 
} from './exam-data-extended';

describe('Exam Data Extended', () => {
  describe('Exam Questions Structure', () => {
    it('should have A1 questions', () => {
      expect(examQuestionsA1.length).toBeGreaterThan(0);
    });

    it('should have A2 questions', () => {
      expect(examQuestionsA2.length).toBeGreaterThan(0);
    });

    it('should have B1 questions', () => {
      expect(examQuestionsB1.length).toBeGreaterThan(0);
    });

    it('should have B2 questions', () => {
      expect(examQuestionsB2.length).toBeGreaterThan(0);
    });

    it('A1 questions should have German and Russian text', () => {
      examQuestionsA1.forEach(q => {
        expect(q.germanText).toBeDefined();
        expect(q.germanText.length).toBeGreaterThan(0);
        expect(q.russianTranslation).toBeDefined();
        expect(q.russianTranslation.length).toBeGreaterThan(0);
      });
    });

    it('A1 questions should have correct type', () => {
      examQuestionsA1.forEach(q => {
        expect(['reading', 'writing', 'listening', 'speaking', 'multiple-choice', 'matching']).toContain(q.type);
      });
    });

    it('A1 questions with options should have correct answers marked', () => {
      examQuestionsA1.forEach(q => {
        if (q.options && q.options.length > 0) {
          const correctCount = q.options.filter(opt => opt.isCorrect).length;
          expect(correctCount).toBeGreaterThan(0);
        }
      });
    });

    it('A1 questions should have explanations', () => {
      examQuestionsA1.forEach(q => {
        expect(q.explanation).toBeDefined();
        expect(q.explanation?.german).toBeDefined();
        expect(q.explanation?.russian).toBeDefined();
      });
    });

    it('A1 questions should have time limits', () => {
      examQuestionsA1.forEach(q => {
        expect(q.timeLimit).toBeDefined();
        expect(q.timeLimit).toBeGreaterThan(0);
      });
    });
  });

  describe('getExamQuestionsByLevel', () => {
    it('should return A1 questions for A1 level', () => {
      const questions = getExamQuestionsByLevel('A1');
      expect(questions.length).toBe(examQuestionsA1.length);
      questions.forEach(q => expect(q.level).toBe('A1'));
    });

    it('should return A2 questions for A2 level', () => {
      const questions = getExamQuestionsByLevel('A2');
      expect(questions.length).toBe(examQuestionsA2.length);
      questions.forEach(q => expect(q.level).toBe('A2'));
    });

    it('should return B1 questions for B1 level', () => {
      const questions = getExamQuestionsByLevel('B1');
      expect(questions.length).toBe(examQuestionsB1.length);
      questions.forEach(q => expect(q.level).toBe('B1'));
    });

    it('should return B2 questions for B2 level', () => {
      const questions = getExamQuestionsByLevel('B2');
      expect(questions.length).toBe(examQuestionsB2.length);
      questions.forEach(q => expect(q.level).toBe('B2'));
    });
  });

  describe('Question Content Quality', () => {
    it('B1 questions should be more complex than A1', () => {
      const a1Avg = examQuestionsA1.reduce((sum, q) => sum + q.germanText.length, 0) / examQuestionsA1.length;
      const b1Avg = examQuestionsB1.reduce((sum, q) => sum + q.germanText.length, 0) / examQuestionsB1.length;
      expect(b1Avg).toBeGreaterThan(a1Avg);
    });

    it('B2 questions should be more complex than B1', () => {
      const b1Avg = examQuestionsB1.reduce((sum, q) => sum + q.germanText.length, 0) / examQuestionsB1.length;
      const b2Avg = examQuestionsB2.reduce((sum, q) => sum + q.germanText.length, 0) / examQuestionsB2.length;
      expect(b2Avg).toBeGreaterThan(b1Avg);
    });

    it('all questions should have unique IDs', () => {
      const allQuestions = [...examQuestionsA1, ...examQuestionsA2, ...examQuestionsB1, ...examQuestionsB2];
      const ids = allQuestions.map(q => q.id);
      const uniqueIds = new Set(ids);
      expect(uniqueIds.size).toBe(ids.length);
    });

    it('options should have unique IDs within a question', () => {
      const allQuestions = [...examQuestionsA1, ...examQuestionsA2, ...examQuestionsB1, ...examQuestionsB2];
      allQuestions.forEach(q => {
        if (q.options && q.options.length > 0) {
          const optionIds = q.options.map(opt => opt.id);
          const uniqueOptionIds = new Set(optionIds);
          expect(uniqueOptionIds.size).toBe(optionIds.length);
        }
      });
    });
  });

  describe('Translation Quality', () => {
    it('all German texts should have Russian translations', () => {
      const allQuestions = [...examQuestionsA1, ...examQuestionsA2, ...examQuestionsB1, ...examQuestionsB2];
      allQuestions.forEach(q => {
        expect(q.russianTranslation).toBeDefined();
        expect(q.russianTranslation.length).toBeGreaterThan(0);
        expect(q.russianTranslation).not.toBe(q.germanText);
      });
    });

    it('all options should have German and Russian text', () => {
      const allQuestions = [...examQuestionsA1, ...examQuestionsA2, ...examQuestionsB1, ...examQuestionsB2];
      allQuestions.forEach(q => {
        if (q.options && q.options.length > 0) {
          q.options.forEach(opt => {
            expect(opt.germanText).toBeDefined();
            expect(opt.germanText.length).toBeGreaterThan(0);
            expect(opt.russianTranslation).toBeDefined();
            expect(opt.russianTranslation.length).toBeGreaterThan(0);
          });
        }
      });
    });
  });
});
