import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Word, UserWordState, LearningSet, LastResult } from './types';
import { vocabularyData, learningSets, getWordsByUserLevel } from './vocabulary-data';
import { useSettings } from './settings-context';

interface VocabularyContextType {
  words: Word[];
  learningSets: LearningSet[];
  userWordStates: Map<string, UserWordState>;
  currentSet: LearningSet | null;
  setCurrentSet: (set: LearningSet | null) => Promise<void>;
  recordWordResult: (wordId: string, result: LastResult) => Promise<void>;
  getWordsForReview: () => Word[];
  getNewWords: (count: number) => Word[];
  isLoading: boolean;
}

const VocabularyContext = createContext<VocabularyContextType | undefined>(undefined);

export function VocabularyProvider({ children }: { children: ReactNode }) {
  const { settings } = useSettings();
  const [words, setWords] = useState<Word[]>([]);
  const [userWordStates, setUserWordStates] = useState<Map<string, UserWordState>>(new Map());
  const [currentSet, setCurrentSetState] = useState<LearningSet | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Lade Vokabeln beim App-Start
  useEffect(() => {
    const loadVocabulary = async () => {
      try {
        // Filtere Vokabeln nach Benutzer-Level
        const filteredWords = getWordsByUserLevel(settings.userLevel);
        setWords(filteredWords);

        // Lade Benutzer-Fortschritt
        const stored = await AsyncStorage.getItem('user_word_states');
        if (stored) {
          const parsed = JSON.parse(stored) as Array<[string, UserWordState]>;
          const statesMap = new Map<string, UserWordState>(parsed);
          setUserWordStates(statesMap);
        }

        // Lade aktuelles Set
        const storedSet = await AsyncStorage.getItem('current_learning_set');
        if (storedSet) {
          const set = learningSets.find(s => s.id === storedSet);
          setCurrentSetState(set || null);
        }
      } catch (error) {
        console.warn('Error loading vocabulary:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadVocabulary();
  }, [settings.userLevel]);

  const setCurrentSet = async (set: LearningSet | null) => {
    try {
      setCurrentSetState(set);
      if (set) {
        await AsyncStorage.setItem('current_learning_set', set.id);
      } else {
        await AsyncStorage.removeItem('current_learning_set');
      }
    } catch (error) {
      console.error('Error setting current set:', error);
      throw error;
    }
  };

  const recordWordResult = async (wordId: string, result: LastResult) => {
    try {
      const now = Date.now();
      const existingState = userWordStates.get(wordId);

      let newState: UserWordState;

      if (!existingState) {
        // Neues Wort
        newState = {
          wordId,
          nextReview: now,
          intervalDays: result === 'easy' ? 1 : result === 'normal' ? 0.5 : 0,
          easeFactor: result === 'easy' ? 2.5 : result === 'normal' ? 2.3 : 2.0,
          repetitions: result === 'easy' ? 1 : 0,
          lapses: result === 'hard' ? 1 : 0,
          lastResult: result,
          lastReviewDate: now,
          createdAt: now,
        };
      } else {
        // Existierendes Wort - Spaced Repetition Logik
        let newIntervalDays = existingState.intervalDays;
        let newEaseFactor = existingState.easeFactor;
        let newRepetitions = existingState.repetitions;
        let newLapses = existingState.lapses;

        if (result === 'easy') {
          // Erfolgreiche Wiederholung - Intervall verlängern
          newIntervalDays = existingState.intervalDays * existingState.easeFactor;
          newEaseFactor = Math.max(1.3, existingState.easeFactor + 0.1);
          newRepetitions = existingState.repetitions + 1;
        } else if (result === 'normal') {
          // Normale Wiederholung - Intervall leicht verlängern
          newIntervalDays = existingState.intervalDays * 1.2;
          newEaseFactor = existingState.easeFactor;
          newRepetitions = existingState.repetitions + 1;
        } else if (result === 'hard') {
          // Fehlgeschlagene Wiederholung - Intervall zurücksetzen
          newIntervalDays = 0.5;
          newEaseFactor = Math.max(1.3, existingState.easeFactor - 0.2);
          newLapses = existingState.lapses + 1;
        }

        // Berechne nächstes Review-Datum
        const nextReviewDate = now + newIntervalDays * 24 * 60 * 60 * 1000;

        newState = {
          ...existingState,
          intervalDays: newIntervalDays,
          easeFactor: newEaseFactor,
          repetitions: newRepetitions,
          lapses: newLapses,
          lastResult: result,
          lastReviewDate: now,
          nextReview: nextReviewDate,
        };
      }

      // Speichere neuen State
      const newStates = new Map(userWordStates);
      newStates.set(wordId, newState);
      setUserWordStates(newStates);

      // Persistiere in AsyncStorage
      const statesArray = Array.from(newStates.entries());
      await AsyncStorage.setItem('user_word_states', JSON.stringify(statesArray));
    } catch (error) {
      console.error('Error recording word result:', error);
      throw error;
    }
  };

  const getWordsForReview = (): Word[] => {
    const now = Date.now();
    const reviewWords: Word[] = [];

    for (const word of words) {
      const state = userWordStates.get(word.id);
      if (state && state.nextReview <= now) {
        reviewWords.push(word);
      }
    }

    return reviewWords;
  };

  const getNewWords = (count: number): Word[] => {
    const newWords: Word[] = [];

    for (const word of words) {
      if (!userWordStates.has(word.id)) {
        newWords.push(word);
        if (newWords.length >= count) break;
      }
    }

    return newWords;
  };

  return (
    <VocabularyContext.Provider
      value={{
        words,
        learningSets,
        userWordStates,
        currentSet,
        setCurrentSet,
        recordWordResult,
        getWordsForReview,
        getNewWords,
        isLoading,
      }}
    >
      {children}
    </VocabularyContext.Provider>
  );
}

export function useVocabulary() {
  const context = useContext(VocabularyContext);
  if (!context) {
    throw new Error('useVocabulary must be used within VocabularyProvider');
  }
  return context;
}
