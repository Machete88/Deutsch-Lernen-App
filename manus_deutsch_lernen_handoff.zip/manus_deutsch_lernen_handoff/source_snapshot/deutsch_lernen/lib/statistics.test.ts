import { describe, it, expect } from 'vitest';

describe('Statistics Context', () => {
  it('should initialize statistics with default values', () => {
    const stats = {
      totalWordsLearned: 0,
      totalWordsReviewed: 0,
      totalCorrectAnswers: 0,
      totalAnswers: 0,
      currentStreak: 0,
      longestStreak: 0,
      lastActivityDate: new Date().toISOString().split('T')[0],
      dailyStats: [],
      averageAccuracy: 0,
      level: 'beginner',
    };

    expect(stats.totalWordsLearned).toBe(0);
    expect(stats.currentStreak).toBe(0);
    expect(stats.averageAccuracy).toBe(0);
  });

  it('should record learning activity', () => {
    const stats = {
      totalWordsLearned: 0,
      totalWordsReviewed: 0,
      totalCorrectAnswers: 0,
      totalAnswers: 0,
      currentStreak: 0,
      longestStreak: 0,
      lastActivityDate: new Date().toISOString().split('T')[0],
      dailyStats: [],
      averageAccuracy: 0,
      level: 'beginner',
    };

    stats.totalWordsLearned += 5;
    expect(stats.totalWordsLearned).toBe(5);
  });

  it('should calculate accuracy', () => {
    const totalCorrect = 80;
    const totalAnswers = 100;
    const accuracy = Math.round((totalCorrect / totalAnswers) * 100);

    expect(accuracy).toBe(80);
  });

  it('should track streak days', () => {
    let streak = 0;
    const hasActivityToday = true;

    if (hasActivityToday) {
      streak += 1;
    }

    expect(streak).toBe(1);
  });

  it('should update longest streak', () => {
    let currentStreak = 5;
    let longestStreak = 3;

    longestStreak = Math.max(currentStreak, longestStreak);
    expect(longestStreak).toBe(5);
  });

  it('should create daily stats entry', () => {
    const today = new Date().toISOString().split('T')[0];
    const dailyStats = {
      date: today,
      wordsLearned: 0,
      wordsReviewed: 0,
      correctAnswers: 0,
      totalAnswers: 0,
      streakDays: 0,
    };

    expect(dailyStats.date).toBe(today);
    expect(dailyStats.wordsLearned).toBe(0);
  });

  it('should filter weekly stats', () => {
    const today = new Date();
    const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);

    const stats = [
      { date: new Date(today.getTime() - 1 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], words: 5 },
      { date: new Date(today.getTime() - 8 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], words: 3 },
    ];

    const weeklyStats = stats.filter(s => {
      const statDate = new Date(s.date);
      return statDate >= weekAgo && statDate <= today;
    });

    expect(weeklyStats.length).toBe(1);
  });
});
