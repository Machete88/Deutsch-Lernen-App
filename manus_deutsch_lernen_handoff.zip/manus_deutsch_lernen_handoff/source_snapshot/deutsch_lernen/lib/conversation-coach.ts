export interface ConversationScenario {
  id: string;
  title: string;
  level: 'A1' | 'A2' | 'B1';
  setting: string;
  openingLine: string;
  goal: string;
  hints: string[];
}

export interface ConversationReply {
  answer: string;
  correction: string;
  betterOption: string;
  encouragement: string;
}

export const conversationScenarios: ConversationScenario[] = [
  {
    id: 'cafe',
    title: 'Im Café bestellen',
    level: 'A1',
    setting: 'Du bestellst ein Getränk und etwas zu essen.',
    openingLine: 'Guten Tag. Was möchten Sie bestellen?',
    goal: 'Bestelle höflich ein Getränk und einen Snack.',
    hints: ['Nutze: Ich möchte ...', 'Sei höflich mit bitte.', 'Halte die Antwort kurz und klar.'],
  },
  {
    id: 'arzt',
    title: 'Beim Arzt',
    level: 'A2',
    setting: 'Du beschreibst ein einfaches Problem beim Arzt.',
    openingLine: 'Guten Morgen. Was fehlt Ihnen?',
    goal: 'Beschreibe dein Problem in 1 bis 2 Sätzen.',
    hints: ['Nutze: Ich habe ...', 'Beschreibe seit wann.', 'Nenne ein Symptom.'],
  },
  {
    id: 'vorstellung',
    title: 'Sich vorstellen',
    level: 'A1',
    setting: 'Du lernst neue Leute im Kurs kennen.',
    openingLine: 'Hallo. Erzähl bitte kurz etwas über dich.',
    goal: 'Nenne Name, Herkunft und warum du Deutsch lernst.',
    hints: ['Nutze: Ich heiße ...', 'Ich komme aus ...', 'Ich lerne Deutsch, weil ...'],
  },
];

function buildCorrection(userMessage: string): string {
  const trimmed = userMessage.trim();
  if (!trimmed) return 'Schreibe eine kurze Antwort, damit ich sie korrigieren kann.';
  if (!/[.!?]$/.test(trimmed)) return 'Gut verständlich. Ergänze am Ende noch einen Punkt für einen vollständigen Satz.';
  if (/ich bin kommen/i.test(trimmed)) return 'Achte auf die Verbform: "ich komme", nicht "ich bin kommen".';
  if (/möchte ein kaffe/i.test(trimmed)) return 'Im Deutschen heißt es meist: "einen Kaffee". Achte auf Artikel und Endung.';
  return 'Dein Satz ist gut verständlich. Achte weiter auf Artikel, Verbposition und höfliche Formulierungen.';
}

function buildBetterOption(userMessage: string, scenarioId?: string): string {
  if (scenarioId === 'cafe') return 'Besser: "Ich möchte bitte einen Kaffee und ein Käsebrötchen."';
  if (scenarioId === 'arzt') return 'Besser: "Ich habe seit zwei Tagen starke Kopfschmerzen und fühle mich müde."';
  if (scenarioId === 'vorstellung') return 'Besser: "Ich heiße Alex, komme aus Spanien und lerne Deutsch für meine Arbeit."';
  return `Verbesserte Version: "${userMessage.trim() || 'Ich brauche noch einen Beispielsatz.'}"`;
}

export function createConversationReply(userMessage: string, scenarioId?: string): ConversationReply {
  const lower = userMessage.toLowerCase();
  let answer = 'Danke. Antworte noch einmal mit einem ganzen Satz.';
  if (scenarioId === 'cafe') {
    answer = /kaffee|tee|wasser/.test(lower)
      ? 'Sehr gut. Möchtest du noch etwas dazu essen?'
      : 'Gut. Nenne bitte noch ein Getränk oder einen Snack.';
  } else if (scenarioId === 'arzt') {
    answer = /schmerz|fieber|husten|müde/.test(lower)
      ? 'Verstanden. Seit wann hast du diese Beschwerden?'
      : 'Beschreibe bitte dein Symptom etwas genauer.';
  } else if (scenarioId === 'vorstellung') {
    answer = /heiße|komme|lerne/.test(lower)
      ? 'Schön. Kannst du noch sagen, warum du Deutsch lernst?'
      : 'Stell dich bitte in einem ganzen Satz vor.';
  }

  return {
    answer,
    correction: buildCorrection(userMessage),
    betterOption: buildBetterOption(userMessage, scenarioId),
    encouragement: 'Gut gemacht. Kurze, klare Sätze sind perfekt zum Üben.',
  };
}
