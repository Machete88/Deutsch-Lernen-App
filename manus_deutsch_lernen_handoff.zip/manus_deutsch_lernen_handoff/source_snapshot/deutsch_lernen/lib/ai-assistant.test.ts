import { describe, it, expect } from 'vitest';

describe('AI Assistant', () => {
  it('should recognize greeting', () => {
    const message = 'Hallo';
    const isGreeting = message.toLowerCase().includes('hallo') || message.toLowerCase().includes('hi');
    expect(isGreeting).toBe(true);
  });

  it('should recognize word-related questions', () => {
    const message = 'Was bedeutet dieses Wort?';
    const isWordQuestion = message.toLowerCase().includes('wort') || message.toLowerCase().includes('bedeutung');
    expect(isWordQuestion).toBe(true);
  });

  it('should recognize pronunciation questions', () => {
    const message = 'Wie spricht man das aus?';
    const isPronunciationQuestion = message.toLowerCase().includes('spricht') || message.toLowerCase().includes('aussprache') || message.toLowerCase().includes('aussprech');
    expect(isPronunciationQuestion).toBe(true);
  });

  it('should recognize example requests', () => {
    const message = 'Gib mir ein Beispiel';
    const isExampleRequest = message.toLowerCase().includes('beispiel') || message.toLowerCase().includes('satz');
    expect(isExampleRequest).toBe(true);
  });

  it('should create message with correct structure', () => {
    const message = {
      id: 'msg_123',
      role: 'user' as const,
      content: 'Hallo!',
      timestamp: Date.now(),
    };

    expect(message.id).toBeDefined();
    expect(message.role).toBe('user');
    expect(message.content).toBeDefined();
    expect(message.timestamp).toBeGreaterThan(0);
  });

  it('should create conversation with correct structure', () => {
    const conversation = {
      id: 'conv_123',
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      topic: 'Deutsch Lernen',
    };

    expect(conversation.id).toBeDefined();
    expect(Array.isArray(conversation.messages)).toBe(true);
    expect(conversation.createdAt).toBeGreaterThan(0);
    expect(conversation.topic).toBe('Deutsch Lernen');
  });

  it('should add message to conversation', () => {
    const conversation = {
      id: 'conv_123',
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    const newMessage = {
      id: 'msg_123',
      role: 'user' as const,
      content: 'Hallo!',
      timestamp: Date.now(),
    };

    const updatedConversation = {
      ...conversation,
      messages: [...conversation.messages, newMessage],
      updatedAt: Date.now(),
    };

    expect(updatedConversation.messages.length).toBe(1);
    expect(updatedConversation.messages[0].content).toBe('Hallo!');
  });

  it('should generate response for greeting', () => {
    const userMessage = 'Hallo';
    const lowerMessage = userMessage.toLowerCase();
    
    let response = '';
    if (lowerMessage.includes('hallo') || lowerMessage.includes('hi')) {
      response = 'Hallo! Ich bin dein KI-Assistent.';
    }

    expect(response).toBeDefined();
    expect(response.length).toBeGreaterThan(0);
  });

  it('should handle empty message gracefully', () => {
    const message = '';
    const isEmpty = message.trim().length === 0;
    expect(isEmpty).toBe(true);
  });

  it('should preserve conversation history', () => {
    const messages = [
      { id: '1', role: 'user' as const, content: 'Hallo', timestamp: Date.now() },
      { id: '2', role: 'assistant' as const, content: 'Hallo!', timestamp: Date.now() },
      { id: '3', role: 'user' as const, content: 'Wie geht es dir?', timestamp: Date.now() },
    ];

    expect(messages.length).toBe(3);
    expect(messages[0].role).toBe('user');
    expect(messages[1].role).toBe('assistant');
    expect(messages[2].content).toBe('Wie geht es dir?');
  });
});
