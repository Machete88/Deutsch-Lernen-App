import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Word } from './types';

interface WordReview {
  wordId: string;
  interval: number; // Tage bis zur nächsten Wiederholung
  easeFactor: number; // SM-2 Algorithmus
  repetitions: number;
  nextReviewDate: number; // Timestamp
  lastReviewDate: number;
}

interface ReviewSession {
  id: string;
  words: Word[];
  currentIndex: number;
  answers: Map<string, boolean>; // wordId -> correct
  startedAt: number;
}

interface SpacedRepetitionContextType {
  reviews: Map<string, WordReview>;
  currentSession: ReviewSession | null;
  getDueWords: (words: Word[]) => Word[];
  startReviewSession: (words: Word[]) => Promise<void>;
  recordReview: (wordId: string, correct: boolean) => Promise<void>;
  completeSession: () => Promise<{ correct: number; total: number }>;
  isLoading: boolean;
}

const SpacedRepetitionContext = createContext<SpacedRepetitionContextType | undefined>(undefined);

// SM-2 Algorithmus für Spaced Repetition
function calculateNextReview(
  current: WordReview,
  correct: boolean
): WordReview {
  if (correct) {
    const newRepetitions = current.repetitions + 1;
    let newInterval = current.interval;
    let newEaseFactor = current.easeFactor;

    if (newRepetitions === 1) {
      newInterval = 1;
    } else if (newRepetitions === 2) {
      newInterval = 3;
    } else {
      newInterval = Math.round(newInterval * newEaseFactor);
    }

    newEaseFactor = Math.max(
      1.3,
      newEaseFactor + 0.1 - (5 - 5) * (0.08 + (5 - 5) * 0.02)
    );

    return {
      ...current,
      repetitions: newRepetitions,
      interval: newInterval,
      easeFactor: newEaseFactor,
      nextReviewDate: Date.now() + newInterval * 24 * 60 * 60 * 1000,
      lastReviewDate: Date.now(),
    };
  } else {
    // Falsch beantwortet - zurücksetzen
    return {
      ...current,
      repetitions: 0,
      interval: 1,
      easeFactor: Math.max(1.3, current.easeFactor - 0.2),
      nextReviewDate: Date.now() + 24 * 60 * 60 * 1000,
      lastReviewDate: Date.now(),
    };
  }
}

export function SpacedRepetitionProvider({ children }: { children: ReactNode }) {
  const [reviews, setReviews] = useState<Map<string, WordReview>>(new Map());
  const [currentSession, setCurrentSession] = useState<ReviewSession | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Lade Wiederholungsdaten beim App-Start
  useEffect(() => {
    const loadReviews = async () => {
      try {
        const storedReviews = await AsyncStorage.getItem('spaced_repetition_reviews');
        if (storedReviews) {
          const parsed = JSON.parse(storedReviews);
          const reviewsMap = new Map(Object.entries(parsed));
          setReviews(reviewsMap as Map<string, WordReview>);
        }
      } catch (error) {
        console.warn('Error loading reviews:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadReviews();
  }, []);

  const getDueWords = (words: Word[]): Word[] => {
    const now = Date.now();
    return words.filter(word => {
      const review = reviews.get(word.id);
      if (!review) return true; // Neue Wörter sind immer fällig
      return review.nextReviewDate <= now;
    });
  };

  const startReviewSession = async (words: Word[]) => {
    const dueWords = getDueWords(words);
    if (dueWords.length === 0) return;

    const newSession: ReviewSession = {
      id: `session-${Date.now()}`,
      words: dueWords.sort(() => Math.random() - 0.5),
      currentIndex: 0,
      answers: new Map(),
      startedAt: Date.now(),
    };

    setCurrentSession(newSession);
  };

  const recordReview = async (wordId: string, correct: boolean) => {
    if (!currentSession) return;

    try {
      const updatedSession = {
        ...currentSession,
        answers: new Map(currentSession.answers).set(wordId, correct),
      };

      setCurrentSession(updatedSession);

      // Aktualisiere Wiederholungsdaten
      const currentReview = reviews.get(wordId) || {
        wordId,
        interval: 0,
        easeFactor: 2.5,
        repetitions: 0,
        nextReviewDate: Date.now(),
        lastReviewDate: 0,
      };

      const newReview = calculateNextReview(currentReview, correct);
      const newReviews = new Map(reviews);
      newReviews.set(wordId, newReview);
      setReviews(newReviews);

      // Speichere in AsyncStorage
      const reviewsObj = Object.fromEntries(newReviews);
      await AsyncStorage.setItem('spaced_repetition_reviews', JSON.stringify(reviewsObj));
    } catch (error) {
      console.error('Error recording review:', error);
      throw error;
    }
  };

  const completeSession = async (): Promise<{ correct: number; total: number }> => {
    if (!currentSession) return { correct: 0, total: 0 };

    try {
      let correctCount = 0;
      for (const [, correct] of currentSession.answers) {
        if (correct) correctCount++;
      }

      setCurrentSession(null);
      return {
        correct: correctCount,
        total: currentSession.answers.size,
      };
    } catch (error) {
      console.error('Error completing session:', error);
      throw error;
    }
  };

  return (
    <SpacedRepetitionContext.Provider
      value={{
        reviews,
        currentSession,
        getDueWords,
        startReviewSession,
        recordReview,
        completeSession,
        isLoading,
      }}
    >
      {children}
    </SpacedRepetitionContext.Provider>
  );
}

export function useSpacedRepetition() {
  const context = useContext(SpacedRepetitionContext);
  if (!context) {
    throw new Error('useSpacedRepetition must be used within SpacedRepetitionProvider');
  }
  return context;
}
