/**
 * Datenmodell für die DEUTSCH LERNEN App
 */

export type PartOfSpeech = 'noun' | 'verb' | 'adjective' | 'adverb' | 'preposition' | 'pronoun';
export type Gender = 'der' | 'die' | 'das' | null;
export type Difficulty = 1 | 2 | 3;
export type UserLevel = 'beginner' | 'intermediate' | 'advanced';
export type LastResult = 'easy' | 'normal' | 'hard' | null;

/**
 * Vokabel-Eintrag
 */
export interface Word {
  id: string;
  russian: string;
  german: string;
  ipa?: string; // Lautschrift, z.B. [ˈgeːən]
  partOfSpeech: PartOfSpeech;
  gender: Gender;
  examples: Array<{
    de: string;
    ru: string;
  }>;
  audioWordUrl?: string; // URL zur Aussprache
  audioExampleUrl?: string;
  category: string; // z.B. "Базовые глаголы", "Семья"
  difficulty: Difficulty;
  minUserLevel: UserLevel; // Minimales Level zum Lernen
}

/**
 * Benutzer-Fortschritt für ein Wort
 * Basierend auf SM-2/FSRS-ähnlichem Algorithmus
 */
export interface UserWordState {
  wordId: string;
  nextReview: number; // Timestamp für nächste Wiederholung
  intervalDays: number; // Tage bis nächste Wiederholung
  easeFactor: number; // Leichtigkeit (Standard: 2.5)
  repetitions: number; // Anzahl erfolgreicher Wiederholungen
  lapses: number; // Anzahl fehlgeschlagener Wiederholungen
  lastResult: LastResult; // Letzte Antwort
  lastReviewDate?: number; // Timestamp der letzten Wiederholung
  createdAt: number; // Timestamp der Erstellung
}

/**
 * Lernset (Kategorie von Vokabeln)
 */
export interface LearningSet {
  id: string;
  name: string; // z.B. "Базовые глаголы"
  description: string;
  category: string;
  wordCount: number;
  difficulty: Difficulty;
  minUserLevel: UserLevel;
  icon?: string;
}

/**
 * Session-Log für Statistiken
 */
export interface SessionLog {
  id: string;
  type: 'learn' | 'review' | 'speak';
  startedAt: number;
  endedAt: number;
  wordsSeen: number;
  successRate?: number; // 0-1
  category?: string;
}

/**
 * Benutzer-Statistiken
 */
export interface UserStats {
  totalWordsLearned: number;
  totalWordsReviewed: number;
  totalSpeakingSessions: number;
  currentStreak: number; // Tage hintereinander gelernt
  lastActivityDate?: number;
  averageReviewAccuracy: number; // 0-1
}
