import React, { createContext, useContext, useState, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { analyzePronunciation } from './pronunciation';
import { buildDailyRecommendations } from './recommendation-service';

type MessageType = 'text' | 'suggestion' | 'feedback';
interface Message { id: string; role: 'user' | 'assistant'; content: string; timestamp: number; type?: MessageType; }
interface ConversationHistory { id: string; messages: Message[]; createdAt: number; updatedAt: number; topic?: string; }

interface AIAssistantContextType {
  currentConversation: ConversationHistory | null;
  conversations: ConversationHistory[];
  isLoading: boolean;
  sendMessage: (content: string) => Promise<string>;
  startNewConversation: (topic?: string) => Promise<void>;
  loadConversation: (id: string) => Promise<void>;
  deleteConversation: (id: string) => Promise<void>;
  getWordExplanation: (word: string, german: string) => Promise<string>;
  getExampleSentences: (word: string) => Promise<string[]>;
  getPronunciationFeedback: (word: string, userText: string) => Promise<string>;
  getPersonalizedRecommendations: () => Promise<string>;
  error: string | null;
  clearError: () => void;
}

const AIAssistantContext = createContext<AIAssistantContextType | undefined>(undefined);

export function AIAssistantProvider({ children }: { children: ReactNode }) {
  const [currentConversation, setCurrentConversation] = useState<ConversationHistory | null>(null);
  const [conversations, setConversations] = useState<ConversationHistory[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  React.useEffect(() => {
    const loadConversations = async () => {
      try {
        const stored = await AsyncStorage.getItem('ai_conversations');
        if (stored) setConversations(JSON.parse(stored));
      } catch (err) {
        console.error('Error loading conversations:', err);
      }
    };
    loadConversations();
  }, []);

  const persistConversations = async (updated: ConversationHistory[]) => {
    await AsyncStorage.setItem('ai_conversations', JSON.stringify(updated));
    setConversations(updated);
  };

  const sendMessage = async (content: string): Promise<string> => {
    try {
      setError(null);
      setIsLoading(true);
      if (!currentConversation) throw new Error('Kein aktives Gespräch');

      const userMessage: Message = { id: `msg_${Date.now()}`, role: 'user', content, timestamp: Date.now() };
      const assistantResponse = await generateSmartResponse(content);
      const assistantMessage: Message = { id: `msg_${Date.now() + 1}`, role: 'assistant', content: assistantResponse, timestamp: Date.now() };
      const updatedConversation: ConversationHistory = {
        ...currentConversation,
        messages: [...currentConversation.messages, userMessage, assistantMessage],
        updatedAt: Date.now(),
      };
      setCurrentConversation(updatedConversation);
      const updatedConversations = conversations.some(c => c.id === updatedConversation.id)
        ? conversations.map(c => (c.id === updatedConversation.id ? updatedConversation : c))
        : [updatedConversation, ...conversations];
      await persistConversations(updatedConversations);
      return assistantResponse;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Fehler beim Senden der Nachricht';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const startNewConversation = async (topic?: string) => {
    const newConversation: ConversationHistory = { id: `conv_${Date.now()}`, messages: [], createdAt: Date.now(), updatedAt: Date.now(), topic };
    setCurrentConversation(newConversation);
    await persistConversations([newConversation, ...conversations]);
  };

  const loadConversation = async (id: string) => {
    const conversation = conversations.find(c => c.id === id);
    if (!conversation) throw new Error('Gespräch nicht gefunden');
    setCurrentConversation(conversation);
  };

  const deleteConversation = async (id: string) => {
    const updated = conversations.filter(c => c.id !== id);
    if (currentConversation?.id === id) setCurrentConversation(null);
    await persistConversations(updated);
  };

  const getWordExplanation = async (word: string, german: string): Promise<string> => {
    setError(null);
    setIsLoading(true);
    try {
      return `„${german}“ bedeutet auf Russisch „${word}“. Merke dir das Wort am besten mit einem einfachen Beispielsatz und achte darauf, in welchen Alltagssituationen du es benutzen kannst.`;
    } finally {
      setIsLoading(false);
    }
  };

  const getExampleSentences = async (word: string): Promise<string[]> => {
    setError(null);
    setIsLoading(true);
    try {
      const normalized = word.trim() || 'Wort';
      return [
        `Ich benutze ${normalized} heute im Gespräch.`,
        `Kannst du ${normalized} bitte noch einmal sagen?`,
        `Im Unterricht schreibe ich ${normalized} in mein Heft.`,
      ];
    } finally {
      setIsLoading(false);
    }
  };

  const getPronunciationFeedback = async (word: string, userText: string): Promise<string> => {
    setError(null);
    setIsLoading(true);
    try {
      const analysis = analyzePronunciation(word, userText);
      return `${analysis.feedback} Trefferquote: ${analysis.similarity}%. Tipp: ${analysis.tips[0]}`;
    } finally {
      setIsLoading(false);
    }
  };

  const getPersonalizedRecommendations = async (): Promise<string> => {
    setError(null);
    setIsLoading(true);
    try {
      const [statisticsRaw, wordStatesRaw] = await Promise.all([
        AsyncStorage.getItem('user_statistics'),
        AsyncStorage.getItem('user_word_states'),
      ]);
      const statistics = statisticsRaw ? JSON.parse(statisticsRaw) : null;
      const wordStates: Array<[string, { lapses?: number; repetitions?: number; nextReview?: number }]> = wordStatesRaw ? JSON.parse(wordStatesRaw) : [];
      const difficultWords = wordStates.filter(([, state]) => (state.lapses ?? 0) >= 2).length;
      const dueToday = wordStates.filter(([, state]) => (state.nextReview ?? 0) <= Date.now()).length;
      const streak = statistics?.currentStreak ?? 0;
      const accuracy = statistics?.averageAccuracy ?? 0;
      return [
        `Heute sind ${dueToday} Wiederholungen fällig.`,
        difficultWords > 0 ? `${difficultWords} Wörter brauchen extra Aufmerksamkeit.` : 'Deine Problemwörter sind aktuell gut unter Kontrolle.',
        accuracy < 75 ? 'Konzentriere dich zuerst auf Wiederholung und kurze Sprechübungen.' : 'Du kannst heute gut neue Wörter und eine Prüfungseinheit kombinieren.',
        `Aktuelle Serie: ${streak} Tage. Halte die Lernroutine stabil.`,
      ].join(' ');
    } finally {
      setIsLoading(false);
    }
  };

  const clearError = () => setError(null);

  return (
    <AIAssistantContext.Provider value={{ currentConversation, conversations, isLoading, sendMessage, startNewConversation, loadConversation, deleteConversation, getWordExplanation, getExampleSentences, getPronunciationFeedback, getPersonalizedRecommendations, error, clearError }}>
      {children}
    </AIAssistantContext.Provider>
  );
}

export function useAIAssistant() {
  const context = useContext(AIAssistantContext);
  if (!context) throw new Error('useAIAssistant must be used within AIAssistantProvider');
  return context;
}

async function generateSmartResponse(userMessage: string): Promise<string> {
  const lowerMessage = userMessage.toLowerCase();

  if (/(hallo|hi|guten tag)/.test(lowerMessage)) {
    return 'Hallo. Ich helfe dir beim Deutschlernen mit Worterklärungen, Beispielsätzen, Aussprachetipps und Lernempfehlungen.';
  }
  if (/(artikel|der|die|das)/.test(lowerMessage)) {
    return 'Bei Artikeln hilft Gruppieren: lerne Nomen immer mit Artikel und Beispiel, zum Beispiel „das Haus“, „die Schule“, „der Termin“.';
  }
  if (/(beispiel|satz)/.test(lowerMessage)) {
    return 'Nenne mir ein Wort, dann gebe ich dir drei einfache Sätze auf Lernniveau.';
  }
  if (/(aussprache|aussprech|sprechen)/.test(lowerMessage)) {
    return 'Für bessere Aussprache: zuerst anhören, dann langsam in Silben nachsprechen, dann erst im normalen Tempo.';
  }
  if (/(prüfung|a1|a2|b1|b2)/.test(lowerMessage)) {
    return 'Für Prüfungen ist die beste Reihenfolge: Wortschatz wiederholen, kurze Sprechübung, dann eine zeitlich begrenzte Probeprüfung.';
  }

  return 'Beschreibe kurz, wobei du Hilfe brauchst: Wort erklären, Beispielsätze, Grammatik, Aussprache oder Prüfungsvorbereitung.';
}
