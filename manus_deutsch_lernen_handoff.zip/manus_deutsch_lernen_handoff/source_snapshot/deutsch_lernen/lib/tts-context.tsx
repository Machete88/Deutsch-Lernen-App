import React, { createContext, useContext, useState, ReactNode } from 'react';
import { Platform } from 'react-native';

interface TTSContextType {
  isAvailable: boolean;
  isSpeaking: boolean;
  speak: (text: string, language?: string) => Promise<void>;
  stop: () => Promise<void>;
  speakWord: (word: string, german: string) => Promise<void>;
  speakSentence: (sentence: string) => Promise<void>;
  isLoading: boolean;
  error: string | null;
  clearError: () => void;
}

const TTSContext = createContext<TTSContextType | undefined>(undefined);

function getSpeechSynthesis(): SpeechSynthesis | null {
  if (typeof globalThis === 'undefined') return null;
  return (globalThis as any).speechSynthesis ?? null;
}

export function TTSProvider({ children }: { children: ReactNode }) {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isAvailable = Platform.OS === 'web' && !!getSpeechSynthesis();

  const speak = async (text: string, language: string = 'de-DE') => {
    try {
      setError(null);
      setIsLoading(true);
      setIsSpeaking(true);

      const synth = getSpeechSynthesis();
      if (!text.trim()) {
        throw new Error('Kein Text für die Sprachausgabe vorhanden');
      }

      if (Platform.OS === 'web' && synth && typeof SpeechSynthesisUtterance !== 'undefined') {
        synth.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = language;
        utterance.rate = 0.95;
        utterance.onend = () => {
          setIsSpeaking(false);
          setIsLoading(false);
        };
        utterance.onerror = () => {
          setError('Die Sprachausgabe konnte nicht gestartet werden');
          setIsSpeaking(false);
          setIsLoading(false);
        };
        synth.speak(utterance);
        return;
      }

      await new Promise(resolve => setTimeout(resolve, Math.min(1200, 350 + text.length * 25)));
      setIsSpeaking(false);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Fehler bei der Sprachausgabe';
      setError(errorMessage);
      setIsSpeaking(false);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const stop = async () => {
    try {
      setError(null);
      const synth = getSpeechSynthesis();
      synth?.cancel();
      setIsSpeaking(false);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Fehler beim Stoppen der Sprachausgabe';
      setError(errorMessage);
      throw err;
    }
  };

  const speakWord = async (_word: string, german: string) => speak(german, 'de-DE');
  const speakSentence = async (sentence: string) => speak(sentence, 'de-DE');
  const clearError = () => setError(null);

  return (
    <TTSContext.Provider
      value={{ isAvailable, isSpeaking, speak, stop, speakWord, speakSentence, isLoading, error, clearError }}
    >
      {children}
    </TTSContext.Provider>
  );
}

export function useTTS() {
  const context = useContext(TTSContext);
  if (!context) {
    throw new Error('useTTS must be used within TTSProvider');
  }
  return context;
}
