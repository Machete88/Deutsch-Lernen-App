import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface DailyStats {
  date: string;
  wordsLearned: number;
  wordsReviewed: number;
  correctAnswers: number;
  totalAnswers: number;
  streakDays: number;
}

interface UserStatistics {
  totalWordsLearned: number;
  totalPointsEarned: number;
  totalWordsReviewed: number;
  totalCorrectAnswers: number;
  totalAnswers: number;
  currentStreak: number;
  longestStreak: number;
  lastActivityDate: string;
  dailyStats: DailyStats[];
  averageAccuracy: number;
  level: string;
}

interface StatisticsContextType {
  statistics: UserStatistics | null;
  isLoading: boolean;
  recordLearning: (count: number) => Promise<void>;
  recordReview: (correct: number, total: number) => Promise<void>;
  recordPoints: (points: number) => Promise<void>;
  getStreakDays: () => number;
  getAccuracy: () => number;
  getDailyStats: (date: string) => DailyStats | undefined;
  getWeeklyStats: () => DailyStats[];
  getMonthlyStats: () => DailyStats[];
  error: string | null;
  clearError: () => void;
}

const StatisticsContext = createContext<StatisticsContextType | undefined>(undefined);

export function StatisticsProvider({ children }: { children: ReactNode }) {
  const [statistics, setStatistics] = useState<UserStatistics | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Lade Statistiken beim App-Start
  useEffect(() => {
    const loadStatistics = async () => {
      try {
        const stored = await AsyncStorage.getItem('user_statistics');
        if (stored) {
          setStatistics(JSON.parse(stored));
        } else {
          // Initialisiere neue Statistiken
          const newStats: UserStatistics = {
            totalWordsLearned: 0,
            totalPointsEarned: 0,
            totalWordsReviewed: 0,
            totalCorrectAnswers: 0,
            totalAnswers: 0,
            currentStreak: 0,
            longestStreak: 0,
            lastActivityDate: new Date().toISOString().split('T')[0],
            dailyStats: [],
            averageAccuracy: 0,
            level: 'beginner',
          };
          setStatistics(newStats);
          await AsyncStorage.setItem('user_statistics', JSON.stringify(newStats));
        }
      } catch (err) {
        console.error('Error loading statistics:', err);
      } finally {
        setIsLoading(false);
      }
    };

    loadStatistics();
  }, []);

  const recordLearning = async (count: number) => {
    try {
      setError(null);
      if (!statistics) throw new Error('Keine Statistiken verfügbar');

      const today = new Date().toISOString().split('T')[0];
      const updatedStats = { ...statistics };

      // Finde oder erstelle heutige Statistik
      let todayStats = updatedStats.dailyStats.find(s => s.date === today);
      if (!todayStats) {
        todayStats = {
          date: today,
          wordsLearned: 0,
          wordsReviewed: 0,
          correctAnswers: 0,
          totalAnswers: 0,
          streakDays: 0,
        };
        updatedStats.dailyStats.push(todayStats);
      }

      // Aktualisiere Statistiken
      todayStats.wordsLearned += count;
      updatedStats.totalWordsLearned += count;
      updatedStats.lastActivityDate = today;
      updatedStats.totalPointsEarned += count * 5;

      // Aktualisiere Streak
      const yesterday = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString().split('T')[0];
      const hadActivityYesterday = updatedStats.dailyStats.some(
        s => s.date === yesterday && (s.wordsLearned > 0 || s.wordsReviewed > 0)
      );

      if (hadActivityYesterday || updatedStats.currentStreak === 0) {
        updatedStats.currentStreak += 1;
        updatedStats.longestStreak = Math.max(updatedStats.currentStreak, updatedStats.longestStreak);
      }

      setStatistics(updatedStats);
      await AsyncStorage.setItem('user_statistics', JSON.stringify(updatedStats));
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Fehler beim Speichern der Statistiken';
      setError(errorMessage);
      throw err;
    }
  };

  const recordReview = async (correct: number, total: number) => {
    try {
      setError(null);
      if (!statistics) throw new Error('Keine Statistiken verfügbar');

      const today = new Date().toISOString().split('T')[0];
      const updatedStats = { ...statistics };

      // Finde oder erstelle heutige Statistik
      let todayStats = updatedStats.dailyStats.find(s => s.date === today);
      if (!todayStats) {
        todayStats = {
          date: today,
          wordsLearned: 0,
          wordsReviewed: 0,
          correctAnswers: 0,
          totalAnswers: 0,
          streakDays: 0,
        };
        updatedStats.dailyStats.push(todayStats);
      }

      // Aktualisiere Statistiken
      todayStats.wordsReviewed += total;
      todayStats.correctAnswers += correct;
      todayStats.totalAnswers += total;
      updatedStats.totalWordsReviewed += total;
      updatedStats.totalCorrectAnswers += correct;
      updatedStats.totalAnswers += total;

      // Berechne Durchschnittsgenauigkeit
      if (updatedStats.totalAnswers > 0) {
        updatedStats.averageAccuracy = Math.round(
          (updatedStats.totalCorrectAnswers / updatedStats.totalAnswers) * 100
        );
      }

      setStatistics(updatedStats);
      await AsyncStorage.setItem('user_statistics', JSON.stringify(updatedStats));
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Fehler beim Speichern der Statistiken';
      setError(errorMessage);
      throw err;
    }
  };


  const recordPoints = async (points: number) => {
    try {
      setError(null);
      if (!statistics) throw new Error('Keine Statistiken verfügbar');

      const updatedStats = { ...statistics, totalPointsEarned: (statistics.totalPointsEarned || 0) + points };
      setStatistics(updatedStats);
      await AsyncStorage.setItem('user_statistics', JSON.stringify(updatedStats));
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Fehler beim Speichern der Punkte';
      setError(errorMessage);
      throw err;
    }
  };

  const getStreakDays = (): number => {
    return statistics?.currentStreak || 0;
  };

  const getAccuracy = (): number => {
    return statistics?.averageAccuracy || 0;
  };

  const getDailyStats = (date: string): DailyStats | undefined => {
    return statistics?.dailyStats.find(s => s.date === date);
  };

  const getWeeklyStats = (): DailyStats[] => {
    if (!statistics) return [];

    const today = new Date();
    const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);

    return statistics.dailyStats.filter(s => {
      const statDate = new Date(s.date);
      return statDate >= weekAgo && statDate <= today;
    });
  };

  const getMonthlyStats = (): DailyStats[] => {
    if (!statistics) return [];

    const today = new Date();
    const monthAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);

    return statistics.dailyStats.filter(s => {
      const statDate = new Date(s.date);
      return statDate >= monthAgo && statDate <= today;
    });
  };

  const clearError = () => setError(null);

  return (
    <StatisticsContext.Provider
      value={{
        statistics,
        isLoading,
        recordLearning,
        recordReview,
        recordPoints,
        getStreakDays,
        getAccuracy,
        getDailyStats,
        getWeeklyStats,
        getMonthlyStats,
        error,
        clearError,
      }}
    >
      {children}
    </StatisticsContext.Provider>
  );
}

export function useStatistics() {
  const context = useContext(StatisticsContext);
  if (!context) {
    throw new Error('useStatistics must be used within StatisticsProvider');
  }
  return context;
}
