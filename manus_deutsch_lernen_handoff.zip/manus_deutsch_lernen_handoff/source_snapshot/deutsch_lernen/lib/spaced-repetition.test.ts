import { describe, it, expect } from 'vitest';

// SM-2 Algorithmus Test
describe('Spaced Repetition - SM-2 Algorithm', () => {
  it('should calculate correct interval for first repetition', () => {
    const interval = 1;
    const easeFactor = 2.5;
    
    expect(interval).toBe(1);
    expect(easeFactor).toBe(2.5);
  });

  it('should calculate correct interval for second repetition', () => {
    const interval = 3;
    const easeFactor = 2.5;
    
    expect(interval).toBe(3);
  });

  it('should increase interval exponentially', () => {
    const intervals = [1, 3, 8, 20, 50];
    
    for (let i = 1; i < intervals.length; i++) {
      expect(intervals[i]).toBeGreaterThan(intervals[i - 1]);
    }
  });

  it('should reset interval on incorrect answer', () => {
    const interval = 10;
    const newInterval = 1; // Reset
    
    expect(newInterval).toBe(1);
  });

  it('should calculate next review date correctly', () => {
    const now = Date.now();
    const interval = 3; // 3 days
    const nextReviewDate = now + interval * 24 * 60 * 60 * 1000;
    
    expect(nextReviewDate).toBeGreaterThan(now);
    expect(nextReviewDate - now).toBe(interval * 24 * 60 * 60 * 1000);
  });

  it('should adjust ease factor based on performance', () => {
    let easeFactor = 2.5;
    
    // Perfect answer
    easeFactor = Math.max(1.3, easeFactor + 0.1);
    expect(easeFactor).toBeGreaterThan(2.5);
    
    // Reset for incorrect
    easeFactor = Math.max(1.3, 2.5 - 0.2);
    expect(easeFactor).toBe(2.3);
  });

  it('should never allow ease factor below 1.3', () => {
    let easeFactor = 1.5;
    
    // Multiple incorrect answers
    for (let i = 0; i < 5; i++) {
      easeFactor = Math.max(1.3, easeFactor - 0.2);
    }
    
    expect(easeFactor).toBeGreaterThanOrEqual(1.3);
  });

  it('should identify due words correctly', () => {
    const now = Date.now();
    const pastDate = now - 1000; // 1 second ago
    const futureDate = now + 1000; // 1 second from now
    
    const isDue1 = pastDate <= now;
    const isDue2 = futureDate <= now;
    
    expect(isDue1).toBe(true);
    expect(isDue2).toBe(false);
  });
});
