import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { CEFRLevel, ExamSession, ExamResult, UserCertificate, ExamAnswerDetail } from './types-extended';
import { getExamQuestionsByLevel } from './vocabulary-data-extended';

interface ExamContextType {
  currentSession: ExamSession | null;
  examResults: ExamResult[];
  certificates: UserCertificate[];
  startExam: (level: CEFRLevel) => Promise<void>;
  submitAnswer: (questionId: string, answer: string) => Promise<void>;
  completeExam: () => Promise<ExamResult | null>;
  getResultsByLevel: (level: CEFRLevel) => ExamResult[];
  isLoading: boolean;
}

const ExamContext = createContext<ExamContextType | undefined>(undefined);
const EXAM_DURATION_BY_LEVEL: Record<CEFRLevel, number> = { A1: 8 * 60, A2: 10 * 60, B1: 12 * 60, B2: 14 * 60 };

function getRecommendation(level: CEFRLevel, score: number): string {
  if (score >= 90) return `Starkes Ergebnis auf ${level}. Du kannst bereits Inhalte auf dem nächsten Niveau testen.`;
  if (score >= 70) return `Gutes Ergebnis auf ${level}. Wiederhole Fehlerfragen und festige die Grammatik, bevor du weitergehst.`;
  return `Trainiere ${level}-Wortschatz, Wiederholung und Aussprache gezielt weiter. Ein neuer Versuch nach 1–2 Lerneinheiten lohnt sich.`;
}

export function ExamProvider({ children }: { children: ReactNode }) {
  const [currentSession, setCurrentSession] = useState<ExamSession | null>(null);
  const [examResults, setExamResults] = useState<ExamResult[]>([]);
  const [certificates, setCertificates] = useState<UserCertificate[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const loadExamData = async () => {
      try {
        const storedResults = await AsyncStorage.getItem('exam_results');
        if (storedResults) setExamResults(JSON.parse(storedResults));
        const storedCertificates = await AsyncStorage.getItem('user_certificates');
        if (storedCertificates) setCertificates(JSON.parse(storedCertificates));
      } catch (error) {
        console.warn('Error loading exam data:', error);
      } finally {
        setIsLoading(false);
      }
    };
    loadExamData();
  }, []);

  const startExam = async (level: CEFRLevel) => {
    const questions = [...getExamQuestionsByLevel(level)].sort(() => Math.random() - 0.5);
    const durationSeconds = EXAM_DURATION_BY_LEVEL[level];
    setCurrentSession({
      id: `exam-${Date.now()}`,
      cefrLevel: level,
      startedAt: Date.now(),
      questions,
      answers: new Map(),
      durationSeconds,
      expiresAt: Date.now() + durationSeconds * 1000,
    });
  };

  const submitAnswer = async (questionId: string, answer: string) => {
    if (!currentSession) return;
    setCurrentSession({ ...currentSession, answers: new Map(currentSession.answers).set(questionId, answer) });
  };

  const completeExam = async (): Promise<ExamResult | null> => {
    if (!currentSession) return null;

    let correctCount = 0;
    const totalQuestions = currentSession.questions.length;
    const answerDetails: ExamAnswerDetail[] = currentSession.questions.map((question) => {
      const userAnswer = currentSession.answers.get(question.id) ?? '';
      const correct = userAnswer === question.correctAnswer;
      if (correct) correctCount += 1;
      return {
        questionId: question.id,
        prompt: question.russian,
        expectedAnswer: question.correctAnswer,
        userAnswer,
        correct,
        explanation: question.explanation,
      };
    });

    const score = Math.round((correctCount / Math.max(totalQuestions, 1)) * 100);
    const passed = score >= 70;
    const certificateNumber = `CERT-${currentSession.cefrLevel}-${Date.now()}`;
    const durationSeconds = Math.round((Date.now() - currentSession.startedAt) / 1000);

    const result: ExamResult = {
      id: `result-${Date.now()}`,
      cefrLevel: currentSession.cefrLevel,
      score,
      passed,
      totalQuestions,
      correctAnswers: correctCount,
      completedAt: Date.now(),
      certificateUrl: passed ? `/certificates/${certificateNumber}.pdf` : undefined,
      certificateNumber: passed ? certificateNumber : undefined,
      durationSeconds,
      recommendation: getRecommendation(currentSession.cefrLevel, score),
      answerDetails,
    };

    const newResults = [...examResults, result];
    setExamResults(newResults);
    await AsyncStorage.setItem('exam_results', JSON.stringify(newResults));

    if (passed) {
      const certificate: UserCertificate = {
        id: `cert-${Date.now()}`,
        cefrLevel: currentSession.cefrLevel,
        issuedAt: Date.now(),
        score,
        certificateNumber,
      };
      const newCertificates = [...certificates, certificate];
      setCertificates(newCertificates);
      await AsyncStorage.setItem('user_certificates', JSON.stringify(newCertificates));
    }

    setCurrentSession(null);
    return result;
  };

  const getResultsByLevel = (level: CEFRLevel): ExamResult[] => examResults.filter(r => r.cefrLevel === level);

  return (
    <ExamContext.Provider value={{ currentSession, examResults, certificates, startExam, submitAnswer, completeExam, getResultsByLevel, isLoading }}>
      {children}
    </ExamContext.Provider>
  );
}

export function useExam() {
  const context = useContext(ExamContext);
  if (!context) throw new Error('useExam must be used within ExamProvider');
  return context;
}
