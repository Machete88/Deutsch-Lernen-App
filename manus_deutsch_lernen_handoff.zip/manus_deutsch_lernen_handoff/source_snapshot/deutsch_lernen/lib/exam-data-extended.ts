// Erweiterte Prüfungsdaten mit deutschen Texten und russischen Übersetzungen

export interface ExamQuestion {
  id: string;
  level: 'A1' | 'A2' | 'B1' | 'B2';
  type: 'listening' | 'reading' | 'writing' | 'speaking' | 'multiple-choice' | 'matching';
  germanText: string;
  russianTranslation: string;
  options?: Array<{
    id: string;
    germanText: string;
    russianTranslation: string;
    isCorrect: boolean;
  }>;
  correctAnswer?: string;
  explanation?: {
    german: string;
    russian: string;
  };
  audioUrl?: string;
  timeLimit?: number; // in seconds
}

// A1 Prüfungsfragen - Anfänger
export const examQuestionsA1: ExamQuestion[] = [
  {
    id: 'a1-1',
    level: 'A1',
    type: 'reading',
    germanText: 'Wie heißt du?',
    russianTranslation: 'Как тебя зовут?',
    options: [
      {
        id: 'opt-1',
        germanText: 'Ich bin 25 Jahre alt.',
        russianTranslation: 'Мне 25 лет.',
        isCorrect: false,
      },
      {
        id: 'opt-2',
        germanText: 'Ich heiße Anna.',
        russianTranslation: 'Меня зовут Анна.',
        isCorrect: true,
      },
      {
        id: 'opt-3',
        germanText: 'Ich komme aus Russland.',
        russianTranslation: 'Я из России.',
        isCorrect: false,
      },
    ],
    explanation: {
      german: 'Die Frage "Wie heißt du?" fragt nach dem Namen. Die richtige Antwort ist "Ich heiße Anna."',
      russian: 'Вопрос "Как тебя зовут?" спрашивает имя. Правильный ответ: "Меня зовут Анна."',
    },
    timeLimit: 30,
  },
  {
    id: 'a1-2',
    level: 'A1',
    type: 'reading',
    germanText: 'Woher kommst du?',
    russianTranslation: 'Откуда ты?',
    options: [
      {
        id: 'opt-1',
        germanText: 'Ich bin Lehrer.',
        russianTranslation: 'Я учитель.',
        isCorrect: false,
      },
      {
        id: 'opt-2',
        germanText: 'Ich bin 30 Jahre alt.',
        russianTranslation: 'Мне 30 лет.',
        isCorrect: false,
      },
      {
        id: 'opt-3',
        germanText: 'Ich komme aus Moskau.',
        russianTranslation: 'Я из Москвы.',
        isCorrect: true,
      },
    ],
    explanation: {
      german: 'Die Frage "Woher kommst du?" fragt nach dem Herkunftsort. Die richtige Antwort ist "Ich komme aus Moskau."',
      russian: 'Вопрос "Откуда ты?" спрашивает место происхождения. Правильный ответ: "Я из Москвы."',
    },
    timeLimit: 30,
  },
  {
    id: 'a1-3',
    level: 'A1',
    type: 'writing',
    germanText: 'Schreibe einen Satz: "Mein Name ist ___"',
    russianTranslation: 'Напишите предложение: "Мое имя ___"',
    correctAnswer: 'Mein Name ist',
    explanation: {
      german: 'Dies ist eine einfache Satzstruktur zum Vorstellen des Namens.',
      russian: 'Это простая структура предложения для представления имени.',
    },
    timeLimit: 60,
  },
];

// A2 Prüfungsfragen - Elementar
export const examQuestionsA2: ExamQuestion[] = [
  {
    id: 'a2-1',
    level: 'A2',
    type: 'reading',
    germanText: 'Ich arbeite in einem Büro und mein Job ist sehr interessant. Ich arbeite mit Computern und treffe viele Leute. Was ist der Beruf?',
    russianTranslation: 'Я работаю в офисе, и моя работа очень интересная. Я работаю с компьютерами и встречаю много людей. Какая это профессия?',
    options: [
      {
        id: 'opt-1',
        germanText: 'Lehrer',
        russianTranslation: 'Учитель',
        isCorrect: false,
      },
      {
        id: 'opt-2',
        germanText: 'Büroarbeiter / Angestellter',
        russianTranslation: 'Офисный работник / Служащий',
        isCorrect: true,
      },
      {
        id: 'opt-3',
        germanText: 'Arzt',
        russianTranslation: 'Врач',
        isCorrect: false,
      },
    ],
    explanation: {
      german: 'Der Text beschreibt jemanden, der in einem Büro mit Computern arbeitet. Das ist ein Büroarbeiter.',
      russian: 'Текст описывает человека, который работает в офисе с компьютерами. Это офисный работник.',
    },
    timeLimit: 45,
  },
  {
    id: 'a2-2',
    level: 'A2',
    type: 'matching',
    germanText: 'Verbinde die Wörter mit den richtigen Definitionen',
    russianTranslation: 'Соедините слова с правильными определениями',
    options: [
      {
        id: 'opt-1',
        germanText: 'Tisch',
        russianTranslation: 'Стол',
        isCorrect: true,
      },
      {
        id: 'opt-2',
        germanText: 'Stuhl',
        russianTranslation: 'Стул',
        isCorrect: true,
      },
      {
        id: 'opt-3',
        germanText: 'Fenster',
        russianTranslation: 'Окно',
        isCorrect: true,
      },
    ],
    timeLimit: 60,
  },
];

// B1 Prüfungsfragen - Mittelstufe
export const examQuestionsB1: ExamQuestion[] = [
  {
    id: 'b1-1',
    level: 'B1',
    type: 'reading',
    germanText: 'Die Globalisierung hat viele positive und negative Auswirkungen auf die Gesellschaft. Einerseits ermöglicht sie den Austausch von Ideen und Kulturen. Andererseits führt sie zu wirtschaftlichen Ungleichheiten. Was ist ein negativer Effekt der Globalisierung nach dem Text?',
    russianTranslation: 'Глобализация имеет множество положительных и отрицательных последствий для общества. С одной стороны, она позволяет обмениваться идеями и культурой. С другой стороны, она приводит к экономическому неравенству. Какой отрицательный эффект глобализации упоминается в тексте?',
    options: [
      {
        id: 'opt-1',
        germanText: 'Austausch von Ideen',
        russianTranslation: 'Обмен идеями',
        isCorrect: false,
      },
      {
        id: 'opt-2',
        germanText: 'Wirtschaftliche Ungleichheiten',
        russianTranslation: 'Экономическое неравенство',
        isCorrect: true,
      },
      {
        id: 'opt-3',
        germanText: 'Kulturelle Vielfalt',
        russianTranslation: 'Культурное разнообразие',
        isCorrect: false,
      },
    ],
    explanation: {
      german: 'Der Text erwähnt, dass die Globalisierung zu wirtschaftlichen Ungleichheiten führt, was ein negativer Effekt ist.',
      russian: 'Текст упоминает, что глобализация приводит к экономическому неравенству, что является отрицательным эффектом.',
    },
    timeLimit: 90,
  },
  {
    id: 'b1-2',
    level: 'B1',
    type: 'writing',
    germanText: 'Schreibe einen kurzen Absatz (3-4 Sätze) über deine Lieblingsbeschäftigung und warum du sie magst.',
    russianTranslation: 'Напишите короткий абзац (3-4 предложения) о вашем любимом занятии и почему вам оно нравится.',
    correctAnswer: '',
    explanation: {
      german: 'Dies ist eine offene Schreibaufgabe. Achte auf Grammatik, Vokabeln und Satzstruktur.',
      russian: 'Это открытое письменное задание. Обратите внимание на грамматику, словарный запас и структуру предложений.',
    },
    timeLimit: 180,
  },
];

// B2 Prüfungsfragen - Oberstufe
export const examQuestionsB2: ExamQuestion[] = [
  {
    id: 'b2-1',
    level: 'B2',
    type: 'reading',
    germanText: 'Die künstliche Intelligenz revolutioniert verschiedene Bereiche der Gesellschaft. Während sie enorme Potenziale bietet, wirft sie auch ethische Fragen auf. Insbesondere die Frage der Datensicherheit und des Datenschutzes bleibt kontrovers. Welche Herausforderung wird im Text erwähnt?',
    russianTranslation: 'Искусственный интеллект революционизирует различные области общества. Хотя он предлагает огромный потенциал, он также поднимает этические вопросы. В частности, вопрос безопасности данных и защиты данных остается спорным. Какой вызов упоминается в тексте?',
    options: [
      {
        id: 'opt-1',
        germanText: 'Mangel an technologischen Ressourcen',
        russianTranslation: 'Нехватка технологических ресурсов',
        isCorrect: false,
      },
      {
        id: 'opt-2',
        germanText: 'Datensicherheit und Datenschutz',
        russianTranslation: 'Безопасность данных и защита данных',
        isCorrect: true,
      },
      {
        id: 'opt-3',
        germanText: 'Unzureichende Bildung',
        russianTranslation: 'Недостаточное образование',
        isCorrect: false,
      },
    ],
    explanation: {
      german: 'Der Text erwähnt explizit, dass die Frage der Datensicherheit und des Datenschutzes kontrovers bleibt.',
      russian: 'Текст явно упоминает, что вопрос безопасности данных и защиты данных остается спорным.',
    },
    timeLimit: 120,
  },
  {
    id: 'b2-2',
    level: 'B2',
    type: 'writing',
    germanText: 'Schreibe einen Essay (5-6 Sätze) über die Vor- und Nachteile der Technologie in der modernen Welt.',
    russianTranslation: 'Напишите эссе (5-6 предложений) о преимуществах и недостатках технологии в современном мире.',
    correctAnswer: '',
    explanation: {
      german: 'Dies ist eine komplexe Schreibaufgabe. Verwende komplexe Satzstrukturen und argumentiere überzeugend.',
      russian: 'Это сложное письменное задание. Используйте сложные структуры предложений и убедительно аргументируйте.',
    },
    timeLimit: 300,
  },
];

export const allExamQuestions = [
  ...examQuestionsA1,
  ...examQuestionsA2,
  ...examQuestionsB1,
  ...examQuestionsB2,
];

export function getExamQuestionsByLevel(level: 'A1' | 'A2' | 'B1' | 'B2'): ExamQuestion[] {
  return allExamQuestions.filter(q => q.level === level);
}
