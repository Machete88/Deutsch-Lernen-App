import React, { createContext, useContext, useState, useCallback } from 'react';
import { ExamQuestion, getExamQuestionsByLevel } from './exam-data-extended';

interface ExamSession {
  level: 'A1' | 'A2' | 'B1' | 'B2';
  questions: ExamQuestion[];
  currentQuestionIndex: number;
  answers: Map<string, string>;
  score: number;
  isComplete: boolean;
  startTime: number;
  endTime?: number;
}

interface ExamContextType {
  session: ExamSession | null;
  showTranslation: boolean;
  toggleTranslation: () => void;
  startExam: (level: 'A1' | 'A2' | 'B1' | 'B2') => void;
  answerQuestion: (questionId: string, answer: string) => void;
  nextQuestion: () => void;
  previousQuestion: () => void;
  completeExam: () => void;
  getCurrentQuestion: () => ExamQuestion | null;
  getProgress: () => { current: number; total: number };
  resetExam: () => void;
}

const ExamContext = createContext<ExamContextType | undefined>(undefined);

export function ExamProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<ExamSession | null>(null);
  const [showTranslation, setShowTranslation] = useState(false);

  const startExam = useCallback((level: 'A1' | 'A2' | 'B1' | 'B2') => {
    const questions = getExamQuestionsByLevel(level);
    setSession({
      level,
      questions,
      currentQuestionIndex: 0,
      answers: new Map(),
      score: 0,
      isComplete: false,
      startTime: Date.now(),
    });
    setShowTranslation(false);
  }, []);

  const answerQuestion = useCallback((questionId: string, answer: string) => {
    if (!session) return;

    const newAnswers = new Map(session.answers);
    newAnswers.set(questionId, answer);

    // Berechne Score
    const currentQuestion = session.questions[session.currentQuestionIndex];
    let newScore = session.score;

    if (currentQuestion.type === 'multiple-choice' || currentQuestion.type === 'reading') {
      const option = currentQuestion.options?.find(opt => opt.id === answer);
      if (option?.isCorrect) {
        newScore += 1;
      }
    }

    setSession(prev => prev ? {
      ...prev,
      answers: newAnswers,
      score: newScore,
    } : null);
  }, [session]);

  const nextQuestion = useCallback(() => {
    if (!session || session.currentQuestionIndex >= session.questions.length - 1) return;
    setSession(prev => prev ? {
      ...prev,
      currentQuestionIndex: prev.currentQuestionIndex + 1,
    } : null);
  }, [session]);

  const previousQuestion = useCallback(() => {
    if (!session || session.currentQuestionIndex <= 0) return;
    setSession(prev => prev ? {
      ...prev,
      currentQuestionIndex: prev.currentQuestionIndex - 1,
    } : null);
  }, [session]);

  const completeExam = useCallback(() => {
    if (!session) return;
    setSession(prev => prev ? {
      ...prev,
      isComplete: true,
      endTime: Date.now(),
    } : null);
  }, [session]);

  const getCurrentQuestion = useCallback((): ExamQuestion | null => {
    if (!session || session.currentQuestionIndex >= session.questions.length) {
      return null;
    }
    return session.questions[session.currentQuestionIndex];
  }, [session]);

  const getProgress = useCallback((): { current: number; total: number } => {
    if (!session) return { current: 0, total: 0 };
    return {
      current: session.currentQuestionIndex + 1,
      total: session.questions.length,
    };
  }, [session]);

  const resetExam = useCallback(() => {
    setSession(null);
    setShowTranslation(false);
  }, []);

  const toggleTranslation = useCallback(() => {
    setShowTranslation(prev => !prev);
  }, []);

  return (
    <ExamContext.Provider value={{
      session,
      showTranslation,
      toggleTranslation,
      startExam,
      answerQuestion,
      nextQuestion,
      previousQuestion,
      completeExam,
      getCurrentQuestion,
      getProgress,
      resetExam,
    }}>
      {children}
    </ExamContext.Provider>
  );
}

export function useExtendedExam(): ExamContextType {
  const context = useContext(ExamContext);
  if (!context) {
    throw new Error('useExtendedExam must be used within ExamProvider');
  }
  return context;
}
