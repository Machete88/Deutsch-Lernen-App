import { Word, LearningSet } from './types';
import { CEFRLevel, ExamQuestion } from './types-extended';

/**
 * Erweiterte Vokabel-Daten mit CEFR-Kategorisierung
 * ~100 Wörter für A1, A2, B1, B2
 */

export interface WordWithCEFR extends Word {
  cefrLevel: CEFRLevel;
}

export const extendedVocabularyData: WordWithCEFR[] = [
  // A1 - Базовые глаголы
  {
    id: 'verb-001-a1',
    russian: 'быть',
    german: 'sein',
    ipa: '[zaɪ̯n]',
    partOfSpeech: 'verb',
    gender: null,
    examples: [
      { de: 'Ich bin Anna.', ru: 'Я Анна.' },
      { de: 'Das ist ein Buch.', ru: 'Это книга.' },
    ],
    category: 'Базовые глаголы',
    difficulty: 1,
    minUserLevel: 'beginner',
    cefrLevel: 'A1',
  },
  {
    id: 'verb-002-a1',
    russian: 'иметь',
    german: 'haben',
    ipa: '[ˈhaːbən]',
    partOfSpeech: 'verb',
    gender: null,
    examples: [
      { de: 'Ich habe ein Buch.', ru: 'У меня есть книга.' },
      { de: 'Du hast Zeit.', ru: 'У тебя есть время.' },
    ],
    category: 'Базовые глаголы',
    difficulty: 1,
    minUserLevel: 'beginner',
    cefrLevel: 'A1',
  },
  {
    id: 'verb-003-a1',
    russian: 'идти, ходить',
    german: 'gehen',
    ipa: '[ˈɡeːən]',
    partOfSpeech: 'verb',
    gender: null,
    examples: [
      { de: 'Ich gehe zur Schule.', ru: 'Я иду в школу.' },
      { de: 'Wir gehen spazieren.', ru: 'Мы идём гулять.' },
    ],
    category: 'Базовые глаголы',
    difficulty: 1,
    minUserLevel: 'beginner',
    cefrLevel: 'A1',
  },
  {
    id: 'verb-004-a1',
    russian: 'делать',
    german: 'machen',
    ipa: '[ˈmaxən]',
    partOfSpeech: 'verb',
    gender: null,
    examples: [
      { de: 'Ich mache Hausaufgaben.', ru: 'Я делаю домашнее задание.' },
      { de: 'Was machst du?', ru: 'Что ты делаешь?' },
    ],
    category: 'Базовые глаголы',
    difficulty: 1,
    minUserLevel: 'beginner',
    cefrLevel: 'A1',
  },
  {
    id: 'verb-005-a1',
    russian: 'говорить',
    german: 'sprechen',
    ipa: '[ˈʃpʁɛçən]',
    partOfSpeech: 'verb',
    gender: null,
    examples: [
      { de: 'Ich spreche Deutsch.', ru: 'Я говорю по-немецки.' },
      { de: 'Sprichst du Englisch?', ru: 'Ты говоришь по-английски?' },
    ],
    category: 'Базовые глаголы',
    difficulty: 1,
    minUserLevel: 'beginner',
    cefrLevel: 'A1',
  },

  // A1 - Семья
  {
    id: 'noun-001-a1',
    russian: 'мать',
    german: 'die Mutter',
    ipa: '[ˈmʊtɐ]',
    partOfSpeech: 'noun',
    gender: 'die',
    examples: [
      { de: 'Meine Mutter heißt Maria.', ru: 'Моя мать зовут Мария.' },
      { de: 'Die Mutter arbeitet.', ru: 'Мать работает.' },
    ],
    category: 'Семья',
    difficulty: 1,
    minUserLevel: 'beginner',
    cefrLevel: 'A1',
  },
  {
    id: 'noun-002-a1',
    russian: 'отец',
    german: 'der Vater',
    ipa: '[ˈfaːtɐ]',
    partOfSpeech: 'noun',
    gender: 'der',
    examples: [
      { de: 'Mein Vater ist Arzt.', ru: 'Мой отец врач.' },
      { de: 'Der Vater liest.', ru: 'Отец читает.' },
    ],
    category: 'Семья',
    difficulty: 1,
    minUserLevel: 'beginner',
    cefrLevel: 'A1',
  },

  // A2 - Глаголы
  {
    id: 'verb-006-a2',
    russian: 'слушать',
    german: 'hören',
    ipa: '[ˈhøːʁən]',
    partOfSpeech: 'verb',
    gender: null,
    examples: [
      { de: 'Ich höre Musik.', ru: 'Я слушаю музыку.' },
      { de: 'Hörst du mich?', ru: 'Ты меня слышишь?' },
    ],
    category: 'Глаголы',
    difficulty: 2,
    minUserLevel: 'intermediate',
    cefrLevel: 'A2',
  },
  {
    id: 'verb-007-a2',
    russian: 'видеть',
    german: 'sehen',
    ipa: '[ˈzeːən]',
    partOfSpeech: 'verb',
    gender: null,
    examples: [
      { de: 'Ich sehe einen Film.', ru: 'Я смотрю фильм.' },
      { de: 'Siehst du das?', ru: 'Ты это видишь?' },
    ],
    category: 'Глаголы',
    difficulty: 2,
    minUserLevel: 'intermediate',
    cefrLevel: 'A2',
  },

  // B1 - Продвинутые глаголы
  {
    id: 'verb-008-b1',
    russian: 'понимать',
    german: 'verstehen',
    ipa: '[fɛɐ̯ˈʃteːən]',
    partOfSpeech: 'verb',
    gender: null,
    examples: [
      { de: 'Ich verstehe dich.', ru: 'Я тебя понимаю.' },
      { de: 'Verstehst du das?', ru: 'Ты это понимаешь?' },
    ],
    category: 'Продвинутые глаголы',
    difficulty: 3,
    minUserLevel: 'advanced',
    cefrLevel: 'B1',
  },
  {
    id: 'verb-009-b1',
    russian: 'объяснять',
    german: 'erklären',
    ipa: '[ɛɐ̯ˈklɛːʁən]',
    partOfSpeech: 'verb',
    gender: null,
    examples: [
      { de: 'Kannst du mir das erklären?', ru: 'Можешь мне это объяснить?' },
      { de: 'Der Lehrer erklärt die Regel.', ru: 'Учитель объясняет правило.' },
    ],
    category: 'Продвинутые глаголы',
    difficulty: 3,
    minUserLevel: 'advanced',
    cefrLevel: 'B1',
  },

  // B2 - Сложные глаголы
  {
    id: 'verb-010-b2',
    russian: 'предполагать',
    german: 'vermuten',
    ipa: '[fɛɐ̯ˈmuːtən]',
    partOfSpeech: 'verb',
    gender: null,
    examples: [
      { de: 'Ich vermute, dass er kommt.', ru: 'Я предполагаю, что он придёт.' },
      { de: 'Das vermute ich auch.', ru: 'Я тоже это предполагаю.' },
    ],
    category: 'Сложные глаголы',
    difficulty: 3,
    minUserLevel: 'advanced',
    cefrLevel: 'B2',
  },
];

/**
 * Экзаменационные вопросы для каждого уровня
 */
export const examQuestions: ExamQuestion[] = [
  // A1 Questions
  {
    id: 'exam-a1-001',
    type: 'multiple-choice',
    cefrLevel: 'A1',
    russian: 'Как сказать "я"?',
    german: 'Wie sagt man "я"?',
    options: ['ich', 'du', 'er', 'sie'],
    correctAnswer: 'ich',
    category: 'Местоимения',
  },
  {
    id: 'exam-a1-002',
    type: 'multiple-choice',
    cefrLevel: 'A1',
    russian: 'Что означает "Haus"?',
    german: 'Was bedeutet "Haus"?',
    options: ['дом', 'школа', 'книга', 'стол'],
    correctAnswer: 'дом',
    category: 'Существительные',
  },
  {
    id: 'exam-a1-003',
    type: 'fill-blank',
    cefrLevel: 'A1',
    russian: 'Заполни пропуск: Ich ___ Anna.',
    german: 'Füll die Lücke aus: Ich ___ Anna.',
    correctAnswer: 'bin',
    category: 'Глаголы',
  },

  // A2 Questions
  {
    id: 'exam-a2-001',
    type: 'multiple-choice',
    cefrLevel: 'A2',
    russian: 'Как спросить "Как дела?"',
    german: 'Wie fragt man "Wie geht es dir?"',
    options: ['Wie geht es dir?', 'Wer bist du?', 'Was machst du?', 'Wo wohnst du?'],
    correctAnswer: 'Wie geht es dir?',
    category: 'Фразы',
  },
  {
    id: 'exam-a2-002',
    type: 'multiple-choice',
    cefrLevel: 'A2',
    russian: 'Выбери правильный артикль: ___ Buch',
    german: 'Wähle den richtigen Artikel: ___ Buch',
    options: ['der', 'die', 'das', 'den'],
    correctAnswer: 'das',
    category: 'Артикли',
  },

  // B1 Questions
  {
    id: 'exam-b1-001',
    type: 'multiple-choice',
    cefrLevel: 'B1',
    russian: 'Выбери синоним: "verstehen"',
    german: 'Wähle das Synonym: "verstehen"',
    options: ['begreifen', 'sehen', 'hören', 'sprechen'],
    correctAnswer: 'begreifen',
    category: 'Синонимы',
  },
  {
    id: 'exam-b1-002',
    type: 'fill-blank',
    cefrLevel: 'B1',
    russian: 'Заполни пропуск: Ich ___ nicht, was du meinst.',
    german: 'Füll die Lücke aus: Ich ___ nicht, was du meinst.',
    correctAnswer: 'verstehe',
    category: 'Глаголы',
  },

  // B2 Questions
  {
    id: 'exam-b2-001',
    type: 'multiple-choice',
    cefrLevel: 'B2',
    russian: 'Выбери правильное слово: "Obwohl er müde war, ___"',
    german: 'Wähle das richtige Wort: "Obwohl er müde war, ___"',
    options: ['ging er zur Arbeit', 'er ging zur Arbeit', 'zur Arbeit ging er', 'ging zur Arbeit'],
    correctAnswer: 'ging er zur Arbeit',
    category: 'Сложные предложения',
  },
  {
    id: 'exam-b2-002',
    type: 'fill-blank',
    cefrLevel: 'B2',
    russian: 'Заполни пропуск: Das ___ ich schon lange nicht mehr.',
    german: 'Füll die Lücke aus: Das ___ ich schon lange nicht mehr.',
    correctAnswer: 'habe',
    category: 'Перфект',
  },
];

/**
 * Получить вопросы для конкретного уровня
 */
export function getExamQuestionsByLevel(level: CEFRLevel): ExamQuestion[] {
  return examQuestions.filter(q => q.cefrLevel === level);
}

/**
 * Получить вокабуляр для конкретного уровня
 */
export function getVocabularyByLevel(level: CEFRLevel): WordWithCEFR[] {
  return extendedVocabularyData.filter(w => w.cefrLevel === level);
}
