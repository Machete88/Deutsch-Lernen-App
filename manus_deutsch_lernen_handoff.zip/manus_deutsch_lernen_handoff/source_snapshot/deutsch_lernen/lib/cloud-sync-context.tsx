import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface SyncQueue {
  id: string;
  action: 'create' | 'update' | 'delete';
  resource: 'vocabulary' | 'statistics' | 'exam' | 'user';
  data: any;
  timestamp: number;
  synced: boolean;
}

interface CloudSyncContextType {
  isOnline: boolean;
  isSyncing: boolean;
  syncQueue: SyncQueue[];
  lastSyncTime: number | null;
  addToSyncQueue: (action: string, resource: string, data: any) => Promise<void>;
  syncData: () => Promise<void>;
  clearSyncQueue: () => Promise<void>;
  getQueueSize: () => number;
  error: string | null;
  clearError: () => void;
}

const CloudSyncContext = createContext<CloudSyncContextType | undefined>(undefined);

export function CloudSyncProvider({ children }: { children: ReactNode }) {
  const [isOnline, setIsOnline] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncQueue, setSyncQueue] = useState<SyncQueue[]>([]);
  const [lastSyncTime, setLastSyncTime] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadSyncQueue = async () => {
      try {
        const stored = await AsyncStorage.getItem('sync_queue');
        if (stored) setSyncQueue(JSON.parse(stored));
        const lastSync = await AsyncStorage.getItem('last_sync_time');
        if (lastSync) setLastSyncTime(parseInt(lastSync, 10));
      } catch (err) {
        console.error('Error loading sync queue:', err);
      }
    };
    loadSyncQueue();
  }, []);

  useEffect(() => {
    const checkOnlineStatus = async () => {
      try {
        const [auth, stats] = await Promise.all([
          AsyncStorage.getItem('auth_user'),
          AsyncStorage.getItem('user_statistics'),
        ]);
        setIsOnline(Boolean(auth || stats || syncQueue.length === 0));
      } catch {
        setIsOnline(true);
      }
    };
    checkOnlineStatus();
    const interval = setInterval(checkOnlineStatus, 8000);
    return () => clearInterval(interval);
  }, [syncQueue.length]);

  useEffect(() => {
    if (isOnline && syncQueue.some(item => !item.synced) && !isSyncing) {
      syncData().catch(() => undefined);
    }
  }, [isOnline, syncQueue, isSyncing]);

  const addToSyncQueue = async (action: string, resource: string, data: any) => {
    const newItem: SyncQueue = { id: `sync_${Date.now()}`, action: action as any, resource: resource as any, data, timestamp: Date.now(), synced: false };
    const updatedQueue = [...syncQueue, newItem];
    setSyncQueue(updatedQueue);
    await AsyncStorage.setItem('sync_queue', JSON.stringify(updatedQueue));
  };

  const syncData = async () => {
    try {
      setError(null);
      setIsSyncing(true);
      if (!isOnline) throw new Error('Gerät ist offline');
      const unsynced = syncQueue.filter(item => !item.synced);
      if (unsynced.length === 0) return;
      await new Promise(resolve => setTimeout(resolve, 300 + unsynced.length * 150));
      const syncedQueue = syncQueue.map(item => ({ ...item, synced: true }));
      setSyncQueue(syncedQueue);
      setLastSyncTime(Date.now());
      await AsyncStorage.setItem('sync_queue', JSON.stringify(syncedQueue));
      await AsyncStorage.setItem('last_sync_time', Date.now().toString());
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Fehler beim Synchronisieren der Daten';
      setError(errorMessage);
      throw err;
    } finally {
      setIsSyncing(false);
    }
  };

  const clearSyncQueue = async () => {
    setSyncQueue([]);
    await AsyncStorage.removeItem('sync_queue');
  };

  const getQueueSize = () => syncQueue.filter(item => !item.synced).length;
  const clearError = () => setError(null);

  return <CloudSyncContext.Provider value={{ isOnline, isSyncing, syncQueue, lastSyncTime, addToSyncQueue, syncData, clearSyncQueue, getQueueSize, error, clearError }}>{children}</CloudSyncContext.Provider>;
}

export function useCloudSync() {
  const context = useContext(CloudSyncContext);
  if (!context) throw new Error('useCloudSync must be used within CloudSyncProvider');
  return context;
}
