import { describe, it, expect } from 'vitest';
import { calculateNextReview, getQualityScore, recommendDifficulty, getCardsForReview, calculateStats, type SM2Card } from './sm2-optimizer';

describe('Social Context', () => {
  it('should initialize friends list', () => {
    const friends = [];
    expect(friends.length).toBe(0);
  });

  it('should add friend request', () => {
    const friendRequests: any[] = [];
    friendRequests.push({ id: 'user1', username: 'John' });

    expect(friendRequests.length).toBe(1);
    expect(friendRequests[0].username).toBe('John');
  });

  it('should accept friend request', () => {
    const friendRequests = [{ id: 'user1', isFriend: false }];
    const friends: any[] = [];

    const request = friendRequests[0];
    friends.push({ ...request, isFriend: true });

    expect(friends[0].isFriend).toBe(true);
  });

  it('should create learning group', () => {
    const groups = [];
    const newGroup = { id: 'group1', name: 'Deutsch Anfänger', members: [] };
    groups.push(newGroup);

    expect(groups.length).toBe(1);
    expect(groups[0].name).toBe('Deutsch Anfänger');
  });

  it('should join learning group', () => {
    const group = { id: 'group1', isJoined: false };
    group.isJoined = true;

    expect(group.isJoined).toBe(true);
  });
});

describe('Adaptive Learning Context', () => {
  it('should generate learning path for beginner', () => {
    const path = {
      id: 'path_basics',
      name: 'Grundlagen Deutsch',
      difficulty: 'easy' as const,
      progress: 0,
    };

    expect(path.difficulty).toBe('easy');
    expect(path.progress).toBe(0);
  });

  it('should get recommendations based on accuracy', () => {
    const stats = { averageAccuracy: 50 };
    const recs: any[] = [];

    if (stats.averageAccuracy < 60) {
      recs.push({ type: 'review', priority: 'high' });
    }

    expect(recs.length).toBe(1);
    expect(recs[0].priority).toBe('high');
  });

  it('should adjust difficulty based on performance', () => {
    let difficulty: 'easy' | 'medium' | 'hard' = 'easy';
    const performance = 95;

    if (performance > 90) {
      difficulty = 'medium';
    }

    expect(difficulty).toBe('medium');
  });

  it('should update learning path progress', () => {
    const path = { id: 'path1', progress: 0 };
    path.progress = 50;

    expect(path.progress).toBe(50);
  });
});

describe('SM-2 Optimizer', () => {
  it('should calculate quality score for correct answer', () => {
    const quality = getQualityScore(true, 5000, 0.9);
    expect(quality).toBeGreaterThanOrEqual(4);
  });

  it('should calculate quality score for incorrect answer', () => {
    const quality = getQualityScore(false, 5000, 0.5);
    expect(quality).toBe(1);
  });

  it('should recommend easy difficulty for low performance', () => {
    const card: SM2Card = {
      id: '1',
      easeFactor: 2.5,
      interval: 1,
      repetitions: 1,
      nextReviewDate: Date.now(),
      difficulty: 'easy' as const,
      lastReviewDate: Date.now(),
    };

    const recentPerformance = [2, 2, 3];
    const difficulty = recommendDifficulty(card, recentPerformance);

    expect(difficulty).toBe('easy');
  });

  it('should recommend hard difficulty for high performance', () => {
    const card: SM2Card = {
      id: '1',
      easeFactor: 2.5,
      interval: 1,
      repetitions: 1,
      nextReviewDate: Date.now(),
      difficulty: 'easy' as const,
      lastReviewDate: Date.now(),
    };

    const recentPerformance = [5, 5, 4.5];
    const difficulty = recommendDifficulty(card, recentPerformance);

    expect(difficulty).toBe('hard');
  });

  it('should calculate next review for correct answer', () => {
    const card: SM2Card = {
      id: '1',
      easeFactor: 2.5,
      interval: 1,
      repetitions: 0,
      nextReviewDate: Date.now(),
      difficulty: 'easy' as const,
      lastReviewDate: Date.now(),
    };

    const updated = calculateNextReview(card, 5, 'medium');

    expect(updated.repetitions).toBe(1);
    expect(updated.interval).toBeGreaterThan(0);
  });

  it('should reset interval for incorrect answer', () => {
    const card: SM2Card = {
      id: '1',
      easeFactor: 2.5,
      interval: 10,
      repetitions: 5,
      nextReviewDate: Date.now(),
      difficulty: 'easy' as const,
      lastReviewDate: Date.now(),
    };

    const updated = calculateNextReview(card, 1, 'medium');

    expect(updated.interval).toBe(1);
    expect(updated.repetitions).toBe(0);
  });

  it('should get cards for review', () => {
    const now = Date.now();
    const cards: SM2Card[] = [
      {
        id: '1',
        easeFactor: 2.5,
        interval: 1,
        repetitions: 1,
        nextReviewDate: now - 1000,
        difficulty: 'easy' as const,
        lastReviewDate: now,
      },
      {
        id: '2',
        easeFactor: 2.5,
        interval: 1,
        repetitions: 1,
        nextReviewDate: now + 86400000,
        difficulty: 'easy' as const,
        lastReviewDate: now,
      },
    ];

    const reviewCards = getCardsForReview(cards);
    expect(reviewCards.length).toBe(1);
    expect(reviewCards[0].id).toBe('1');
  });

  it('should calculate learning statistics', () => {
    const cards: SM2Card[] = [
      {
        id: '1',
        easeFactor: 2.5,
        interval: 1,
        repetitions: 5,
        nextReviewDate: Date.now(),
        difficulty: 'medium',
        lastReviewDate: Date.now(),
      },
      {
        id: '2',
        easeFactor: 2.5,
        interval: 1,
        repetitions: 1,
        nextReviewDate: Date.now(),
        difficulty: 'medium',
        lastReviewDate: Date.now(),
      },
    ];

    const stats = calculateStats(cards);

    expect(stats.totalCards).toBe(2);
    expect(stats.learnedCards).toBe(1);
    expect(parseFloat(stats.learningProgress)).toBe(50);
  });
});
