import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface OfflineContent {
  id: string;
  type: 'vocabulary' | 'exam' | 'lessons';
  title: string;
  size: number;
  downloaded: boolean;
  downloadedAt?: number;
}

interface OfflineContentContextType {
  offlineContent: OfflineContent[];
  isDownloading: boolean;
  downloadProgress: number;
  totalSize: number;
  downloadedSize: number;
  downloadContent: (id: string) => Promise<void>;
  deleteContent: (id: string) => Promise<void>;
  isContentAvailable: (type: string) => boolean;
  getAvailableSpace: () => number;
  isLoading: boolean;
  error: string | null;
  clearError: () => void;
}

const OfflineContentContext = createContext<OfflineContentContextType | undefined>(undefined);
const DEFAULT_CONTENT: OfflineContent[] = [
  { id: 'vocabulary_core', type: 'vocabulary', title: 'Grundwortschatz', size: 6, downloaded: false },
  { id: 'exam_a1', type: 'exam', title: 'A1 Probeprüfung', size: 2, downloaded: false },
  { id: 'exam_a2', type: 'exam', title: 'A2 Probeprüfung', size: 3, downloaded: false },
  { id: 'lessons_grammar', type: 'lessons', title: 'Grammatik-Kurzlektionen', size: 4, downloaded: false },
];

export function OfflineContentProvider({ children }: { children: ReactNode }) {
  const [offlineContent, setOfflineContent] = useState<OfflineContent[]>(DEFAULT_CONTENT);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadOfflineContent = async () => {
      try {
        const stored = await AsyncStorage.getItem('offline_content');
        if (stored) setOfflineContent(JSON.parse(stored));
      } catch (err) {
        console.error('Error loading offline content:', err);
      } finally {
        setIsLoading(false);
      }
    };
    loadOfflineContent();
  }, []);

  const downloadContent = async (id: string) => {
    try {
      setError(null);
      setIsDownloading(true);
      const contentToDownload = offlineContent.find(c => c.id === id);
      if (!contentToDownload) throw new Error('Inhalt nicht gefunden');
      for (let progress = 0; progress <= 100; progress += 20) {
        setDownloadProgress(progress);
        await new Promise(resolve => setTimeout(resolve, 120));
      }
      const updatedContent = offlineContent.map(c => c.id === id ? { ...c, downloaded: true, downloadedAt: Date.now() } : c);
      setOfflineContent(updatedContent);
      await AsyncStorage.setItem('offline_content', JSON.stringify(updatedContent));
      await AsyncStorage.setItem(`offline_snapshot_${id}`, JSON.stringify({ id, downloadedAt: Date.now(), note: `Offline-Paket ${contentToDownload.title}` }));
      setDownloadProgress(0);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Fehler beim Herunterladen von Inhalten';
      setError(errorMessage);
      throw err;
    } finally {
      setIsDownloading(false);
    }
  };

  const deleteContent = async (id: string) => {
    const updatedContent = offlineContent.map(c => c.id === id ? { ...c, downloaded: false, downloadedAt: undefined } : c);
    setOfflineContent(updatedContent);
    await AsyncStorage.setItem('offline_content', JSON.stringify(updatedContent));
    await AsyncStorage.removeItem(`offline_snapshot_${id}`);
  };

  const isContentAvailable = (type: string) => offlineContent.some(c => c.id === type && c.downloaded);
  const getAvailableSpace = () => 100 - offlineContent.filter(c => c.downloaded).reduce((sum, c) => sum + c.size, 0);
  const totalSize = offlineContent.reduce((sum, c) => sum + c.size, 0);
  const downloadedSize = offlineContent.filter(c => c.downloaded).reduce((sum, c) => sum + c.size, 0);
  const clearError = () => setError(null);

  return <OfflineContentContext.Provider value={{ offlineContent, isDownloading, downloadProgress, totalSize, downloadedSize, downloadContent, deleteContent, isContentAvailable, getAvailableSpace, isLoading, error, clearError }}>{children}</OfflineContentContext.Provider>;
}

export function useOfflineContent() {
  const context = useContext(OfflineContentContext);
  if (!context) throw new Error('useOfflineContent must be used within OfflineContentProvider');
  return context;
}
