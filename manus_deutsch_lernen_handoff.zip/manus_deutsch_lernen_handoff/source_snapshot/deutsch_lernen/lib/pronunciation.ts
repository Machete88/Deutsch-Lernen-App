export interface PronunciationAnalysis {
  expected: string;
  actual: string;
  similarity: number;
  rating: 'excellent' | 'good' | 'fair' | 'needs-practice';
  feedback: string;
  tips: string[];
}

export interface PronunciationCoachResult extends PronunciationAnalysis {
  focusSounds: string[];
  rhythmTip: string;
  exercise: string;
  shadowingSteps: string[];
}

export function normalizePronunciationText(value: string): string {
  return value
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/ß/g, 'ss')
    .replace(/ä/g, 'ae')
    .replace(/ö/g, 'oe')
    .replace(/ü/g, 'ue')
    .replace(/[^a-z\s]/g, '')
    .trim();
}

function levenshtein(a: string, b: string): number {
  const rows = a.length + 1;
  const cols = b.length + 1;
  const matrix = Array.from({ length: rows }, () => Array(cols).fill(0));

  for (let i = 0; i < rows; i += 1) matrix[i][0] = i;
  for (let j = 0; j < cols; j += 1) matrix[0][j] = j;

  for (let i = 1; i < rows; i += 1) {
    for (let j = 1; j < cols; j += 1) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,
        matrix[i][j - 1] + 1,
        matrix[i - 1][j - 1] + cost,
      );
    }
  }

  return matrix[a.length][b.length];
}

function detectFocusSounds(word: string): string[] {
  const lower = word.toLowerCase();
  const focus: string[] = [];
  if (/(ch)/.test(lower)) focus.push('ch-Laut');
  if (/(sch)/.test(lower)) focus.push('sch-Laut');
  if (/(ei)/.test(lower)) focus.push('ei wie in "mein"');
  if (/(ie)/.test(lower)) focus.push('langes i wie in "vier"');
  if (/(eu|äu)/.test(lower)) focus.push('eu/äu');
  if (/(sp|st)/.test(lower)) focus.push('deutscher Anlaut in sp/st');
  if (/(r)/.test(lower)) focus.push('weiches deutsches r');
  if (/(z)/.test(lower)) focus.push('z wie ts');
  if (/(tsch)/.test(lower)) focus.push('tsch');
  return focus.length ? focus : ['klare Vokale'];
}

function buildExercise(word: string): string {
  const lower = word.toLowerCase();
  if (/(ch)/.test(lower)) return `Sprich "${word}" in drei Schritten: erst nur "ch", dann die letzte Silbe, dann das ganze Wort.`;
  if (/(ei)/.test(lower)) return `Dehne bei "${word}" den Doppellaut "ei" leicht und sprich danach den Rest des Wortes klar aus.`;
  if (/(ie)/.test(lower)) return `Sprich bei "${word}" das "ie" bewusst lang und halte die Stimme kurz eine halbe Sekunde.`;
  if (/(r)/.test(lower)) return `Wiederhole "${word}" dreimal langsam und achte darauf, dass das deutsche r weich bleibt.`;
  return `Sprich "${word}" erst in Silben, dann zweimal im normalen Tempo.`;
}

function buildRhythmTip(word: string): string {
  const syllables = Math.max(1, (word.match(/[aeiouyäöü]+/gi) || []).length);
  if (syllables >= 3) return 'Teile das Wort in Silben und betone die stärkste Silbe etwas länger.';
  if (syllables === 2) return 'Sprich beide Silben klar getrennt und ziehe die betonte Silbe minimal länger.';
  return 'Sprich das kurze Wort deutlich und ohne zu verschlucken.';
}

export function analyzePronunciation(expectedInput: string, actualInput: string): PronunciationAnalysis {
  const expected = normalizePronunciationText(expectedInput);
  const actual = normalizePronunciationText(actualInput || '');

  if (!actual) {
    return {
      expected,
      actual,
      similarity: 0,
      rating: 'needs-practice',
      feedback: 'Noch keine erkennbare Aussprache vorhanden. Sprich das Wort langsam und deutlich nach.',
      tips: ['Höre dir das Wort einmal an.', 'Sprich in Silben nach.', 'Achte auf lange und kurze Vokale.'],
    };
  }

  const distance = levenshtein(expected, actual);
  const maxLen = Math.max(expected.length, actual.length, 1);
  const similarity = Math.max(0, Math.round((1 - distance / maxLen) * 100));

  let rating: PronunciationAnalysis['rating'] = 'needs-practice';
  let feedback = 'Übe das Wort noch einmal langsam und konzentriere dich auf die Wortenden.';
  if (similarity >= 92) {
    rating = 'excellent';
    feedback = 'Sehr stark ausgesprochen. Betonung und Form passen sehr gut.';
  } else if (similarity >= 78) {
    rating = 'good';
    feedback = 'Gute Aussprache. Kleine Abweichungen sind noch hörbar, aber das Wort ist gut verständlich.';
  } else if (similarity >= 60) {
    rating = 'fair';
    feedback = 'Fast richtig. Wiederhole das Wort langsam und achte besonders auf Vokale und Endungen.';
  }

  const tips = [
    'Höre zuerst die Modell-Aussprache.',
    'Sprich das Wort einmal in Silben und dann flüssig.',
    'Achte auf Vokallänge und die Endung.',
  ];

  return { expected, actual, similarity, rating, feedback, tips };
}

export function buildPronunciationCoach(word: string, attemptText?: string): PronunciationCoachResult {
  const analysis = analyzePronunciation(word, attemptText || '');
  return {
    ...analysis,
    focusSounds: detectFocusSounds(word),
    rhythmTip: buildRhythmTip(word),
    exercise: buildExercise(word),
    shadowingSteps: [
      `1. Höre "${word}" einmal komplett an.`,
      '2. Sprich das Wort langsam mit klaren Silben nach.',
      '3. Wiederhole es zweimal im natürlichen Tempo.',
      '4. Vergleiche deine Aufnahme mit dem Original.',
    ],
  };
}
