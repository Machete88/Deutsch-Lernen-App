/**
 * Optimierter SM-2 (Spaced Repetition) Algorithmus mit Schwierigkeitsgrad-Integration
 * Basierend auf: https://en.wikipedia.org/wiki/Spaced_repetition#SM-2
 */

export interface SM2Card {
  id: string;
  easeFactor: number; // EF (Ease Factor)
  interval: number; // Tage bis zur nächsten Wiederholung
  repetitions: number; // Anzahl der erfolgreichen Wiederholungen
  nextReviewDate: number; // Timestamp
  difficulty: 'easy' | 'medium' | 'hard';
  lastReviewDate: number;
}

export interface ReviewResponse {
  cardId: string;
  quality: number; // 0-5 (0=blackout, 5=perfect)
  difficulty: 'easy' | 'medium' | 'hard';
}

/**
 * Berechne die nächste Wiederholung basierend auf SM-2 Algorithmus
 */
export function calculateNextReview(
  card: SM2Card,
  quality: number,
  difficulty: 'easy' | 'medium' | 'hard'
): SM2Card {
  // Validiere Quality (0-5)
  const q = Math.max(0, Math.min(5, quality));

  // Schwierigkeitsgrad-Faktor (0.8 = easy, 1.0 = medium, 1.2 = hard)
  const difficultyFactor = getDifficultyFactor(difficulty);

  // Berechne neuen EF (Ease Factor)
  let newEF = card.easeFactor + 0.1 - (5 - q) * (0.08 + (5 - q) * 0.02);
  newEF = Math.max(1.3, newEF); // Minimum EF ist 1.3

  // Berechne neue Interval und Repetitions
  let newInterval = card.interval;
  let newRepetitions = card.repetitions;

  if (q < 3) {
    // Falsch beantwortet - zurücksetzen
    newInterval = 1;
    newRepetitions = 0;
  } else {
    // Richtig beantwortet
    newRepetitions += 1;

    if (newRepetitions === 1) {
      newInterval = 1;
    } else if (newRepetitions === 2) {
      newInterval = 3;
    } else {
      newInterval = Math.round(card.interval * newEF * difficultyFactor);
    }
  }

  // Berechne nächstes Review-Datum
  const nextReviewDate = Date.now() + newInterval * 24 * 60 * 60 * 1000;

  return {
    ...card,
    easeFactor: newEF,
    interval: newInterval,
    repetitions: newRepetitions,
    nextReviewDate,
    difficulty,
    lastReviewDate: Date.now(),
  };
}

/**
 * Gebe Schwierigkeitsgrad-Faktor basierend auf Schwierigkeit
 */
function getDifficultyFactor(difficulty: 'easy' | 'medium' | 'hard'): number {
  switch (difficulty) {
    case 'easy':
      return 0.8; // Schnellere Wiederholungen
    case 'medium':
      return 1.0; // Standard
    case 'hard':
      return 1.2; // Langsamere Wiederholungen
    default:
      return 1.0;
  }
}

/**
 * Gebe Qualität basierend auf Benutzer-Antwort
 */
export function getQualityScore(
  isCorrect: boolean,
  responseTime: number, // in Millisekunden
  confidence: number // 0-1
): number {
  let quality = 0;

  if (!isCorrect) {
    quality = 1; // Falsch
  } else if (responseTime > 10000) {
    quality = 2; // Richtig aber langsam
  } else if (confidence < 0.5) {
    quality = 3; // Richtig aber unsicher
  } else if (confidence < 0.8) {
    quality = 4; // Richtig und einigermaßen sicher
  } else {
    quality = 5; // Perfekt
  }

  return quality;
}

/**
 * Gebe empfohlene Schwierigkeit basierend auf Performance
 */
export function recommendDifficulty(
  card: SM2Card,
  recentPerformance: number[] // Array von Quality Scores
): 'easy' | 'medium' | 'hard' {
  if (recentPerformance.length === 0) {
    return 'medium';
  }

  const avgPerformance = recentPerformance.reduce((a, b) => a + b, 0) / recentPerformance.length;

  if (avgPerformance >= 4.5) {
    return 'hard'; // Benutzer macht sehr gute Fortschritte
  } else if (avgPerformance >= 3.5) {
    return 'medium'; // Benutzer macht gute Fortschritte
  } else {
    return 'easy'; // Benutzer braucht mehr Zeit
  }
}

/**
 * Gebe Karten für heutige Wiederholung
 */
export function getCardsForReview(cards: SM2Card[]): SM2Card[] {
  const now = Date.now();
  return cards.filter(card => card.nextReviewDate <= now).sort((a, b) => {
    // Sortiere nach Priorität: schwierigere Karten zuerst
    const diffOrder = { hard: 0, medium: 1, easy: 2 };
    return diffOrder[a.difficulty] - diffOrder[b.difficulty];
  });
}

/**
 * Berechne Lernstatistiken
 */
export function calculateStats(cards: SM2Card[]) {
  const totalCards = cards.length;
  const learnedCards = cards.filter(c => c.repetitions >= 3).length;
  const reviewCards = getCardsForReview(cards).length;
  const avgEF = cards.reduce((sum, c) => sum + c.easeFactor, 0) / totalCards;

  return {
    totalCards,
    learnedCards,
    reviewCards,
    avgEF: avgEF.toFixed(2),
    learningProgress: ((learnedCards / totalCards) * 100).toFixed(1),
  };
}
