import React, { createContext, useContext, useState, ReactNode } from 'react';

interface LLMConfig {
  provider: 'openai' | 'anthropic' | 'local';
  apiKey?: string;
  model?: string;
  baseURL?: string;
}

interface LLMContextType {
  config: LLMConfig;
  isConfigured: boolean;
  setConfig: (config: LLMConfig) => Promise<void>;
  generateResponse: (prompt: string, context?: string) => Promise<string>;
  explainWord: (word: string, german: string) => Promise<string>;
  generateExamples: (word: string, context?: string) => Promise<string[]>;
  analyzePronunciation: (word: string, userText: string) => Promise<string>;
  isLoading: boolean;
  error: string | null;
  clearError: () => void;
}

const LLMContext = createContext<LLMContextType | undefined>(undefined);

export function LLMProvider({ children }: { children: ReactNode }) {
  const [config, setConfigState] = useState<LLMConfig>({
    provider: 'local',
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const setConfig = async (newConfig: LLMConfig) => {
    try {
      setError(null);
      setConfigState(newConfig);
      // TODO: Speichere Config in SecureStore für Produktion
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Fehler beim Speichern der Konfiguration';
      setError(errorMessage);
      throw err;
    }
  };

  const generateResponse = async (prompt: string, context?: string): Promise<string> => {
    try {
      setError(null);
      setIsLoading(true);

      // TODO: Integriere mit echtem LLM
      // Für jetzt: Einfache lokale Antwort
      const response = await generateLocalResponse(prompt, context);
      return response;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Fehler beim Generieren der Antwort';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const explainWord = async (word: string, german: string): Promise<string> => {
    try {
      setError(null);
      setIsLoading(true);

      const prompt = `Erkläre das deutsche Wort "${german}" (Russisch: "${word}") einfach und verständlich für einen Deutschlerner. Gib eine kurze Erklärung (2-3 Sätze).`;
      const explanation = await generateResponse(prompt);
      return explanation;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Fehler beim Erklären des Wortes';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const generateExamples = async (word: string, context?: string): Promise<string[]> => {
    try {
      setError(null);
      setIsLoading(true);

      const prompt = `Gib 3 einfache Beispielsätze mit dem Wort "${word}" für einen Deutschlerner. ${
        context ? `Kontext: ${context}` : ''
      } Format: Satz 1\\nSatz 2\\nSatz 3`;

      const response = await generateResponse(prompt);
      const examples = response.split('\n').filter(s => s.trim());
      return examples;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Fehler beim Generieren von Beispielen';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const analyzePronunciation = async (word: string, userText: string): Promise<string> => {
    try {
      setError(null);
      setIsLoading(true);

      const prompt = `Der Benutzer hat versucht, das Wort "${word}" auszusprechen. Der erkannte Text war: "${userText}". Gib kurzes Feedback (1-2 Sätze) zur Aussprache.`;
      const feedback = await generateResponse(prompt);
      return feedback;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Fehler beim Analysieren der Aussprache';
      setError(errorMessage);
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const clearError = () => setError(null);

  return (
    <LLMContext.Provider
      value={{
        config,
        isConfigured: config.provider !== 'local' && !!config.apiKey,
        setConfig,
        generateResponse,
        explainWord,
        generateExamples,
        analyzePronunciation,
        isLoading,
        error,
        clearError,
      }}
    >
      {children}
    </LLMContext.Provider>
  );
}

export function useLLM() {
  const context = useContext(LLMContext);
  if (!context) {
    throw new Error('useLLM must be used within LLMProvider');
  }
  return context;
}

// Lokale Antwort-Generierung (wird durch echtes LLM ersetzt)
async function generateLocalResponse(prompt: string, context?: string): Promise<string> {
  // Simuliere API-Latenz
  await new Promise(resolve => setTimeout(resolve, 500));

  if (prompt.toLowerCase().includes('erkläre')) {
    return 'Das ist ein wichtiges deutsches Wort. Es wird häufig in alltäglichen Situationen verwendet und hat mehrere Bedeutungen je nach Kontext.';
  }

  if (prompt.toLowerCase().includes('beispiel')) {
    return 'Beispiel 1: Das ist ein Beispiel.\nBeispiel 2: Ich gebe dir ein Beispiel.\nBeispiel 3: Kannst du mir ein Beispiel geben?';
  }

  if (prompt.toLowerCase().includes('aussprache')) {
    return 'Gute Aussprache! Das Wort wird korrekt betont. Achte auf die Länge des Vokals.';
  }

  return 'Das ist eine interessante Frage. Kannst du mir mehr Details geben?';
}
