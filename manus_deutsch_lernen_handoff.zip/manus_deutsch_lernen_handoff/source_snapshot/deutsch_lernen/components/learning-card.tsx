import React, { useState } from 'react';
import { View, Text, Pressable, Animated, PanResponder, GestureResponderEvent } from 'react-native';
import { Word } from '@/lib/types';
import { useFontSizes } from '@/hooks/use-accessibility';
import { useSettings } from '@/lib/settings-context';

interface LearningCardProps {
  word: Word;
  isFlipped?: boolean;
  onFlip?: () => void;
  onSwipeLeft?: () => void;
  onSwipeRight?: () => void;
  onAudioPlay?: () => void;
}

export function LearningCard({
  word,
  isFlipped = false,
  onFlip,
  onSwipeLeft,
  onSwipeRight,
  onAudioPlay,
}: LearningCardProps) {
  const { settings } = useSettings();
  const fontSizes = useFontSizes(settings.fontSizeLevel);
  const [flipped, setFlipped] = useState(isFlipped);
  const [pan] = useState(new Animated.ValueXY());

  const panResponder = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: () => true,
    onPanResponderRelease: (evt, gestureState) => {
      const { dx } = gestureState;

      // Wisch nach rechts (Easy)
      if (dx > 50 && onSwipeRight) {
        onSwipeRight();
      }
      // Wisch nach links (Hard)
      else if (dx < -50 && onSwipeLeft) {
        onSwipeLeft();
      }

      // Reset position
      Animated.spring(pan, {
        toValue: { x: 0, y: 0 },
        useNativeDriver: false,
      }).start();
    },
  });

  const handleFlip = () => {
    setFlipped(!flipped);
    if (onFlip) {
      onFlip();
    }
  };

  return (
    <Animated.View
      {...panResponder.panHandlers}
      style={[
        {
          transform: [
            { translateX: pan.x },
            { translateY: pan.y },
          ],
        },
      ]}
    >
      <Pressable
        onPress={handleFlip}
        accessible={true}
        accessibilityRole="button"
        accessibilityLabel={`Lernkarte: ${word.russian}`}
        accessibilityHint="Tippen zum Umdrehen, nach rechts wischen für leicht, nach links für schwer"
        className="bg-surface rounded-3xl p-8 border-2 border-primary min-h-96 justify-center items-center"
        style={({ pressed }) => ({
          opacity: pressed ? 0.9 : 1,
          transform: [{ scale: pressed ? 0.98 : 1 }],
        })}
      >
        <View className="gap-6 items-center w-full">
          {/* Language Label */}
          <Text
            className="text-muted text-xs font-semibold uppercase tracking-widest"
            style={{ fontSize: fontSizes.xs }}
          >
            {flipped ? 'Deutsch' : 'Русский'}
          </Text>

          {/* Main Content */}
          <View className="gap-4 items-center">
            {flipped ? (
              <>
                {/* German Side */}
                <Text
                  className="text-foreground font-bold text-center"
                  style={{ fontSize: fontSizes['5xl'], lineHeight: fontSizes['5xl'] * 1.2 }}
                >
                  {word.german}
                </Text>

                {/* IPA */}
                {word.ipa && (
                  <Text
                    className="text-muted text-center"
                    style={{ fontSize: fontSizes.lg }}
                  >
                    {word.ipa}
                  </Text>
                )}

                {/* Audio Button */}
                {word.audioWordUrl && (
                  <Pressable
                    onPress={onAudioPlay}
                    accessible={true}
                    accessibilityRole="button"
                    accessibilityLabel="Aussprache anhören"
                    className="bg-primary rounded-full p-4 mt-4"
                    style={({ pressed }) => ({
                      opacity: pressed ? 0.8 : 1,
                      transform: [{ scale: pressed ? 0.95 : 1 }],
                    })}
                  >
                    <Text
                      className="text-background font-bold text-center"
                      style={{ fontSize: fontSizes.xl }}
                    >
                      🔊 Anhören
                    </Text>
                  </Pressable>
                )}
              </>
            ) : (
              <>
                {/* Russian Side */}
                <Text
                  className="text-foreground font-bold text-center"
                  style={{ fontSize: fontSizes['5xl'], lineHeight: fontSizes['5xl'] * 1.2 }}
                >
                  {word.russian}
                </Text>

                {/* Category */}
                <Text
                  className="text-muted text-center"
                  style={{ fontSize: fontSizes.base }}
                >
                  {word.category}
                </Text>
              </>
            )}
          </View>

          {/* Swipe Instructions */}
          <View className="flex-row gap-8 mt-6 w-full justify-center">
            <View className="items-center gap-1">
              <Text
                className="text-muted text-xs"
                style={{ fontSize: fontSizes.xs }}
              >
                ← Schwer
              </Text>
            </View>
            <View className="items-center gap-1">
              <Text
                className="text-muted text-xs"
                style={{ fontSize: fontSizes.xs }}
              >
                Leicht →
              </Text>
            </View>
          </View>
        </View>
      </Pressable>
    </Animated.View>
  );
}
