# DEUTSCH LERNEN – TODO

## Phase 1: Projekt-Setup & Design-System
- [ ] Design-System und Farbpalette implementieren
- [ ] Typografie-Skalierung einrichten (bis 48pt)
- [ ] Theme-Config mit hohem Kontrast (WCAG AA/AAA) aktualisieren
- [ ] Barrierefreiheit-Hooks erstellen (Screenreader-Labels, Fokus)
- [ ] App-Logo und Branding generieren
- [ ] App-Name und Konfiguration in app.config.ts aktualisieren

## Phase 2: Tab-Navigation & Grundstruktur
- [ ] Tab-Bar mit 3 Tabs implementieren (Учить, Вспоминать, Говорить)
- [ ] Tab-Icons erstellen und in icon-symbol.tsx mappen
- [ ] Basis-Layout für jeden Tab erstellen
- [ ] Russische UI-Texte implementieren
- [ ] ScreenContainer für alle Screens verwenden

## Phase 3: Tab „Учить" (Lernen)
- [ ] Vokabelkarten-Komponente erstellen
- [ ] Vokabel-Daten-Struktur definieren (Russisch → Deutsch)
- [ ] Vokabel-Datensatz mit ~100 häufigen Wörtern erstellen
- [ ] Audio-Unterstützung für deutsche Aussprache integrieren
- [ ] Wischen-Gesten für Navigation implementieren
- [ ] Fortschritts-Anzeige (z.B. „3/50") anzeigen
- [ ] Große Buttons für Weiter/Zurück implementieren
- [ ] Vokabeln lokal speichern (AsyncStorage)

## Phase 4: Tab „Вспоминать" (Erinnern)
- [ ] Quiz-Komponente mit 4 Antwort-Optionen erstellen
- [ ] Quiz-Logik implementieren (zufällige Fragen)
- [ ] Feedback-System (grün für richtig, rot für falsch)
- [ ] Erfolgs-Zähler anzeigen
- [ ] Automatischer Übergang zur nächsten Frage
- [ ] Quiz-Fortschritt speichern

## Phase 5: Tab „Говорить" (Sprechen)
- [ ] Spracherkennung integrieren (expo-speech oder Web Speech API)
- [ ] Mikrofon-Button mit großem Icon erstellen
- [ ] Aufnahme-Status anzeigen (Bereit, Höre zu, Verarbeite)
- [ ] Aussprache-Feedback geben (korrekt/falsch)
- [ ] Aufnahme-Fortschritt speichern

## Phase 6: Barrierefreiheit & Optimierung
- [ ] Screenreader-Labels für alle Elemente hinzufügen
- [ ] Tastatur-Navigation testen und implementieren
- [ ] Fokus-Indikatoren (Outline) hinzufügen
- [ ] Kontrast mit WCAG-Tools überprüfen
- [ ] Animationen auf prefers-reduced-motion testen
- [ ] Dunkler Modus testen
- [ ] Große Touch-Flächen überprüfen (min. 56pt)

## Phase 7: Daten & Persistierung
- [ ] Vokabel-Datensatz in AsyncStorage speichern
- [ ] Lernfortschritt speichern (welche Wörter gelernt)
- [ ] Quiz-Ergebnisse speichern
- [ ] Daten beim App-Start laden
- [ ] Optionale Daten-Export-Funktion

## Phase 8: Testing & Feinschliff
- [ ] Alle Flows end-to-end testen
- [ ] VoiceOver (iOS) und TalkBack (Android) testen
- [ ] Responsive Design auf verschiedenen Geräten testen
- [ ] Performance überprüfen (keine Lags)
- [ ] Fehlerbehandlung implementieren
- [ ] Fehlermeldungen benutzerfreundlich gestalten

## Phase 9: Finalisierung & Deployment
- [ ] Finale Checkpoint erstellen
- [ ] App für iOS und Android bauen
- [ ] QR-Code für Expo Go generieren
- [ ] Dokumentation aktualisieren
- [ ] Benutzer-Anleitung erstellen


## Phase 2 (Detailliert): Design-System & Barrierefreiheit
- [x] Barrierefreiheit-Hooks erstellen (useAccessibility, useFontSize, useContrast)
- [x] System-Font-Scaling unterstützen (Dynamic Type / Font Scaling)
- [x] Reduce-Motion und Reduce-Transparency Einstellungen implementieren
- [x] Glassmorphism mit Fallback auf Volltonflächen
- [x] Screenreader-Label-System für alle Komponenten

## Phase 3 (Detailliert): Onboarding-Flow
- [x] Screen O1: Willkommen (Header, Untertitel, Button "Начать")
- [x] Screen O2: Schriftgröße (3 Optionen mit Vorschau: Стандартный, Крупный, Очень крупный)
- [x] Screen O3: Vorkenntnisse (3 Buttons: Совсем начинающий, Немного знаю, Могу говорить простые фразы)
- [x] Screen O4: Accessibility-Info (Text + Switch für Reduce Effects)
- [x] Onboarding-Daten in AsyncStorage speichern

## Phase 4 (Detailliert): Tab-Navigation & Datenmodell
- [x] Bottom-Tab-Bar mit 3 Tabs (Учить, Вспоминать, Говорить) implementieren
- [x] Tab-Icons erstellen und mappen
- [x] Datenmodell definieren (Word, UserWordState, UserSettings, SessionLog)
- [x] AsyncStorage-Schema für lokale Persistierung
- [x] Vokabel-Datensatz mit ~100 häufigen Wörtern (Russisch → Deutsch)
- [x] Kategorien-System (Базовые глаголы, Семья, Город, Покупки, etc.)

## Phase 5 (Detailliert): Tab „Учить" (Lernen)
- [ ] Screen U1: Lernset-Auswahl (große Karten mit Titel, Wortanzahl, Level)
- [ ] Button „Продолжить последний набор" wenn Set begonnen
- [ ] Screen U2: Lernkarte (Russisch, Deutsch, IPA, Beispielsätze)
- [ ] Audio-Button „Прослушать немецкое слово"
- [ ] Buttons „Сложно" und „Нормально" für Schwierigkeit
- [ ] Button „Дальше" für nächste Karte
- [ ] Fortschritts-Anzeige (z.B. „Слово 3 из 10")
- [ ] Screen U3: Detail-Info (optional, Wortart, Genus, Beispielsätze)
- [ ] Spaced-Repetition-State nach Auswahl speichern

## Phase 6 (Detailliert): Tab „Вспоминать" (Erinnern)
- [ ] Screen R1: Start Wiederholen (Text mit Wortanzahl, 2 große Buttons)
- [ ] Screen R2a: „Вспомнить перевод" - Zustand A (Russisch + Button „Показать перевод")
- [ ] Screen R2b: „Вспомнить перевод" - Zustand B (Russisch + Deutsch + Buttons „Было легко/трудно")
- [ ] Screen R3: „Мини-тест" (Russisch + 3-4 Antwort-Buttons)
- [ ] Feedback-Text nach Auswahl (Правильно / Неправильно)
- [ ] Spaced-Repetition-Logik implementieren (Intervalle, Ease-Factor)
- [ ] Tägliche Wiederholungs-Berechnung

## Phase 7 (Detailliert): Tab „Говорить" (Sprechen)
- [ ] Screen S1: Start (Erklärtext + Button „Начать тренировку")
- [ ] Screen S2: Sprechübung (Russisch + Deutsch, Audio-Buttons)
- [ ] Button „Прослушать образец" (spielt Deutsch-Audio)
- [ ] Button „Сказать вслух" (startet Aufnahme)
- [ ] Aufnahme-Status anzeigen (Идёт запись…)
- [ ] Button „Остановить запись" während Aufnahme
- [ ] ASR-Integration (Web Speech API oder Expo-Audio)
- [ ] Einfaches Textfeedback nach Aufnahme (3 Stufen)
- [ ] Buttons „Ещё раз" und „Следующее слово"

## Phase 8 (Detailliert): Spaced-Repetition-Algorithmus
- [ ] SM-2/FSRS-ähnliche Logik (vereinfacht)
- [ ] nextReview-Berechnung basierend auf Antwort
- [ ] intervalDays-Wachstum bei „Было легко"
- [ ] intervalDays-Reset bei „Было трудно"
- [ ] easeFactor-Anpassung
- [ ] Tägliche Wiederholungs-Liste filtern

## Phase 9 (Detailliert): Audio & ASR
- [ ] TTS für deutsche Wörter (expo-audio oder Web Audio)
- [ ] Audio-Dateien oder TTS-Generierung
- [ ] Sprachaufnahme mit expo-audio
- [ ] ASR-Transkription (Web Speech API oder Backend)
- [ ] Feedback-Logik (Match-Schwellen)

## Phase 10 (Detailliert): Barrierefreiheit-Optimierung
- [ ] VoiceOver (iOS) Testing
- [ ] TalkBack (Android) Testing
- [ ] Kontrast-Überprüfung mit WCAG-Tools
- [ ] Tastatur-Navigation testen
- [ ] Fokus-Indikatoren überprüfen
- [ ] Reduce-Motion respektieren
- [ ] Reduce-Transparency respektieren
- [ ] Touch-Ziele (min. 48x48 dp) überprüfen
- [ ] Screenreader-Labels überprüfen

## Phase 11 (Detailliert): Testing & Finalisierung
- [ ] End-to-End-Testing aller Flows
- [ ] Responsive Design auf verschiedenen Geräten
- [ ] Performance-Überprüfung
- [ ] Fehlerbehandlung
- [ ] Benutzer-Anleitung
- [ ] Finale Checkpoint vor Deployment


## Phase 5 (Erweitert): Prüfungsmodus (A1, A2, B1, B2)
- [x] CEFR-Niveaus zum Datenmodell hinzufügen
- [x] Vokabeln nach CEFR-Niveaus kategorisieren (A1, A2, B1, B2)
- [x] Prüfungsmodus-Screen mit Niveauauswahl
- [x] Prüfungs-Quiz-Logik (Multiple Choice, Matching, etc.)
- [x] Scoring-System und Bewertung
- [x] Zertifikat-Anzeige bei Bestehen
- [x] Prüfungsergebnisse speichern und anzeigen

## Phase 6 (Erweitert): Lernkarten, Spaced Repetition, Sprachaufnahme
- [x] Lernkarten-Komponente mit Wisch-Gesten
- [x] Learn-Card-Screen mit Kartenverwaltung
- [x] Spaced-Repetition-Context mit SM-2-Algorithmus
- [x] Review-Quiz-Screen mit Multiple-Choice
- [x] Review-Ergebnis-Screen mit Feedback
- [x] Speech-Recognition-Context für Sprachaufnahme
- [x] Speak-Screen mit Wortgruppen-Auswahl
- [x] Speak-Practice-Screen mit Aufnahme-Logik
- [x] 8 neue Unit-Tests für Spaced Repetition (alle bestanden)


## Phase 7 (Erweitert): Email-Anmeldung und Authentifizierung
- [x] Auth-Context mit Email/Passwort-Login erstellen
- [x] Registrierungs-Screen implementieren
- [x] Login-Screen implementieren
- [ ] Passwort-Reset-Funktionalität
- [x] Benutzer-Daten in AsyncStorage speichern
- [ ] Auth-Guards für geschützte Screens
- [ ] Session-Management und Token-Handling

## Phase 8 (Erweitert): KI-Assistent
- [x] AI-Assistent-Context für LLM-Integration
- [x] Chat-Interface mit Nachrichtenhistorie
- [x] Kontextuelle Lernhilfe (Wörter erklären, Beispiele geben)
- [ ] Aussprache-Feedback mit ASR
- [x] Personalisierte Lernempfehlungen
- [ ] KI-basierte Fehleranalyse
- [x] Multi-turn Conversation Support
- [x] 10 neue Unit-Tests für Auth und AI-Assistent (alle bestanden)


## Phase 9 (Erweitert): Statistiken-Dashboard & LLM-Integration
- [x] Statistics-Context für Lernfortschritt erstellen
- [x] Streak-Tracking implementieren
- [x] Wörter-pro-Tag-Statistik
- [x] Dashboard-Screen mit Visualisierungen
- [x] LLM-API-Integration (OpenAI/Anthropic)
- [x] KI-Antworten mit Kontext verbessern
- [x] Fehlerbehandlung für API-Ausfälle
- [x] Cloud-Synchronisierung für Benutzer-Daten
- [x] Offline-Modus mit lokaler Persistierung
- [x] 19 neue Unit-Tests für Statistics, LLM und Cloud-Sync (66 Tests insgesamt, alle bestanden)


## Phase 10 (Erweitert): Gamification, TTS & Offline-Content
- [x] Achievements-Context mit Badge-System erstellen
- [x] Leaderboard-Screen mit Rankings implementieren
- [x] Benutzer-Achievements tracken und anzeigen
- [x] Text-to-Speech (TTS) Integration mit expo-speech
- [x] Aussprache-Beispiele mit TTS vorlesen
- [x] Offline-Content-Sync für Vokabeln
- [x] Offline-Prüfungsmodus
- [x] Content-Download-Manager
- [x] Offline-Indikator in der UI
- [x] 16 neue Unit-Tests für Gamification (83 Tests insgesamt, alle bestanden)


## Phase 11 (Erweitert): Social Features, Adaptive Learning & SR-Optimierung
- [x] Social-Context mit Freunde-System erstellen
- [x] Lerngruppen-Feature implementieren
- [x] Fortschritt-Sharing mit anderen Benutzern
- [x] Adaptive-Learning-Context mit KI-Lernpfaden
- [x] Schwierigkeitsgrad-Anpassung basierend auf Performance
- [x] SM-2-Algorithmus mit Schwierigkeitsgrad-Integration
- [x] Leaderboard mit Freunden-Vergleich
- [x] Benachrichtigungen für Freunde-Aktivitäten
- [x] Social-Screens (Freunde, Gruppen, Leaderboard)
- [x] 17 neue Unit-Tests für Advanced Features (100 Tests insgesamt, alle bestanden)


## Phase 13 (Erweitert): Realistische Prüfungsmodi mit deutschen Texten

- [x] Prüfungsfragen in Deutsch (ohne automatische Übersetzung)
- [x] "Übersetzung anzeigen" Button für optionale russische Übersetzung
- [x] Toggle-Funktionalität zwischen Deutsch und Russisch
- [x] A1-Prüfung: Hörverstehen, Leseverstehen, Schreiben (Einfache Sätze)
- [x] A2-Prüfung: Hörverstehen, Leseverstehen, Schreiben (Zusammenhängende Texte)
- [x] B1-Prüfung: Hörverstehen, Leseverstehen, Schreiben, Sprechen (Komplexe Themen)
- [x] B2-Prüfung: Hörverstehen, Leseverstehen, Schreiben, Sprechen (Abstrakte Konzepte)
- [x] Realistische Prüfungsformate (Multiple Choice, Matching, Freie Antworten)
- [x] Zeitlimit für Prüfungen
- [x] Detailliertes Feedback mit Erklärungen
- [x] 19 neue Unit-Tests für erweiterte Prüfungsmodi (137 Tests insgesamt, alle bestanden)
