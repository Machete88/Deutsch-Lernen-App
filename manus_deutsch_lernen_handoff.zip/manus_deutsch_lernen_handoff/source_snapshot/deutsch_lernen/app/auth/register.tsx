import { View, Text, ScrollView, Pressable, TextInput } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useAuth } from '@/lib/auth-context';
import { useSettings } from '@/lib/settings-context';
import { useFontSizes } from '@/hooks/use-accessibility';
import { useState } from 'react';

export default function RegisterScreen() {
  const router = useRouter();
  const { register, isLoading, error, clearError } = useAuth();
  const { settings } = useSettings();
  const fontSizes = useFontSizes(settings.fontSizeLevel);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleRegister = async () => {
    try {
      clearError();
      if (password !== confirmPassword) {
        throw new Error('Passwörter stimmen nicht überein');
      }
      await register(email, password, name);
      router.replace('/(tabs)');
    } catch (err) {
      console.error('Register error:', err);
    }
  };

  const handleLogin = () => {
    router.back();
  };

  const isFormValid = email && password && confirmPassword && name && password === confirmPassword;

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 px-6 py-8 gap-8 justify-between">
          {/* Header */}
          <View className="gap-2">
            <Text
              className="text-foreground font-bold"
              style={{ fontSize: fontSizes['5xl'] }}
              accessibilityRole="header"
            >
              Registrieren
            </Text>
            
            <Text
              className="text-muted"
              style={{ fontSize: fontSizes.lg, lineHeight: fontSizes.lg * 1.5 }}
            >
              Erstelle dein Konto
            </Text>
          </View>

          {/* Form */}
          <View className="gap-6">
            {/* Name Input */}
            <View className="gap-2">
              <Text
                className="text-foreground font-semibold"
                style={{ fontSize: fontSizes.base }}
              >
                Name
              </Text>

              <TextInput
                placeholder="Dein Name"
                value={name}
                onChangeText={setName}
                editable={!isLoading}
                accessibilityLabel="Name-Eingabe"
                className="bg-surface border-2 border-border rounded-2xl px-4 py-4 text-foreground"
                placeholderTextColor="#999"
                style={{ fontSize: fontSizes.lg }}
              />
            </View>

            {/* Email Input */}
            <View className="gap-2">
              <Text
                className="text-foreground font-semibold"
                style={{ fontSize: fontSizes.base }}
              >
                Email
              </Text>

              <TextInput
                placeholder="deine@email.de"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                editable={!isLoading}
                accessibilityLabel="Email-Eingabe"
                className="bg-surface border-2 border-border rounded-2xl px-4 py-4 text-foreground"
                placeholderTextColor="#999"
                style={{ fontSize: fontSizes.lg }}
              />
            </View>

            {/* Password Input */}
            <View className="gap-2">
              <Text
                className="text-foreground font-semibold"
                style={{ fontSize: fontSizes.base }}
              >
                Passwort
              </Text>

              <View className="flex-row items-center border-2 border-border rounded-2xl bg-surface">
                <TextInput
                  placeholder="••••••••"
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPassword}
                  editable={!isLoading}
                  accessibilityLabel="Passwort-Eingabe"
                  className="flex-1 px-4 py-4 text-foreground"
                  placeholderTextColor="#999"
                  style={{ fontSize: fontSizes.lg }}
                />

                <Pressable
                  onPress={() => setShowPassword(!showPassword)}
                  accessible={true}
                  accessibilityRole="button"
                  className="px-4 py-4"
                >
                  <Text
                    className="text-primary font-bold"
                    style={{ fontSize: fontSizes.lg }}
                  >
                    {showPassword ? '🙈' : '👁'}
                  </Text>
                </Pressable>
              </View>
            </View>

            {/* Confirm Password Input */}
            <View className="gap-2">
              <Text
                className="text-foreground font-semibold"
                style={{ fontSize: fontSizes.base }}
              >
                Passwort wiederholen
              </Text>

              <TextInput
                placeholder="••••••••"
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                secureTextEntry={!showPassword}
                editable={!isLoading}
                accessibilityLabel="Passwort-Wiederholung"
                className="bg-surface border-2 border-border rounded-2xl px-4 py-4 text-foreground"
                placeholderTextColor="#999"
                style={{ fontSize: fontSizes.lg }}
              />
            </View>

            {/* Error Message */}
            {error && (
              <View className="bg-error rounded-2xl p-4">
                <Text
                  className="text-background"
                  style={{ fontSize: fontSizes.base, lineHeight: fontSizes.base * 1.5 }}
                >
                  {error}
                </Text>
              </View>
            )}

            {/* Password Mismatch Warning */}
            {password && confirmPassword && password !== confirmPassword && (
              <View className="bg-warning rounded-2xl p-4">
                <Text
                  className="text-background"
                  style={{ fontSize: fontSizes.base }}
                >
                  Passwörter stimmen nicht überein
                </Text>
              </View>
            )}

            {/* Register Button */}
            <Pressable
              onPress={handleRegister}
              disabled={!isFormValid || isLoading}
              accessible={true}
              accessibilityRole="button"
              className={`rounded-2xl py-4 items-center ${
                isFormValid && !isLoading ? 'bg-primary' : 'bg-border'
              }`}
              style={({ pressed }) => ({
                opacity: pressed && isFormValid && !isLoading ? 0.8 : 1,
                transform: [{ scale: pressed && isFormValid && !isLoading ? 0.97 : 1 }],
              })}
            >
              <Text
                className={`font-bold text-center ${
                  isFormValid && !isLoading ? 'text-background' : 'text-muted'
                }`}
                style={{ fontSize: fontSizes.lg }}
              >
                {isLoading ? 'Wird registriert...' : 'Registrieren'}
              </Text>
            </Pressable>
          </View>

          {/* Login Link */}
          <View className="flex-row justify-center gap-2 items-center">
            <Text
              className="text-muted"
              style={{ fontSize: fontSizes.base }}
            >
              Bereits registriert?
            </Text>

            <Pressable
              onPress={handleLogin}
              accessible={true}
              accessibilityRole="button"
            >
              <Text
                className="text-primary font-bold"
                style={{ fontSize: fontSizes.base }}
              >
                Anmelden
              </Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
