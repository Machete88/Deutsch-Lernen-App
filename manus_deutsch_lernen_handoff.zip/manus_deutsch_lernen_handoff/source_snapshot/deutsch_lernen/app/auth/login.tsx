import { View, Text, ScrollView, Pressable, TextInput } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useAuth } from '@/lib/auth-context';
import { useSettings } from '@/lib/settings-context';
import { useFontSizes } from '@/hooks/use-accessibility';
import { useState } from 'react';

export default function LoginScreen() {
  const router = useRouter();
  const { login, isLoading, error, clearError } = useAuth();
  const { settings } = useSettings();
  const fontSizes = useFontSizes(settings.fontSizeLevel);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = async () => {
    try {
      clearError();
      await login(email, password);
      router.replace('/(tabs)');
    } catch (err) {
      console.error('Login error:', err);
    }
  };

  const handleRegister = () => {
    router.push('/auth/register');
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 px-6 py-8 gap-8 justify-between">
          {/* Header */}
          <View className="gap-2">
            <Text
              className="text-foreground font-bold"
              style={{ fontSize: fontSizes['5xl'] }}
              accessibilityRole="header"
            >
              Anmelden
            </Text>
            
            <Text
              className="text-muted"
              style={{ fontSize: fontSizes.lg, lineHeight: fontSizes.lg * 1.5 }}
            >
              Willkommen zurück zu DEUTSCH LERNEN
            </Text>
          </View>

          {/* Form */}
          <View className="gap-6">
            {/* Email Input */}
            <View className="gap-2">
              <Text
                className="text-foreground font-semibold"
                style={{ fontSize: fontSizes.base }}
              >
                Email
              </Text>

              <TextInput
                placeholder="deine@email.de"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                editable={!isLoading}
                accessibilityLabel="Email-Eingabe"
                className="bg-surface border-2 border-border rounded-2xl px-4 py-4 text-foreground"
                placeholderTextColor="#999"
                style={{ fontSize: fontSizes.lg }}
              />
            </View>

            {/* Password Input */}
            <View className="gap-2">
              <Text
                className="text-foreground font-semibold"
                style={{ fontSize: fontSizes.base }}
              >
                Passwort
              </Text>

              <View className="flex-row items-center border-2 border-border rounded-2xl bg-surface">
                <TextInput
                  placeholder="••••••••"
                  value={password}
                  onChangeText={setPassword}
                  secureTextEntry={!showPassword}
                  editable={!isLoading}
                  accessibilityLabel="Passwort-Eingabe"
                  className="flex-1 px-4 py-4 text-foreground"
                  placeholderTextColor="#999"
                  style={{ fontSize: fontSizes.lg }}
                />

                <Pressable
                  onPress={() => setShowPassword(!showPassword)}
                  accessible={true}
                  accessibilityRole="button"
                  accessibilityLabel={showPassword ? 'Passwort verbergen' : 'Passwort anzeigen'}
                  className="px-4 py-4"
                >
                  <Text
                    className="text-primary font-bold"
                    style={{ fontSize: fontSizes.lg }}
                  >
                    {showPassword ? '🙈' : '👁'}
                  </Text>
                </Pressable>
              </View>
            </View>

            {/* Error Message */}
            {error && (
              <View className="bg-error rounded-2xl p-4">
                <Text
                  className="text-background"
                  style={{ fontSize: fontSizes.base, lineHeight: fontSizes.base * 1.5 }}
                >
                  {error}
                </Text>
              </View>
            )}

            {/* Login Button */}
            <Pressable
              onPress={handleLogin}
              disabled={!email || !password || isLoading}
              accessible={true}
              accessibilityRole="button"
              accessibilityLabel="Anmelden"
              className={`rounded-2xl py-4 items-center ${
                email && password && !isLoading ? 'bg-primary' : 'bg-border'
              }`}
              style={({ pressed }) => ({
                opacity: pressed && email && password && !isLoading ? 0.8 : 1,
                transform: [{ scale: pressed && email && password && !isLoading ? 0.97 : 1 }],
              })}
            >
              <Text
                className={`font-bold text-center ${
                  email && password && !isLoading ? 'text-background' : 'text-muted'
                }`}
                style={{ fontSize: fontSizes.lg }}
              >
                {isLoading ? 'Wird angemeldet...' : 'Anmelden'}
              </Text>
            </Pressable>
          </View>

          {/* Register Link */}
          <View className="flex-row justify-center gap-2 items-center">
            <Text
              className="text-muted"
              style={{ fontSize: fontSizes.base }}
            >
              Noch kein Konto?
            </Text>

            <Pressable
              onPress={handleRegister}
              accessible={true}
              accessibilityRole="button"
              accessibilityLabel="Zur Registrierung"
            >
              <Text
                className="text-primary font-bold"
                style={{ fontSize: fontSizes.base }}
              >
                Registrieren
              </Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
