import { View, Text, ScrollView, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useFontSizes } from '@/hooks/use-accessibility';

const userLevelOptions = [
  { level: 'beginner' as const, label: 'Совсем начинающий', description: 'Я не знаю немецкий' },
  { level: 'intermediate' as const, label: 'Немного знаю', description: 'Я знаю несколько слов' },
  { level: 'advanced' as const, label: 'Могу говорить простые фразы', description: 'Я уже учу немецкий' },
];

export default function UserLevelScreen() {
  const router = useRouter();
  const { settings, updateSettings } = useSettings();
  const fontSizes = useFontSizes(settings.fontSizeLevel);

  const handleSelectLevel = async (level: 'beginner' | 'intermediate' | 'advanced') => {
    await updateSettings({ userLevel: level });
    router.push('../accessibility-info');
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 justify-center px-6 gap-8">
          {/* Header */}
          <View className="gap-2">
            <Text
              className="text-foreground font-bold"
              style={{ fontSize: fontSizes['4xl'] }}
              accessibilityRole="header"
            >
              Ваш уровень
            </Text>
            
            <Text
              className="text-muted"
              style={{ fontSize: fontSizes.lg, lineHeight: fontSizes.lg * 1.5 }}
            >
              Вы уже немного знаете немецкий?
            </Text>
          </View>

          {/* User Level Options */}
          <View className="gap-4">
            {userLevelOptions.map(option => (
              <Pressable
                key={option.level}
                onPress={() => handleSelectLevel(option.level)}
                accessible={true}
                accessibilityRole="radio"
                accessibilityState={{ selected: settings.userLevel === option.level }}
                accessibilityLabel={option.label}
                className="rounded-2xl p-6 bg-surface border-2 border-border"
                style={({ pressed }) => ({
                  opacity: pressed ? 0.8 : 1,
                  transform: [{ scale: pressed ? 0.97 : 1 }],
                })}
              >
                <Text
                  className="text-foreground font-bold"
                  style={{ fontSize: fontSizes.xl }}
                >
                  {option.label}
                </Text>
                
                <Text
                  className="text-muted mt-2"
                  style={{ fontSize: fontSizes.base, lineHeight: fontSizes.base * 1.5 }}
                >
                  {option.description}
                </Text>
              </Pressable>
            ))}
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
