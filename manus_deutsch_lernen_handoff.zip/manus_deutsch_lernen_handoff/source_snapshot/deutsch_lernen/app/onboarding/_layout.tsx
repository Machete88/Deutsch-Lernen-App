import { Stack } from 'expo-router';

export default function OnboardingLayout() {
  return (
    <Stack
      screenOptions={{
        headerShown: false,
      }}
    >
      <Stack.Screen name="welcome" />
      <Stack.Screen name="font-size" />
      <Stack.Screen name="user-level" />
      <Stack.Screen name="accessibility-info" />
    </Stack>
  );
}
