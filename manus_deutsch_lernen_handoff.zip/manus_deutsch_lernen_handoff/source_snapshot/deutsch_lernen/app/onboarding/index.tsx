import { useRouter } from 'expo-router';
import { useSettings } from '@/lib/settings-context';
import { useEffect } from 'react';

export default function OnboardingIndex() {
  const router = useRouter();
  const { settings, isLoading } = useSettings();

  useEffect(() => {
    if (isLoading) return;

    // Wenn Onboarding bereits abgeschlossen, gehe zu Tabs
    if (settings.onboardingCompleted) {
      router.replace('/(tabs)');
    } else {
      // Sonst starte mit Welcome-Screen
      router.replace('./welcome');
    }
  }, [settings.onboardingCompleted, isLoading, router]);

  return null;
}
