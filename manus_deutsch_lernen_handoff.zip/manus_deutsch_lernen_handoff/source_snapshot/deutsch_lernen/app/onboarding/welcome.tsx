import { View, Text, ScrollView, Pressable, AccessibilityInfo } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useFontSizes } from '@/hooks/use-accessibility';

export default function WelcomeScreen() {
  const router = useRouter();
  const { settings } = useSettings();
  const fontSizes = useFontSizes(settings.fontSizeLevel);

  const handleStart = async () => {
    // Gehe zum nächsten Onboarding-Screen
    router.push('../font-size');
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 justify-center items-center px-6 gap-8">
          {/* Header */}
          <View className="items-center gap-4">
            <Text
              className="text-foreground font-bold text-center"
              style={{ fontSize: fontSizes['6xl'] }}
              accessibilityRole="header"
            >
              DEUTSCH LERNEN
            </Text>
            
            <Text
              className="text-muted text-center"
              style={{ fontSize: fontSizes.lg, lineHeight: fontSizes.lg * 1.5 }}
              accessibilityLabel="Простое приложение для изучения немецких слов. Спокойно, понятно, с большой читаемой надписью."
            >
              Простое приложение для изучения немецких слов.{'\n'}
              Спокойно, понятно, с большой читаемой надписью.
            </Text>
          </View>

          {/* Start Button */}
          <Pressable
            onPress={handleStart}
            accessible={true}
            accessibilityRole="button"
            accessibilityLabel="Начать использование приложения"
            accessibilityHint="Переход к выбору размера шрифта"
            className="w-full bg-primary rounded-2xl py-4 items-center"
            style={({ pressed }) => ({
              opacity: pressed ? 0.8 : 1,
              transform: [{ scale: pressed ? 0.97 : 1 }],
            })}
          >
            <Text
              className="text-background font-bold text-center"
              style={{ fontSize: fontSizes.xl }}
            >
              Начать
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
