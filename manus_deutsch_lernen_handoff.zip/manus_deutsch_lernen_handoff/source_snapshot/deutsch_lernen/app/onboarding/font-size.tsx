import { View, Text, ScrollView, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useFontSizes } from '@/hooks/use-accessibility';
import { FontSizeLevel } from '@/hooks/use-accessibility';

const fontSizeOptions: Array<{ level: FontSizeLevel; label: string; description: string }> = [
  { level: 'normal', label: 'Стандартный', description: 'Обычный размер' },
  { level: 'large', label: 'Крупный', description: 'Больше текста' },
  { level: 'xlarge', label: 'Очень крупный', description: 'Максимум текста' },
];

export default function FontSizeScreen() {
  const router = useRouter();
  const { settings, updateSettings } = useSettings();
  const fontSizes = useFontSizes(settings.fontSizeLevel);

  const handleSelectFontSize = async (level: FontSizeLevel) => {
    await updateSettings({ fontSizeLevel: level });
    router.push('../user-level');
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 justify-center px-6 gap-8">
          {/* Header */}
          <View className="gap-2">
            <Text
              className="text-foreground font-bold"
              style={{ fontSize: fontSizes['4xl'] }}
              accessibilityRole="header"
            >
              Размер шрифта
            </Text>
            
            <Text
              className="text-muted"
              style={{ fontSize: fontSizes.lg, lineHeight: fontSizes.lg * 1.5 }}
            >
              Выберите, насколько крупным будет текст.
            </Text>
          </View>

          {/* Font Size Options */}
          <View className="gap-6">
            {fontSizeOptions.map(option => {
              const isSelected = settings.fontSizeLevel === option.level;
              const previewSizes = useFontSizes(option.level);
              
              return (
                <Pressable
                  key={option.level}
                  onPress={() => handleSelectFontSize(option.level)}
                  accessible={true}
                  accessibilityRole="radio"
                  accessibilityState={{ selected: isSelected }}
                  accessibilityLabel={`${option.label}, ${option.description}`}
                  className={`rounded-2xl p-6 border-2 ${
                    isSelected
                      ? 'border-primary bg-primary'
                      : 'border-border bg-surface'
                  }`}
                  style={({ pressed }) => ({
                    opacity: pressed ? 0.8 : 1,
                    transform: [{ scale: pressed ? 0.97 : 1 }],
                  })}
                >
                  <View className="gap-3">
                    <Text
                      className={`font-bold ${
                        isSelected ? 'text-background' : 'text-foreground'
                      }`}
                      style={{ fontSize: fontSizes.xl }}
                    >
                      {option.label}
                    </Text>
                    
                    <Text
                      className={isSelected ? 'text-background' : 'text-muted'}
                      style={{ fontSize: previewSizes.lg, lineHeight: previewSizes.lg * 1.5 }}
                    >
                      Пример текста
                    </Text>
                  </View>
                </Pressable>
              );
            })}
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
