import { View, Text, ScrollView, Pressable, Switch } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useFontSizes } from '@/hooks/use-accessibility';
import { useState } from 'react';

export default function AccessibilityInfoScreen() {
  const router = useRouter();
  const { settings, updateSettings } = useSettings();
  const fontSizes = useFontSizes(settings.fontSizeLevel);
  const [reduceMotion, setReduceMotion] = useState(settings.reduceMotion);

  const handleCompleteOnboarding = async () => {
    await updateSettings({
      reduceMotion,
      onboardingCompleted: true,
    });
    router.replace('/(tabs)');
  };

  const handleToggleReduceMotion = async (value: boolean) => {
    setReduceMotion(value);
    await updateSettings({ reduceMotion: value });
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 justify-between px-6 py-8 gap-8">
          {/* Content */}
          <View className="gap-6">
            <View className="gap-2">
              <Text
                className="text-foreground font-bold"
                style={{ fontSize: fontSizes['4xl'] }}
                accessibilityRole="header"
              >
                Доступность
              </Text>
            </View>

            {/* Info Text */}
            <Text
              className="text-foreground"
              style={{ fontSize: fontSizes.lg, lineHeight: fontSizes.lg * 1.6 }}
            >
              Приложение адаптировано для людей со слабым зрением:{'\n'}
              • Большой текст{'\n'}
              • Высокий контраст{'\n'}
              • Простая навигация
            </Text>

            {/* Reduce Motion Toggle */}
            <View className="bg-surface rounded-2xl p-6 border border-border gap-4">
              <View className="flex-row justify-between items-center">
                <Text
                  className="text-foreground font-semibold flex-1"
                  style={{ fontSize: fontSizes.lg }}
                  accessibilityLabel="Уменьшить эффекты и анимации"
                >
                  Уменьшить эффекты и анимации
                </Text>
                
                <Switch
                  value={reduceMotion}
                  onValueChange={handleToggleReduceMotion}
                  accessible={true}
                  accessibilityRole="switch"
                  accessibilityState={{ checked: reduceMotion }}
                  accessibilityLabel="Переключатель для уменьшения эффектов"
                  accessibilityHint="Отключает анимации для удобства"
                />
              </View>
              
              <Text
                className="text-muted"
                style={{ fontSize: fontSizes.base, lineHeight: fontSizes.base * 1.5 }}
              >
                Отключает плавные анимации для удобства использования.
              </Text>
            </View>
          </View>

          {/* Button */}
          <Pressable
            onPress={handleCompleteOnboarding}
            accessible={true}
            accessibilityRole="button"
            accessibilityLabel="Перейти к словам"
            accessibilityHint="Завершить настройку и начать обучение"
            className="w-full bg-primary rounded-2xl py-4 items-center"
            style={({ pressed }) => ({
              opacity: pressed ? 0.8 : 1,
              transform: [{ scale: pressed ? 0.97 : 1 }],
            })}
          >
            <Text
              className="text-background font-bold text-center"
              style={{ fontSize: fontSizes.xl }}
            >
              Перейти к словам
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
