import { View, Text, ScrollView, Pressable } from 'react-native';
import { useMemo, useState } from 'react';
import { ScreenContainer } from '@/components/screen-container';
import { grammarLessons } from '@/lib/language-lessons';
import { useAchievements } from '@/lib/achievements-context';
import { useStatistics } from '@/lib/statistics-context';

export default function GrammarScreen() {
  const [selectedId, setSelectedId] = useState(grammarLessons[0].id);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const { addPoints } = useAchievements();
  const { recordReview } = useStatistics();
  const lesson = grammarLessons.find(item => item.id === selectedId) || grammarLessons[0];

  const result = useMemo(() => {
    const total = lesson.quickCheck.length;
    const correct = lesson.quickCheck.filter(item => {
      const given = (answers[item.prompt] || '').trim().toLowerCase();
      return given === item.answer.trim().toLowerCase();
    }).length;
    return { total, correct, percent: total ? Math.round((correct / total) * 100) : 0 };
  }, [lesson, answers]);

  const selectLesson = (id: string) => {
    setSelectedId(id);
    setAnswers({});
    setSubmitted(false);
  };

  const chooseAnswer = (prompt: string, answer: string) => {
    if (submitted) return;
    setAnswers(prev => ({ ...prev, [prompt]: answer }));
  };

  const submitQuiz = async () => {
    setSubmitted(true);
    await recordReview(result.correct, result.total);
    await addPoints(result.correct * 8 + (result.correct === result.total ? 20 : 0));
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView className="flex-1" contentContainerStyle={{ padding: 24, gap: 16 }}>
        <Text className="text-foreground text-4xl font-bold">Grammatik</Text>
        <Text className="text-muted text-base">
          Kurze Lektionen mit Regeln, Beispielen und einem echten Quiz.
        </Text>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} className="mt-2">
          <View className="flex-row gap-3">
            {grammarLessons.map(item => (
              <Pressable
                key={item.id}
                onPress={() => selectLesson(item.id)}
                className={`rounded-2xl px-4 py-3 ${item.id === lesson.id ? 'bg-primary' : 'bg-card'}`}
              >
                <Text className={`${item.id === lesson.id ? 'text-background' : 'text-foreground'} font-semibold`}>
                  {item.level} · {item.title}
                </Text>
              </Pressable>
            ))}
          </View>
        </ScrollView>

        <View className="bg-card rounded-3xl p-5 gap-4">
          <View>
            <Text className="text-foreground text-2xl font-bold">{lesson.title}</Text>
            <Text className="text-muted mt-1">{lesson.topic}</Text>
          </View>

          <Text className="text-foreground text-base leading-6">{lesson.explanation}</Text>

          <View className="gap-2">
            <Text className="text-foreground text-lg font-semibold">Tipps</Text>
            {lesson.tips.map((tip) => (
              <Text key={tip} className="text-muted">• {tip}</Text>
            ))}
          </View>

          <View className="gap-3">
            <Text className="text-foreground text-lg font-semibold">Beispiele</Text>
            {lesson.examples.map((example) => (
              <View key={example.de} className="bg-background rounded-2xl p-4">
                <Text className="text-foreground font-medium">{example.de}</Text>
                <Text className="text-muted mt-1">{example.hint}</Text>
              </View>
            ))}
          </View>

          <View className="gap-3">
            <Text className="text-foreground text-lg font-semibold">Quiz</Text>
            {lesson.quickCheck.map((item) => {
              const options = Array.from(new Set([
                item.answer,
                item.answer.toLowerCase(),
                item.answer === 'Der' ? 'Die' : 'Der',
                item.answer === 'den' ? 'der' : 'den',
                item.answer === 'die' ? 'das' : 'die',
                item.answer === 'das' ? 'den' : 'das',
                item.answer === 'habe' ? 'hat' : 'habe',
                item.answer === 'sprechen' ? 'sprecht' : 'sprechen',
              ])).slice(0, 4);
              const selected = answers[item.prompt];
              const isCorrect = submitted && selected?.trim().toLowerCase() === item.answer.trim().toLowerCase();
              return (
                <View key={item.prompt} className="border border-border rounded-2xl p-4 gap-3">
                  <Text className="text-foreground">{item.prompt}</Text>
                  <View className="flex-row flex-wrap gap-2">
                    {options.map((option) => (
                      <Pressable
                        key={option}
                        onPress={() => chooseAnswer(item.prompt, option)}
                        className={`rounded-2xl px-4 py-2 ${selected === option ? 'bg-primary' : 'bg-background'}`}
                      >
                        <Text className={`${selected === option ? 'text-background' : 'text-foreground'} font-semibold`}>
                          {option}
                        </Text>
                      </Pressable>
                    ))}
                  </View>
                  {submitted && (
                    <Text className={`${isCorrect ? 'text-success' : 'text-error'} font-semibold`}>
                      {isCorrect ? 'Richtig beantwortet' : `Lösung: ${item.answer}`}
                    </Text>
                  )}
                </View>
              );
            })}
          </View>

          {!submitted ? (
            <Pressable onPress={submitQuiz} className="bg-primary rounded-2xl p-4 items-center">
              <Text className="text-background text-lg font-bold">Quiz auswerten</Text>
            </Pressable>
          ) : (
            <View className="bg-success rounded-2xl p-4 gap-2">
              <Text className="text-background text-xl font-bold">Ergebnis: {result.correct}/{result.total}</Text>
              <Text className="text-background">Genauigkeit: {result.percent}% · Bonuspunkte wurden gutgeschrieben.</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
