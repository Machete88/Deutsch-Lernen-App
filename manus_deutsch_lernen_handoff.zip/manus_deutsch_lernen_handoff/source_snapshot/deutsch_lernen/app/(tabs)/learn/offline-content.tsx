import { View, Text, ScrollView, Pressable, FlatList } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useOfflineContent } from '@/lib/offline-content-context';
import { useFontSizes } from '@/hooks/use-accessibility';
import { useState } from 'react';

export default function OfflineContentScreen() {
  const { settings } = useSettings();
  const {
    offlineContent,
    isDownloading,
    downloadProgress,
    downloadedSize,
    totalSize,
    downloadContent,
    deleteContent,
    isLoading,
  } = useOfflineContent();
  const fontSizes = useFontSizes(settings.fontSizeLevel);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  const handleDownload = async (id: string) => {
    try {
      setDownloadingId(id);
      await downloadContent(id);
    } catch (err) {
      console.error('Download error:', err);
    } finally {
      setDownloadingId(null);
    }
  };

  if (isLoading) {
    return (
      <ScreenContainer className="bg-background items-center justify-center">
        <Text className="text-foreground" style={{ fontSize: fontSizes.lg }}>
          Wird geladen...
        </Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="px-6 py-8 gap-8">
          {/* Header */}
          <View className="gap-2">
            <Text
              className="text-foreground font-bold"
              style={{ fontSize: fontSizes['4xl'] }}
              accessibilityRole="header"
            >
              Offline-Inhalte
            </Text>
            
            <Text
              className="text-muted"
              style={{ fontSize: fontSizes.base }}
            >
              Lade Inhalte herunter für Offline-Nutzung
            </Text>
          </View>

          {/* Storage Info */}
          <View className="bg-surface rounded-2xl p-6 gap-4">
            <View className="gap-2">
              <View className="flex-row justify-between items-center">
                <Text
                  className="text-muted font-semibold"
                  style={{ fontSize: fontSizes.base }}
                >
                  Speichernutzung
                </Text>
                <Text
                  className="text-foreground font-bold"
                  style={{ fontSize: fontSizes.base }}
                >
                  {downloadedSize.toFixed(1)}/{totalSize.toFixed(1)} MB
                </Text>
              </View>

              <View className="bg-border rounded-full h-3">
                <View
                  className="bg-primary rounded-full h-3"
                  style={{
                    width: `${(downloadedSize / totalSize) * 100}%`,
                  }}
                />
              </View>
            </View>
          </View>

          {/* Content List */}
          <View className="gap-3">
            <Text
              className="text-foreground font-semibold"
              style={{ fontSize: fontSizes.lg }}
            >
              Verfügbare Inhalte
            </Text>

            <FlatList
              data={offlineContent}
              keyExtractor={item => item.id}
              scrollEnabled={false}
              renderItem={({ item }) => (
                <View
                  className={`rounded-2xl p-4 mb-3 gap-3 ${
                    item.downloaded ? 'bg-surface border-2 border-success' : 'bg-surface'
                  }`}
                >
                  <View className="flex-row justify-between items-start">
                    <View className="flex-1 gap-1">
                      <Text
                        className="text-foreground font-bold"
                        style={{ fontSize: fontSizes.base }}
                      >
                        {item.name}
                      </Text>

                      <Text
                        className="text-muted text-sm"
                        style={{ fontSize: fontSizes.sm }}
                      >
                        {item.size} MB
                      </Text>
                    </View>

                    {item.downloaded && (
                      <Text
                        className="text-success font-bold"
                        style={{ fontSize: fontSizes.base }}
                      >
                        ✓
                      </Text>
                    )}
                  </View>

                  {downloadingId === item.id && (
                    <View className="gap-2">
                      <View className="bg-border rounded-full h-2">
                        <View
                          className="bg-primary rounded-full h-2"
                          style={{
                            width: `${downloadProgress}%`,
                          }}
                        />
                      </View>
                      <Text
                        className="text-muted text-xs text-center"
                        style={{ fontSize: fontSizes.xs }}
                      >
                        {downloadProgress}%
                      </Text>
                    </View>
                  )}

                  <View className="flex-row gap-2">
                    {!item.downloaded ? (
                      <Pressable
                        onPress={() => handleDownload(item.id)}
                        disabled={isDownloading || downloadingId === item.id}
                        className="flex-1 bg-primary rounded-2xl py-3 items-center"
                        style={({ pressed }) => ({
                          opacity: pressed && !isDownloading ? 0.8 : 1,
                          transform: [{ scale: pressed && !isDownloading ? 0.97 : 1 }],
                        })}
                      >
                        <Text
                          className="text-background font-bold"
                          style={{ fontSize: fontSizes.base }}
                        >
                          {downloadingId === item.id ? 'Wird heruntergeladen...' : 'Herunterladen'}
                        </Text>
                      </Pressable>
                    ) : (
                      <Pressable
                        onPress={() => deleteContent(item.id)}
                        className="flex-1 bg-error rounded-2xl py-3 items-center"
                        style={({ pressed }) => ({
                          opacity: pressed ? 0.8 : 1,
                          transform: [{ scale: pressed ? 0.97 : 1 }],
                        })}
                      >
                        <Text
                          className="text-background font-bold"
                          style={{ fontSize: fontSizes.base }}
                        >
                          Löschen
                        </Text>
                      </Pressable>
                    )}
                  </View>
                </View>
              )}
            />
          </View>

          {/* Info */}
          <View className="bg-surface border-2 border-border rounded-2xl p-4 gap-2">
            <Text
              className="text-foreground font-semibold"
              style={{ fontSize: fontSizes.base }}
            >
              ℹ️ Hinweis
            </Text>

            <Text
              className="text-muted text-sm"
              style={{ fontSize: fontSizes.sm, lineHeight: fontSizes.sm * 1.5 }}
            >
              Heruntergeladene Inhalte sind auch ohne Internetverbindung verfügbar. Du kannst Inhalte jederzeit löschen, um Speicherplatz freizugeben.
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
