import { View, Text, ScrollView, FlatList, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useExam } from '@/lib/exam-context';
import { useFontSizes } from '@/hooks/use-accessibility';

export default function CertificatesScreen() {
  const router = useRouter();
  const { settings } = useSettings();
  const { certificates } = useExam();
  const fontSizes = useFontSizes(settings.fontSizeLevel);

  const handleBack = () => {
    router.back();
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 px-6 py-8 gap-8">
          {/* Header */}
          <View className="gap-2">
            <Text
              className="text-foreground font-bold"
              style={{ fontSize: fontSizes['5xl'] }}
              accessibilityRole="header"
            >
              Zertifikate
            </Text>
            
            <Text
              className="text-muted"
              style={{ fontSize: fontSizes.lg, lineHeight: fontSizes.lg * 1.5 }}
            >
              Deine erworbenen Zertifikate
            </Text>
          </View>

          {/* Certificates List */}
          {certificates.length > 0 ? (
            <View className="gap-4">
              <FlatList
                data={certificates}
                keyExtractor={item => item.id}
                scrollEnabled={false}
                renderItem={({ item }) => (
                  <View className="bg-surface rounded-2xl p-6 border-2 border-primary gap-3">
                    <View className="flex-row justify-between items-start">
                      <View className="flex-1">
                        <Text
                          className="text-foreground font-bold"
                          style={{ fontSize: fontSizes.xl }}
                        >
                          🎓 Zertifikat {item.cefrLevel}
                        </Text>
                        
                        <Text
                          className="text-muted mt-2"
                          style={{ fontSize: fontSizes.base }}
                        >
                          Ergebnis: {item.score}%
                        </Text>

                        <Text
                          className="text-muted text-xs mt-1"
                          style={{ fontSize: fontSizes.xs }}
                        >
                          Nr: {item.certificateNumber}
                        </Text>
                      </View>

                      <View className="bg-primary rounded-lg px-3 py-2 items-center">
                        <Text
                          className="text-background font-bold"
                          style={{ fontSize: fontSizes.lg }}
                        >
                          ✓
                        </Text>
                      </View>
                    </View>
                  </View>
                )}
              />
            </View>
          ) : (
            <View className="flex-1 justify-center items-center gap-4">
              <Text
                className="text-muted text-center"
                style={{ fontSize: fontSizes.lg, lineHeight: fontSizes.lg * 1.5 }}
              >
                Du hast noch keine Zertifikate erworben.
              </Text>

              <Text
                className="text-muted text-center"
                style={{ fontSize: fontSizes.base, lineHeight: fontSizes.base * 1.5 }}
              >
                Bestehe eine Prüfung mit mindestens 70%, um ein Zertifikat zu erhalten.
              </Text>
            </View>
          )}

          {/* Back Button */}
          <Pressable
            onPress={handleBack}
            accessible={true}
            accessibilityRole="button"
            className="w-full bg-surface rounded-2xl py-4 border-2 border-border items-center"
            style={({ pressed }) => ({
              opacity: pressed ? 0.8 : 1,
              transform: [{ scale: pressed ? 0.97 : 1 }],
            })}
          >
            <Text
              className="text-foreground font-bold text-center"
              style={{ fontSize: fontSizes.lg }}
            >
              Zurück
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
