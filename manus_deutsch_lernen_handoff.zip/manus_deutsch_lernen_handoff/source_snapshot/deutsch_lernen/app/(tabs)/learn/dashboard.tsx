import { View, Text, ScrollView, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useStatistics } from '@/lib/statistics-context';
import { useFontSizes } from '@/hooks/use-accessibility';
import { useEffect } from 'react';

export default function DashboardScreen() {
  const router = useRouter();
  const { settings } = useSettings();
  const { statistics, isLoading } = useStatistics();
  const fontSizes = useFontSizes(settings.fontSizeLevel);

  if (isLoading) {
    return (
      <ScreenContainer className="bg-background items-center justify-center">
        <Text className="text-foreground" style={{ fontSize: fontSizes.lg }}>
          Wird geladen...
        </Text>
      </ScreenContainer>
    );
  }

  if (!statistics) {
    return (
      <ScreenContainer className="bg-background items-center justify-center">
        <Text className="text-foreground" style={{ fontSize: fontSizes.lg }}>
          Keine Statistiken verfügbar
        </Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="px-6 py-8 gap-8">
          {/* Header */}
          <View className="gap-2">
            <Text
              className="text-foreground font-bold"
              style={{ fontSize: fontSizes['4xl'] }}
              accessibilityRole="header"
            >
              Dein Fortschritt
            </Text>
            
            <Text
              className="text-muted"
              style={{ fontSize: fontSizes.base }}
            >
              Überblick über dein Lernfortschritt
            </Text>
          </View>

          {/* Main Stats Cards */}
          <View className="gap-4">
            {/* Streak Card */}
            <View className="bg-surface border-2 border-primary rounded-2xl p-6">
              <Text
                className="text-muted font-semibold mb-2"
                style={{ fontSize: fontSizes.base }}
              >
                🔥 Aktuelle Serie
              </Text>

              <Text
                className="text-primary font-bold"
                style={{ fontSize: fontSizes['5xl'] }}
              >
                {statistics.currentStreak}
              </Text>

              <Text
                className="text-muted text-sm mt-2"
                style={{ fontSize: fontSizes.sm }}
              >
                Tage in Folge
              </Text>
            </View>

            {/* Accuracy Card */}
            <View className="bg-surface border-2 border-success rounded-2xl p-6">
              <Text
                className="text-muted font-semibold mb-2"
                style={{ fontSize: fontSizes.base }}
              >
                ✓ Genauigkeit
              </Text>

              <Text
                className="text-success font-bold"
                style={{ fontSize: fontSizes['5xl'] }}
              >
                {statistics.averageAccuracy}%
              </Text>

              <Text
                className="text-muted text-sm mt-2"
                style={{ fontSize: fontSizes.sm }}
              >
                Durchschnittliche Genauigkeit
              </Text>
            </View>

            {/* Words Learned Card */}
            <View className="bg-surface border-2 border-primary rounded-2xl p-6">
              <Text
                className="text-muted font-semibold mb-2"
                style={{ fontSize: fontSizes.base }}
              >
                📚 Gelernte Wörter
              </Text>

              <Text
                className="text-primary font-bold"
                style={{ fontSize: fontSizes['5xl'] }}
              >
                {statistics.totalWordsLearned}
              </Text>

              <Text
                className="text-muted text-sm mt-2"
                style={{ fontSize: fontSizes.sm }}
              >
                Insgesamt gelernt
              </Text>
            </View>
          </View>

          {/* Additional Stats */}
          <View className="gap-3">
            <Text
              className="text-foreground font-semibold"
              style={{ fontSize: fontSizes.lg }}
            >
              Weitere Statistiken
            </Text>

            <View className="gap-2">
              <View className="flex-row justify-between items-center bg-surface rounded-2xl p-4">
                <Text className="text-muted" style={{ fontSize: fontSizes.base }}>
                  Längste Serie
                </Text>
                <Text className="text-foreground font-bold" style={{ fontSize: fontSizes.lg }}>
                  {statistics.longestStreak} Tage
                </Text>
              </View>

              <View className="flex-row justify-between items-center bg-surface rounded-2xl p-4">
                <Text className="text-muted" style={{ fontSize: fontSizes.base }}>
                  Überprüfte Wörter
                </Text>
                <Text className="text-foreground font-bold" style={{ fontSize: fontSizes.lg }}>
                  {statistics.totalWordsReviewed}
                </Text>
              </View>

              <View className="flex-row justify-between items-center bg-surface rounded-2xl p-4">
                <Text className="text-muted" style={{ fontSize: fontSizes.base }}>
                  Richtige Antworten
                </Text>
                <Text className="text-foreground font-bold" style={{ fontSize: fontSizes.lg }}>
                  {statistics.totalCorrectAnswers}/{statistics.totalAnswers}
                </Text>
              </View>
            </View>
          </View>

          {/* Action Buttons */}
          <View className="gap-3">
            <Pressable
              onPress={() => router.push('/(tabs)/learn/learn-card')}
              className="bg-primary rounded-2xl py-4 items-center"
              style={({ pressed }) => ({
                opacity: pressed ? 0.8 : 1,
                transform: [{ scale: pressed ? 0.97 : 1 }],
              })}
            >
              <Text
                className="text-background font-bold"
                style={{ fontSize: fontSizes.lg }}
              >
                Weiter lernen
              </Text>
            </Pressable>

            <Pressable
              onPress={() => router.push('/(tabs)/review')}
              className="bg-surface border-2 border-primary rounded-2xl py-4 items-center"
              style={({ pressed }) => ({
                opacity: pressed ? 0.8 : 1,
                transform: [{ scale: pressed ? 0.97 : 1 }],
              })}
            >
              <Text
                className="text-primary font-bold"
                style={{ fontSize: fontSizes.lg }}
              >
                Überprüfen
              </Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
