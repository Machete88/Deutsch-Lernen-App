import { View, Text, ScrollView, Pressable, FlatList } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useAchievements } from '@/lib/achievements-context';
import { useFontSizes } from '@/hooks/use-accessibility';

export default function AchievementsScreen() {
  const router = useRouter();
  const { settings } = useSettings();
  const { achievements, userRank, totalPoints, unlockedCount, isLoading } = useAchievements();
  const fontSizes = useFontSizes(settings.fontSizeLevel);

  if (isLoading) {
    return (
      <ScreenContainer className="bg-background items-center justify-center">
        <Text className="text-foreground" style={{ fontSize: fontSizes.lg }}>
          Wird geladen...
        </Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="px-6 py-8 gap-8">
          {/* Header */}
          <View className="gap-2">
            <Text
              className="text-foreground font-bold"
              style={{ fontSize: fontSizes['4xl'] }}
              accessibilityRole="header"
            >
              Achievements
            </Text>
            
            <Text
              className="text-muted"
              style={{ fontSize: fontSizes.base }}
            >
              Deine Erfolge und Fortschritt
            </Text>
          </View>

          {/* User Rank Card */}
          <View className="bg-gradient-to-r from-primary to-primary rounded-2xl p-6 gap-4">
            <View className="gap-2">
              <Text
                className="text-background font-semibold"
                style={{ fontSize: fontSizes.base }}
              >
                Dein Rang
              </Text>

              <Text
                className="text-background font-bold"
                style={{ fontSize: fontSizes['5xl'] }}
              >
                {userRank.level}
              </Text>
            </View>

            <View className="gap-2">
              <View className="flex-row justify-between items-center">
                <Text
                  className="text-background text-sm"
                  style={{ fontSize: fontSizes.sm }}
                >
                  Punkte
                </Text>
                <Text
                  className="text-background font-bold"
                  style={{ fontSize: fontSizes.lg }}
                >
                  {totalPoints}/{userRank.nextLevelPoints}
                </Text>
              </View>

              <View className="bg-background rounded-full h-2">
                <View
                  className="bg-success rounded-full h-2"
                  style={{
                    width: `${(totalPoints / userRank.nextLevelPoints) * 100}%`,
                  }}
                />
              </View>
            </View>
          </View>

          {/* Achievements Stats */}
          <View className="flex-row gap-4">
            <View className="flex-1 bg-surface rounded-2xl p-4">
              <Text
                className="text-muted font-semibold mb-2"
                style={{ fontSize: fontSizes.sm }}
              >
                Freigeschaltet
              </Text>
              <Text
                className="text-primary font-bold"
                style={{ fontSize: fontSizes['3xl'] }}
              >
                {unlockedCount}/{achievements.length}
              </Text>
            </View>

            <View className="flex-1 bg-surface rounded-2xl p-4">
              <Text
                className="text-muted font-semibold mb-2"
                style={{ fontSize: fontSizes.sm }}
              >
                Punkte
              </Text>
              <Text
                className="text-success font-bold"
                style={{ fontSize: fontSizes['3xl'] }}
              >
                {totalPoints}
              </Text>
            </View>
          </View>

          {/* Achievements List */}
          <View className="gap-3">
            <Text
              className="text-foreground font-semibold"
              style={{ fontSize: fontSizes.lg }}
            >
              Alle Achievements
            </Text>

            <FlatList
              data={achievements}
              keyExtractor={item => item.id}
              scrollEnabled={false}
              renderItem={({ item }) => (
                <View
                  className={`rounded-2xl p-4 mb-3 flex-row gap-4 items-start ${
                    item.unlocked ? 'bg-surface border-2 border-success' : 'bg-surface opacity-50'
                  }`}
                >
                  <Text
                    style={{ fontSize: fontSizes['3xl'] }}
                  >
                    {item.icon}
                  </Text>

                  <View className="flex-1 gap-1">
                    <Text
                      className="text-foreground font-bold"
                      style={{ fontSize: fontSizes.base }}
                    >
                      {item.name}
                    </Text>

                    <Text
                      className="text-muted text-sm"
                      style={{ fontSize: fontSizes.sm, lineHeight: fontSizes.sm * 1.4 }}
                    >
                      {item.description}
                    </Text>

                    {!item.unlocked && (
                      <View className="mt-2 gap-1">
                        <View className="flex-row justify-between items-center">
                          <Text
                            className="text-muted text-xs"
                            style={{ fontSize: fontSizes.xs }}
                          >
                            Fortschritt
                          </Text>
                          <Text
                            className="text-muted text-xs font-bold"
                            style={{ fontSize: fontSizes.xs }}
                          >
                            {item.progress}/{item.maxProgress}
                          </Text>
                        </View>

                        <View className="bg-border rounded-full h-1.5">
                          <View
                            className="bg-primary rounded-full h-1.5"
                            style={{
                              width: `${(item.progress / item.maxProgress) * 100}%`,
                            }}
                          />
                        </View>
                      </View>
                    )}

                    {item.unlocked && (
                      <Text
                        className="text-success text-xs font-bold mt-2"
                        style={{ fontSize: fontSizes.xs }}
                      >
                        ✓ Freigeschaltet
                      </Text>
                    )}
                  </View>
                </View>
              )}
            />
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
