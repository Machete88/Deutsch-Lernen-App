import { View, Text, ScrollView, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { LearningCard } from '@/components/learning-card';
import { useSettings } from '@/lib/settings-context';
import { useVocabulary } from '@/lib/vocabulary-context';
import { useFontSizes } from '@/hooks/use-accessibility';
import { useState, useEffect } from 'react';
import { Word } from '@/lib/types';

export default function LearnCardScreen() {
  const router = useRouter();
  const { settings } = useSettings();
  const { currentSet, words, getNewWords, recordWordResult } = useVocabulary();
  const fontSizes = useFontSizes(settings.fontSizeLevel);
  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [cardsToLearn, setCardsToLearn] = useState<Word[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Lade neue Wörter für das aktuelle Set
    if (currentSet) {
      const setWords = words.filter(w => w.category === currentSet.category);
      const newWords = getNewWords(setWords.length);
      setCardsToLearn(newWords.length > 0 ? newWords : setWords);
      setIsLoading(false);
    }
  }, [currentSet, words]);

  if (isLoading || cardsToLearn.length === 0) {
    return (
      <ScreenContainer className="bg-background">
        <View className="flex-1 justify-center items-center px-6">
          <Text
            className="text-foreground font-bold text-center"
            style={{ fontSize: fontSizes.xl }}
          >
            Keine Wörter zum Lernen
          </Text>
          <Pressable
            onPress={() => router.back()}
            className="mt-6 bg-primary rounded-2xl px-6 py-3"
          >
            <Text className="text-background font-bold" style={{ fontSize: fontSizes.base }}>
              Zurück
            </Text>
          </Pressable>
        </View>
      </ScreenContainer>
    );
  }

  const currentWord = cardsToLearn[currentWordIndex];
  const progress = Math.round(((currentWordIndex + 1) / cardsToLearn.length) * 100);
  const isLastCard = currentWordIndex === cardsToLearn.length - 1;

  const handleSwipeRight = async () => {
    // Easy - Wort als gelernt markieren
    await recordWordResult(currentWord.id, 'easy');
    
    if (isLastCard) {
      router.back();
    } else {
      setCurrentWordIndex(currentWordIndex + 1);
    }
  };

  const handleSwipeLeft = async () => {
    // Hard - Wort als schwer markieren
    await recordWordResult(currentWord.id, 'hard');
    
    if (isLastCard) {
      router.back();
    } else {
      setCurrentWordIndex(currentWordIndex + 1);
    }
  };

  const handleAudioPlay = () => {
    // TODO: Audio-Wiedergabe implementieren
    console.log('Play audio:', currentWord.audioWordUrl);
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 px-6 py-8 gap-8 justify-between">
          {/* Progress */}
          <View className="gap-2">
            <View className="flex-row justify-between items-center">
              <Text
                className="text-foreground font-semibold"
                style={{ fontSize: fontSizes.base }}
              >
                {currentSet?.name}
              </Text>
              <Text
                className="text-primary font-bold"
                style={{ fontSize: fontSizes.base }}
              >
                {progress}%
              </Text>
            </View>

            {/* Progress Bar */}
            <View className="h-2 bg-border rounded-full overflow-hidden">
              <View
                className="h-full bg-primary"
                style={{ width: `${progress}%` }}
              />
            </View>

            <Text
              className="text-muted text-xs"
              style={{ fontSize: fontSizes.xs }}
            >
              {currentWordIndex + 1} von {cardsToLearn.length}
            </Text>
          </View>

          {/* Learning Card */}
          <View className="flex-1 justify-center">
            <LearningCard
              word={currentWord}
              onSwipeRight={handleSwipeRight}
              onSwipeLeft={handleSwipeLeft}
              onAudioPlay={handleAudioPlay}
            />
          </View>

          {/* Instructions */}
          <View className="bg-surface rounded-2xl p-4 border border-border gap-2">
            <Text
              className="text-foreground font-semibold"
              style={{ fontSize: fontSizes.base }}
            >
              Wie geht es dir mit diesem Wort?
            </Text>

            <View className="flex-row gap-2 mt-2">
              <Pressable
                onPress={handleSwipeLeft}
                accessible={true}
                accessibilityRole="button"
                className="flex-1 bg-error rounded-lg py-2 items-center"
                style={({ pressed }) => ({
                  opacity: pressed ? 0.8 : 1,
                  transform: [{ scale: pressed ? 0.95 : 1 }],
                })}
              >
                <Text
                  className="text-background font-semibold"
                  style={{ fontSize: fontSizes.sm }}
                >
                  Schwer
                </Text>
              </Pressable>

              <Pressable
                onPress={handleSwipeRight}
                accessible={true}
                accessibilityRole="button"
                className="flex-1 bg-success rounded-lg py-2 items-center"
                style={({ pressed }) => ({
                  opacity: pressed ? 0.8 : 1,
                  transform: [{ scale: pressed ? 0.95 : 1 }],
                })}
              >
                <Text
                  className="text-background font-semibold"
                  style={{ fontSize: fontSizes.sm }}
                >
                  Leicht
                </Text>
              </Pressable>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
