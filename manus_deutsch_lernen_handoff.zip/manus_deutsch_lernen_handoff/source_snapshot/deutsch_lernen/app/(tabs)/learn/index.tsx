import { View, Text, ScrollView, Pressable, FlatList } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useVocabulary } from '@/lib/vocabulary-context';
import { useFontSizes } from '@/hooks/use-accessibility';
import { LearningSet } from '@/lib/types';
import { t } from '@/lib/i18n';

export default function LearnScreen() {
  const router = useRouter();
  const { settings } = useSettings();
  const { learningSets, currentSet, setCurrentSet } = useVocabulary();
  const fontSizes = useFontSizes(settings.fontSizeLevel);

  const handleSelectSet = async (set: LearningSet) => {
    await setCurrentSet(set);
    router.push('./learn-card');
  };

  const handleContinueSet = async () => {
    if (currentSet) {
      router.push('./learn-card');
    }
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 px-6 py-8 gap-8">
          {/* Header */}
          <View className="gap-2">
            <Text
              className="text-foreground font-bold"
              style={{ fontSize: fontSizes['5xl'] }}
              accessibilityRole="header"
            >
              {t('learn')}
            </Text>
            
            <Text
              className="text-muted"
              style={{ fontSize: fontSizes.lg, lineHeight: fontSizes.lg * 1.5 }}
            >
              {t('selectCategory')}
            </Text>
          </View>


          <View className="gap-3">
            <Pressable
              onPress={() => router.push('./grammar')}
              className="w-full bg-card rounded-2xl p-5"
            >
              <Text className="text-foreground text-xl font-bold">Grammatik</Text>
              <Text className="text-muted mt-1">Kurze Regeln, Beispiele und Mini-Checks.</Text>
            </Pressable>

            <Pressable
              onPress={() => router.push('./sentence-builder')}
              className="w-full bg-card rounded-2xl p-5"
            >
              <Text className="text-foreground text-xl font-bold">Satzbau</Text>
              <Text className="text-muted mt-1">Baue korrekte deutsche Sätze aus Wortbausteinen.</Text>
            </Pressable>

            <Pressable
              onPress={() => router.push('./study-plan')}
              className="w-full bg-card rounded-2xl p-5"
            >
              <Text className="text-foreground text-xl font-bold">Tagesplan</Text>
              <Text className="text-muted mt-1">Personalisierte Empfehlungen für heute.</Text>
            </Pressable>
          </View>

          {/* Exam Mode Button */}
          <Pressable
            onPress={() => router.push('./exam-mode')}
            accessible={true}
            accessibilityRole="button"
            accessibilityLabel="Prüfungsmodus"
            className="w-full bg-success rounded-2xl p-6 items-center"
            style={({ pressed }) => ({
              opacity: pressed ? 0.8 : 1,
              transform: [{ scale: pressed ? 0.97 : 1 }],
            })}
          >
            <Text
              className="text-background font-bold text-center"
              style={{ fontSize: fontSizes.lg }}
            >
              🎓 Prüfungsmodus
            </Text>
            <Text
              className="text-background text-center mt-1"
              style={{ fontSize: fontSizes.sm }}
            >
              A1, A2, B1, B2 Prüfungen
            </Text>
          </Pressable>

          {/* Continue Button */}
          {currentSet && (
            <Pressable
              onPress={handleContinueSet}
              accessible={true}
              accessibilityRole="button"
              accessibilityLabel={`Letztes Set fortsetzen: ${currentSet.name}`}
              className="w-full bg-primary rounded-2xl p-6 items-center"
              style={({ pressed }) => ({
                opacity: pressed ? 0.8 : 1,
                transform: [{ scale: pressed ? 0.97 : 1 }],
              })}
            >
              <Text
                className="text-background font-bold text-center"
                style={{ fontSize: fontSizes.lg }}
              >
                Letztes Set fortsetzen
              </Text>
              <Text
                className="text-background text-center mt-2"
                style={{ fontSize: fontSizes.base }}
              >
                {currentSet.name}
              </Text>
            </Pressable>
          )}

          {/* Learning Sets List */}
          <View className="gap-4">
            <FlatList
              data={learningSets}
              keyExtractor={item => item.id}
              scrollEnabled={false}
              renderItem={({ item }) => (
                <Pressable
                  onPress={() => handleSelectSet(item)}
                  accessible={true}
                  accessibilityRole="button"
                  accessibilityLabel={`${item.name}, ${item.wordCount} Wörter`}
                  className="bg-surface rounded-2xl p-6 border-2 border-border"
                  style={({ pressed }) => ({
                    opacity: pressed ? 0.8 : 1,
                    transform: [{ scale: pressed ? 0.97 : 1 }],
                  })}
                >
                  <Text
                    className="text-foreground font-bold"
                    style={{ fontSize: fontSizes.xl }}
                  >
                    {item.name}
                  </Text>
                  
                  <Text
                    className="text-muted mt-2"
                    style={{ fontSize: fontSizes.base }}
                  >
                    {item.wordCount} Wörter
                  </Text>
                  
                  <Text
                    className="text-muted mt-1"
                    style={{ fontSize: fontSizes.sm }}
                  >
                    {item.description}
                  </Text>
                </Pressable>
              )}
            />
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
