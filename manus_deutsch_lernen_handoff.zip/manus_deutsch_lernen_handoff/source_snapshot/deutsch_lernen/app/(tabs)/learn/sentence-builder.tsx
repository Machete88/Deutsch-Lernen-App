import { View, Text, ScrollView, Pressable } from 'react-native';
import { useMemo, useState } from 'react';
import { ScreenContainer } from '@/components/screen-container';
import { sentenceChallenges } from '@/lib/language-lessons';
import { useAchievements } from '@/lib/achievements-context';
import { useStatistics } from '@/lib/statistics-context';

export default function SentenceBuilderScreen() {
  const [challengeIndex, setChallengeIndex] = useState(0);
  const [selected, setSelected] = useState<string[]>([]);
  const [streak, setStreak] = useState(0);
  const [roundScore, setRoundScore] = useState(0);
  const current = sentenceChallenges[challengeIndex];
  const { addPoints, totalPoints } = useAchievements();
  const { recordLearning, recordReview } = useStatistics();

  const remaining = useMemo(
    () => current.fragments.filter(fragment => {
      const usedCount = selected.filter(s => s === fragment).length;
      const totalCount = current.fragments.filter(f => f === fragment).length;
      return usedCount < totalCount;
    }),
    [current, selected]
  );
  const solved = selected.join(' ') === current.solution.join(' ');
  const isCompleteButWrong = selected.length === current.solution.length && !solved;

  const addFragment = (fragment: string) => setSelected(prev => [...prev, fragment]);
  const removeLast = () => setSelected(prev => prev.slice(0, -1));
  const reset = () => setSelected([]);
  const next = async () => {
    const gained = 15 + streak * 5;
    await addPoints(gained);
    await recordLearning(1);
    await recordReview(1, 1);
    setRoundScore(gained);
    setStreak(prev => prev + 1);
    setSelected([]);
    setChallengeIndex(prev => (prev + 1) % sentenceChallenges.length);
  };

  const tryAgain = async () => {
    await recordReview(0, 1);
    setStreak(0);
    setSelected([]);
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView className="flex-1" contentContainerStyle={{ padding: 24, gap: 16 }}>
        <Text className="text-foreground text-4xl font-bold">Satzbau</Text>
        <Text className="text-muted">Ordne Wörter zu korrekten deutschen Sätzen.</Text>

        <View className="flex-row gap-3">
          <View className="bg-card rounded-2xl px-4 py-3 flex-1">
            <Text className="text-muted">Serie</Text>
            <Text className="text-foreground text-2xl font-bold">{streak}</Text>
          </View>
          <View className="bg-card rounded-2xl px-4 py-3 flex-1">
            <Text className="text-muted">Punkte</Text>
            <Text className="text-foreground text-2xl font-bold">{totalPoints}</Text>
          </View>
          <View className="bg-card rounded-2xl px-4 py-3 flex-1">
            <Text className="text-muted">Letzte Runde</Text>
            <Text className="text-foreground text-2xl font-bold">+{roundScore}</Text>
          </View>
        </View>

        <View className="bg-card rounded-3xl p-5 gap-4">
          <Text className="text-foreground text-2xl font-bold">{current.topic}</Text>
          <Text className="text-muted">{current.prompt}</Text>

          <View className="bg-background rounded-2xl p-4 min-h-[90px] justify-center">
            <Text className="text-foreground text-lg">
              {selected.length ? selected.join(' ') : 'Tippe unten auf die Bausteine.'}
            </Text>
          </View>

          <View className="flex-row flex-wrap gap-3">
            {remaining.map((fragment, index) => (
              <Pressable
                key={`${fragment}-${index}`}
                onPress={() => addFragment(fragment)}
                className="bg-primary rounded-2xl px-4 py-3"
              >
                <Text className="text-background font-semibold">{fragment}</Text>
              </Pressable>
            ))}
          </View>

          <View className="flex-row gap-3">
            {selected.length > 0 && (
              <Pressable onPress={removeLast} className="bg-muted rounded-2xl px-4 py-3 self-start">
                <Text className="text-foreground font-semibold">Letztes Wort entfernen</Text>
              </Pressable>
            )}
            {selected.length > 0 && (
              <Pressable onPress={reset} className="bg-muted rounded-2xl px-4 py-3 self-start">
                <Text className="text-foreground font-semibold">Zurücksetzen</Text>
              </Pressable>
            )}
          </View>

          <View className="border border-border rounded-2xl p-4">
            <Text className="text-muted">Übersetzung</Text>
            <Text className="text-foreground mt-1">{current.translation}</Text>
          </View>

          {solved && (
            <View className="bg-success rounded-2xl p-4 gap-2">
              <Text className="text-background text-lg font-bold">Richtig!</Text>
              <Text className="text-background">Lösung: {current.solution.join(' ')}</Text>
              <Text className="text-background">Du erhältst Punkte und deine Serie steigt.</Text>
              <Pressable onPress={next} className="bg-background rounded-2xl px-4 py-3 self-start mt-2">
                <Text className="text-foreground font-semibold">Nächste Aufgabe</Text>
              </Pressable>
            </View>
          )}

          {isCompleteButWrong && (
            <View className="bg-card rounded-2xl p-4 gap-2 border border-error">
              <Text className="text-foreground text-lg font-bold">Fast – aber noch nicht korrekt</Text>
              <Text className="text-muted">Deine aktuelle Reihenfolge passt nicht. Versuche es noch einmal.</Text>
              <Pressable onPress={tryAgain} className="bg-error rounded-2xl px-4 py-3 self-start mt-2">
                <Text className="text-background font-semibold">Neu versuchen</Text>
              </Pressable>
            </View>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
