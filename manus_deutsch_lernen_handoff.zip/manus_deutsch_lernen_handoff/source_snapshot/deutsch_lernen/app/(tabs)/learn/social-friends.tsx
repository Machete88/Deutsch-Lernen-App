import { View, Text, ScrollView, Pressable, FlatList } from 'react-native';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useSocial } from '@/lib/social-context';
import { useFontSizes } from '@/hooks/use-accessibility';

export default function SocialFriendsScreen() {
  const { settings } = useSettings();
  const { friends, friendRequests, addFriend, acceptFriendRequest, rejectFriendRequest, isLoading } = useSocial();
  const fontSizes = useFontSizes(settings.fontSizeLevel);

  if (isLoading) {
    return (
      <ScreenContainer className="bg-background items-center justify-center">
        <Text className="text-foreground" style={{ fontSize: fontSizes.lg }}>
          Wird geladen...
        </Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="px-6 py-8 gap-8">
          {/* Header */}
          <View className="gap-2">
            <Text
              className="text-foreground font-bold"
              style={{ fontSize: fontSizes['4xl'] }}
              accessibilityRole="header"
            >
              Freunde
            </Text>
            
            <Text
              className="text-muted"
              style={{ fontSize: fontSizes.base }}
            >
              Verbinde dich mit anderen Lernenden
            </Text>
          </View>

          {/* Friend Requests */}
          {friendRequests.length > 0 && (
            <View className="gap-3">
              <Text
                className="text-foreground font-semibold"
                style={{ fontSize: fontSizes.lg }}
              >
                Freundschaftsanfragen ({friendRequests.length})
              </Text>

              <FlatList
                data={friendRequests}
                keyExtractor={item => item.id}
                scrollEnabled={false}
                renderItem={({ item }) => (
                  <View className="bg-surface rounded-2xl p-4 mb-3 gap-3">
                    <View className="gap-1">
                      <Text
                        className="text-foreground font-bold"
                        style={{ fontSize: fontSizes.base }}
                      >
                        {item.username}
                      </Text>

                      <Text
                        className="text-muted text-sm"
                        style={{ fontSize: fontSizes.sm }}
                      >
                        Level: {item.level} • {item.points} Punkte
                      </Text>
                    </View>

                    <View className="flex-row gap-2">
                      <Pressable
                        onPress={() => acceptFriendRequest(item.id)}
                        className="flex-1 bg-success rounded-2xl py-3 items-center"
                        style={({ pressed }) => ({
                          opacity: pressed ? 0.8 : 1,
                        })}
                      >
                        <Text
                          className="text-background font-bold"
                          style={{ fontSize: fontSizes.base }}
                        >
                          Akzeptieren
                        </Text>
                      </Pressable>

                      <Pressable
                        onPress={() => rejectFriendRequest(item.id)}
                        className="flex-1 bg-error rounded-2xl py-3 items-center"
                        style={({ pressed }) => ({
                          opacity: pressed ? 0.8 : 1,
                        })}
                      >
                        <Text
                          className="text-background font-bold"
                          style={{ fontSize: fontSizes.base }}
                        >
                          Ablehnen
                        </Text>
                      </Pressable>
                    </View>
                  </View>
                )}
              />
            </View>
          )}

          {/* Friends List */}
          <View className="gap-3">
            <Text
              className="text-foreground font-semibold"
              style={{ fontSize: fontSizes.lg }}
            >
              Meine Freunde ({friends.length})
            </Text>

            {friends.length === 0 ? (
              <View className="bg-surface rounded-2xl p-6 items-center gap-3">
                <Text
                  className="text-muted text-center"
                  style={{ fontSize: fontSizes.base }}
                >
                  Du hast noch keine Freunde hinzugefügt
                </Text>

                <Pressable
                  className="bg-primary rounded-2xl px-6 py-3"
                  style={({ pressed }) => ({
                    opacity: pressed ? 0.8 : 1,
                  })}
                >
                  <Text
                    className="text-background font-bold"
                    style={{ fontSize: fontSizes.base }}
                  >
                    Freunde suchen
                  </Text>
                </Pressable>
              </View>
            ) : (
              <FlatList
                data={friends}
                keyExtractor={item => item.id}
                scrollEnabled={false}
                renderItem={({ item }) => (
                  <View className="bg-surface rounded-2xl p-4 mb-3 flex-row justify-between items-center">
                    <View className="flex-1 gap-1">
                      <Text
                        className="text-foreground font-bold"
                        style={{ fontSize: fontSizes.base }}
                      >
                        {item.username}
                      </Text>

                      <Text
                        className="text-muted text-sm"
                        style={{ fontSize: fontSizes.sm }}
                      >
                        {item.level} • {item.points} Punkte
                      </Text>
                    </View>

                    <Pressable
                      className="bg-primary rounded-full w-12 h-12 items-center justify-center"
                      style={({ pressed }) => ({
                        opacity: pressed ? 0.8 : 1,
                      })}
                    >
                      <Text
                        className="text-background font-bold"
                        style={{ fontSize: fontSizes.lg }}
                      >
                        →
                      </Text>
                    </Pressable>
                  </View>
                )}
              />
            )}
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
