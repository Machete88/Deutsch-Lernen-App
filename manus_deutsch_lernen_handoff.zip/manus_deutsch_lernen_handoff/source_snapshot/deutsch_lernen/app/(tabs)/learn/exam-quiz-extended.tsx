import { View, Text, ScrollView, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useFontSizes } from '@/hooks/use-accessibility';
import { useExtendedExam } from '@/lib/exam-context-extended';
import { t } from '@/lib/i18n';
import { useState } from 'react';

export default function ExamQuizExtendedScreen() {
  const router = useRouter();
  const { settings } = useSettings();
  const fontSizes = useFontSizes(settings.fontSizeLevel);
  const { 
    session, 
    showTranslation, 
    toggleTranslation, 
    getCurrentQuestion, 
    getProgress,
    answerQuestion,
    nextQuestion,
    previousQuestion,
    completeExam,
  } = useExtendedExam();
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);

  if (!session || session.isComplete) {
    return (
      <ScreenContainer className="bg-background">
        <View className="flex-1 justify-center items-center px-6">
          <Text 
            className="text-foreground font-bold text-center"
            style={{ fontSize: fontSizes['3xl'] }}
          >
            Prüfung abgeschlossen
          </Text>
        </View>
      </ScreenContainer>
    );
  }

  const currentQuestion = getCurrentQuestion();
  const progress = getProgress();

  if (!currentQuestion) {
    return (
      <ScreenContainer className="bg-background">
        <View className="flex-1 justify-center items-center px-6">
          <Text 
            className="text-foreground font-bold"
            style={{ fontSize: fontSizes['2xl'] }}
          >
            {t('loading')}
          </Text>
        </View>
      </ScreenContainer>
    );
  }

  const handleAnswerSelect = (optionId: string) => {
    setSelectedAnswer(optionId);
    answerQuestion(currentQuestion.id, optionId);
  };

  const handleNext = () => {
    if (progress.current === progress.total) {
      completeExam();
      router.push('./exam-result');
    } else {
      nextQuestion();
      setSelectedAnswer(null);
    }
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 px-6 py-8 gap-6">
          {/* Header mit Progress */}
          <View className="gap-2">
            <View className="flex-row justify-between items-center">
              <Text 
                className="text-foreground font-bold"
                style={{ fontSize: fontSizes['2xl'] }}
              >
                Frage {progress.current} von {progress.total}
              </Text>
              
              {/* Übersetzungs-Toggle Button */}
              <Pressable
                onPress={toggleTranslation}
                accessible={true}
                accessibilityRole="button"
                accessibilityLabel={showTranslation ? 'Übersetzung ausblenden' : 'Übersetzung anzeigen'}
                className={`px-4 py-2 rounded-lg ${
                  showTranslation ? 'bg-primary' : 'bg-surface border border-border'
                }`}
                style={({ pressed }) => ({
                  opacity: pressed ? 0.8 : 1,
                  transform: [{ scale: pressed ? 0.97 : 1 }],
                })}
              >
                <Text 
                  className={showTranslation ? 'text-background font-semibold' : 'text-foreground font-semibold'}
                  style={{ fontSize: fontSizes.sm }}
                >
                  {showTranslation ? '🌐 РУ' : '🌐 DE'}
                </Text>
              </Pressable>
            </View>

            {/* Progress Bar */}
            <View className="h-2 bg-border rounded-full overflow-hidden">
              <View 
                className="h-full bg-primary"
                style={{ width: `${(progress.current / progress.total) * 100}%` }}
              />
            </View>
          </View>

          {/* Frage in Deutsch */}
          <View className="bg-surface rounded-2xl p-6 gap-3">
            <Text 
              className="text-foreground font-bold"
              style={{ fontSize: fontSizes['xl'] }}
            >
              {currentQuestion.germanText}
            </Text>

            {/* Übersetzung (optional) */}
            {showTranslation && (
              <View className="pt-3 border-t border-border">
                <Text 
                  className="text-muted italic"
                  style={{ fontSize: fontSizes.base }}
                >
                  {currentQuestion.russianTranslation}
                </Text>
              </View>
            )}
          </View>

          {/* Antwort-Optionen */}
          {currentQuestion.options && currentQuestion.options.length > 0 && (
            <View className="gap-3">
              {currentQuestion.options.map((option) => (
                <Pressable
                  key={option.id}
                  onPress={() => handleAnswerSelect(option.id)}
                  accessible={true}
                  accessibilityRole="radio"
                  accessibilityLabel={option.germanText}
                  className={`rounded-2xl p-4 border-2 ${
                    selectedAnswer === option.id
                      ? 'border-primary bg-primary bg-opacity-10'
                      : 'border-border bg-surface'
                  }`}
                  style={({ pressed }) => ({
                    opacity: pressed ? 0.8 : 1,
                    transform: [{ scale: pressed ? 0.97 : 1 }],
                  })}
                >
                  <Text 
                    className={selectedAnswer === option.id ? 'text-foreground font-semibold' : 'text-foreground'}
                    style={{ fontSize: fontSizes.base }}
                  >
                    {option.germanText}
                  </Text>

                  {/* Übersetzung der Option (optional) */}
                  {showTranslation && (
                    <Text 
                      className="text-muted italic mt-2"
                      style={{ fontSize: fontSizes.sm }}
                    >
                      {option.russianTranslation}
                    </Text>
                  )}
                </Pressable>
              ))}
            </View>
          )}

          {/* Navigation Buttons */}
          <View className="flex-row gap-4 mt-6">
            <Pressable
              onPress={previousQuestion}
              disabled={progress.current === 1}
              accessible={true}
              accessibilityRole="button"
              accessibilityLabel="Vorherige Frage"
              className={`flex-1 py-4 rounded-xl items-center ${
                progress.current === 1 ? 'bg-border opacity-50' : 'bg-surface border border-border'
              }`}
              style={({ pressed }) => ({
                opacity: pressed && progress.current > 1 ? 0.8 : 1,
                transform: [{ scale: pressed && progress.current > 1 ? 0.97 : 1 }],
              })}
            >
              <Text 
                className="text-foreground font-semibold"
                style={{ fontSize: fontSizes.base }}
              >
                ← Zurück
              </Text>
            </Pressable>

            <Pressable
              onPress={handleNext}
              disabled={!selectedAnswer}
              accessible={true}
              accessibilityRole="button"
              accessibilityLabel={progress.current === progress.total ? 'Prüfung beenden' : 'Nächste Frage'}
              className={`flex-1 py-4 rounded-xl items-center ${
                selectedAnswer ? 'bg-primary' : 'bg-border opacity-50'
              }`}
              style={({ pressed }) => ({
                opacity: pressed && selectedAnswer ? 0.8 : 1,
                transform: [{ scale: pressed && selectedAnswer ? 0.97 : 1 }],
              })}
            >
              <Text 
                className="text-background font-semibold"
                style={{ fontSize: fontSizes.base }}
              >
                {progress.current === progress.total ? 'Fertig →' : 'Weiter →'}
              </Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
