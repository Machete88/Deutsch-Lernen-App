import { View, Text, ScrollView, Pressable, TextInput, FlatList } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useAIAssistant } from '@/lib/ai-assistant-context';
import { useFontSizes } from '@/hooks/use-accessibility';
import { useState, useEffect } from 'react';

export default function AIAssistantScreen() {
  const router = useRouter();
  const { settings } = useSettings();
  const {
    currentConversation,
    isLoading,
    sendMessage,
    startNewConversation,
    error,
    clearError,
  } = useAIAssistant();
  const fontSizes = useFontSizes(settings.fontSizeLevel);

  const [inputText, setInputText] = useState('');
  const [messages, setMessages] = useState<any[]>([]);

  // Starte neues Gespräch beim Laden
  useEffect(() => {
    const initializeChat = async () => {
      if (!currentConversation) {
        await startNewConversation('Deutsch Lernen');
      } else {
        setMessages(currentConversation.messages);
      }
    };

    initializeChat();
  }, []);

  // Aktualisiere Nachrichten wenn Gespräch sich ändert
  useEffect(() => {
    if (currentConversation) {
      setMessages(currentConversation.messages);
    }
  }, [currentConversation]);

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    try {
      clearError();
      await sendMessage(inputText);
      setInputText('');
    } catch (err) {
      console.error('Error sending message:', err);
    }
  };

  return (
    <ScreenContainer className="bg-background">
      <View className="flex-1 gap-4 px-6 py-6">
        {/* Header */}
        <View className="gap-2">
          <Text
            className="text-foreground font-bold"
            style={{ fontSize: fontSizes['3xl'] }}
            accessibilityRole="header"
          >
            KI-Assistent
          </Text>
          
          <Text
            className="text-muted"
            style={{ fontSize: fontSizes.base }}
          >
            Frag mich alles über Deutsch
          </Text>
        </View>

        {/* Messages */}
        <FlatList
          data={messages}
          keyExtractor={item => item.id}
          renderItem={({ item }) => (
            <View
              className={`mb-4 ${item.role === 'user' ? 'items-end' : 'items-start'}`}
            >
              <View
                className={`rounded-2xl px-4 py-3 max-w-xs ${
                  item.role === 'user'
                    ? 'bg-primary'
                    : 'bg-surface border-2 border-border'
                }`}
              >
                <Text
                  className={`${
                    item.role === 'user' ? 'text-background' : 'text-foreground'
                  }`}
                  style={{ fontSize: fontSizes.base, lineHeight: fontSizes.base * 1.4 }}
                >
                  {item.content}
                </Text>
              </View>
            </View>
          )}
          scrollEnabled={true}
          className="flex-1"
        />

        {/* Error Message */}
        {error && (
          <View className="bg-error rounded-2xl p-3">
            <Text
              className="text-background"
              style={{ fontSize: fontSizes.sm }}
            >
              {error}
            </Text>
          </View>
        )}

        {/* Input */}
        <View className="gap-3 border-t border-border pt-4">
          <View className="flex-row gap-2 items-end">
            <TextInput
              placeholder="Schreib deine Frage..."
              value={inputText}
              onChangeText={setInputText}
              multiline
              editable={!isLoading}
              accessibilityLabel="Nachricht-Eingabe"
              className="flex-1 bg-surface border-2 border-border rounded-2xl px-4 py-3 text-foreground"
              placeholderTextColor="#999"
              style={{ fontSize: fontSizes.base, minHeight: fontSizes.base * 2.5 }}
            />

            <Pressable
              onPress={handleSendMessage}
              disabled={!inputText.trim() || isLoading}
              accessible={true}
              accessibilityRole="button"
              className={`rounded-2xl p-3 items-center justify-center ${
                inputText.trim() && !isLoading ? 'bg-primary' : 'bg-border'
              }`}
              style={({ pressed }) => ({
                opacity: pressed && inputText.trim() && !isLoading ? 0.8 : 1,
                transform: [{ scale: pressed && inputText.trim() && !isLoading ? 0.95 : 1 }],
              })}
            >
              <Text
                className={`font-bold ${
                  inputText.trim() && !isLoading ? 'text-background' : 'text-muted'
                }`}
                style={{ fontSize: fontSizes.lg }}
              >
                ➤
              </Text>
            </Pressable>
          </View>

          {/* Quick Actions */}
          <View className="gap-2">
            <Text
              className="text-muted text-xs"
              style={{ fontSize: fontSizes.xs }}
            >
              Schnelle Fragen:
            </Text>

            <View className="flex-row gap-2 flex-wrap">
              {['Wort erklären', 'Beispiele', 'Aussprache', 'Tipps'].map(action => (
                <Pressable
                  key={action}
                  onPress={() => setInputText(action)}
                  className="bg-surface border border-border rounded-full px-3 py-2"
                >
                  <Text
                    className="text-foreground text-xs"
                    style={{ fontSize: fontSizes.xs }}
                  >
                    {action}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>
        </View>
      </View>
    </ScreenContainer>
  );
}
