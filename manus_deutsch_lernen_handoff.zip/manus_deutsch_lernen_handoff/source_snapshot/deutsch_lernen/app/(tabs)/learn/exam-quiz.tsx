import { View, Text, ScrollView, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useExam } from '@/lib/exam-context';
import { useFontSizes } from '@/hooks/use-accessibility';
import { useState, useEffect } from 'react';

function formatTime(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
}

export default function ExamQuizScreen() {
  const router = useRouter();
  const { settings } = useSettings();
  const { currentSession, submitAnswer, completeExam } = useExam();
  const fontSizes = useFontSizes(settings.fontSizeLevel);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [timeLeft, setTimeLeft] = useState(0);

  useEffect(() => {
    if (!currentSession?.expiresAt) return;
    const updateTime = () => setTimeLeft(Math.max(0, Math.round((currentSession.expiresAt! - Date.now()) / 1000)));
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [currentSession?.expiresAt]);

  useEffect(() => {
    if (timeLeft !== 0 || !currentSession) return;
    handleFinishExam();
  }, [timeLeft]);

  if (!currentSession) {
    return <ScreenContainer className="bg-background"><View className="flex-1 justify-center items-center"><Text className="text-foreground" style={{ fontSize: fontSizes.lg }}>Keine aktive Prüfung</Text></View></ScreenContainer>;
  }

  const currentQuestion = currentSession.questions[currentQuestionIndex];
  const isLastQuestion = currentQuestionIndex === currentSession.questions.length - 1;
  const progress = Math.round(((currentQuestionIndex + 1) / currentSession.questions.length) * 100);

  const handleFinishExam = async () => {
    if (selectedAnswer) await submitAnswer(currentQuestion.id, selectedAnswer);
    const result = await completeExam();
    if (result) {
      router.push({ pathname: './exam-result', params: { score: result.score.toString(), passed: result.passed.toString(), correctAnswers: result.correctAnswers.toString(), totalQuestions: result.totalQuestions.toString(), recommendation: result.recommendation ?? '', certificateNumber: result.certificateNumber ?? '', durationSeconds: `${result.durationSeconds ?? 0}` } });
    }
  };

  const handleNext = async () => {
    if (!selectedAnswer) return;
    await submitAnswer(currentQuestion.id, selectedAnswer);
    if (isLastQuestion) await handleFinishExam();
    else {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer(null);
    }
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 px-6 py-8 gap-8">
          <View className="gap-3">
            <View className="flex-row justify-between items-center">
              <Text className="text-foreground font-semibold" style={{ fontSize: fontSizes.base }}>Frage {currentQuestionIndex + 1} von {currentSession.questions.length}</Text>
              <Text className="text-primary font-bold" style={{ fontSize: fontSizes.base }}>{progress}%</Text>
            </View>
            <View className="h-2 bg-border rounded-full overflow-hidden"><View className="h-full bg-primary" style={{ width: `${progress}%` }} /></View>
            <View className="bg-surface rounded-xl p-3 border border-border"><Text className="text-foreground font-semibold">Verbleibende Zeit: {formatTime(timeLeft)}</Text></View>
          </View>

          <View className="gap-4">
            <Text className="text-foreground font-bold" style={{ fontSize: fontSizes['2xl'], lineHeight: fontSizes['2xl'] * 1.3 }}>{currentQuestion.russian}</Text>
            <Text className="text-muted" style={{ fontSize: fontSizes.base, lineHeight: fontSizes.base * 1.5 }}>{currentQuestion.german}</Text>
          </View>

          {currentQuestion.options && (
            <View className="gap-3">
              {currentQuestion.options.map((option, index) => (
                <Pressable key={index} onPress={() => setSelectedAnswer(option)} accessibilityRole="radio" accessibilityState={{ selected: selectedAnswer === option }} className={`rounded-2xl p-4 border-2 ${selectedAnswer === option ? 'border-primary bg-primary' : 'border-border bg-surface'}`}>
                  <Text className={`font-semibold ${selectedAnswer === option ? 'text-background' : 'text-foreground'}`} style={{ fontSize: fontSizes.lg }}>{option}</Text>
                </Pressable>
              ))}
            </View>
          )}

          <View className="gap-3">
            <Pressable onPress={handleNext} disabled={!selectedAnswer} className={`rounded-2xl py-4 items-center ${selectedAnswer ? 'bg-primary' : 'bg-border'}`}>
              <Text className={`font-bold text-center ${selectedAnswer ? 'text-background' : 'text-muted'}`} style={{ fontSize: fontSizes.lg }}>{isLastQuestion ? 'Prüfung beenden' : 'Nächste Frage'}</Text>
            </Pressable>
            <Pressable onPress={handleFinishExam} className="rounded-2xl py-4 items-center bg-surface border border-border"><Text className="text-foreground font-semibold">Frühzeitig abgeben</Text></Pressable>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
