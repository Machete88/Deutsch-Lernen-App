import { View, Text, ScrollView, Pressable, FlatList } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useExam } from '@/lib/exam-context';
import { useFontSizes } from '@/hooks/use-accessibility';
import { CEFRLevel } from '@/lib/types-extended';

const cefrLevels: Array<{ level: CEFRLevel; name: string; description: string }> = [
  { level: 'A1', name: 'A1 (Anfänger)', description: 'Grundlagen der Sprache' },
  { level: 'A2', name: 'A2 (Elementar)', description: 'Einfache Kommunikation' },
  { level: 'B1', name: 'B1 (Mittelstufe)', description: 'Fließende Konversation' },
  { level: 'B2', name: 'B2 (Oberstufe)', description: 'Fortgeschrittenes Deutsch' },
];

export default function ExamModeScreen() {
  const router = useRouter();
  const { settings } = useSettings();
  const { startExam, getResultsByLevel } = useExam();
  const fontSizes = useFontSizes(settings.fontSizeLevel);

  const handleStartExam = async (level: CEFRLevel) => {
    try {
      await startExam(level);
      router.push('./exam-quiz');
    } catch (error) {
      console.error('Error starting exam:', error);
    }
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 px-6 py-8 gap-8">
          {/* Header */}
          <View className="gap-2">
            <Text
              className="text-foreground font-bold"
              style={{ fontSize: fontSizes['5xl'] }}
              accessibilityRole="header"
            >
              Прüfungsmodus
            </Text>
            
            <Text
              className="text-muted"
              style={{ fontSize: fontSizes.lg, lineHeight: fontSizes.lg * 1.5 }}
            >
              Wähle dein Sprachniveau
            </Text>
          </View>

          {/* CEFR Levels */}
          <View className="gap-4">
            <FlatList
              data={cefrLevels}
              keyExtractor={item => item.level}
              scrollEnabled={false}
              renderItem={({ item }) => {
                const results = getResultsByLevel(item.level);
                const lastResult = results.length > 0 ? results[results.length - 1] : null;

                return (
                  <Pressable
                    onPress={() => handleStartExam(item.level)}
                    accessible={true}
                    accessibilityRole="button"
                    accessibilityLabel={`${item.name}, ${item.description}`}
                    className="bg-surface rounded-2xl p-6 border-2 border-border"
                    style={({ pressed }) => ({
                      opacity: pressed ? 0.8 : 1,
                      transform: [{ scale: pressed ? 0.97 : 1 }],
                    })}
                  >
                    <View className="flex-row justify-between items-start gap-4">
                      <View className="flex-1">
                        <Text
                          className="text-foreground font-bold"
                          style={{ fontSize: fontSizes.xl }}
                        >
                          {item.name}
                        </Text>
                        
                        <Text
                          className="text-muted mt-2"
                          style={{ fontSize: fontSizes.base }}
                        >
                          {item.description}
                        </Text>
                      </View>

                      {lastResult && (
                        <View className="bg-primary rounded-lg px-3 py-2 items-center">
                          <Text
                            className="text-background font-bold"
                            style={{ fontSize: fontSizes.base }}
                          >
                            {lastResult.score}%
                          </Text>
                          <Text
                            className="text-background text-xs"
                            style={{ fontSize: fontSizes.xs }}
                          >
                            {lastResult.passed ? '✓ Bestanden' : '✗ Nicht bestanden'}
                          </Text>
                        </View>
                      )}
                    </View>
                  </Pressable>
                );
              }}
            />
          </View>

          {/* Info */}
          <View className="bg-surface rounded-2xl p-6 border border-border gap-2">
            <Text
              className="text-foreground font-semibold"
              style={{ fontSize: fontSizes.lg }}
            >
              Über die Prüfung
            </Text>
            
            <Text
              className="text-muted"
              style={{ fontSize: fontSizes.base, lineHeight: fontSizes.base * 1.5 }}
            >
              Jede Prüfung besteht aus 10 Fragen. Du brauchst mindestens 70% um zu bestehen und ein Zertifikat zu erhalten.
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
