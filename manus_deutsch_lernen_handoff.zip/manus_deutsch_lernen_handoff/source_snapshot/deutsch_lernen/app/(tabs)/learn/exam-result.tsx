import { View, Text, ScrollView, Pressable } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useFontSizes } from '@/hooks/use-accessibility';

function formatDuration(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const rest = seconds % 60;
  return `${minutes} Min ${rest} Sek`;
}

export default function ExamResultScreen() {
  const router = useRouter();
  const { settings } = useSettings();
  const fontSizes = useFontSizes(settings.fontSizeLevel);
  const params = useLocalSearchParams();

  const score = parseInt(params.score as string, 10) || 0;
  const passed = params.passed === 'true';
  const correctAnswers = parseInt(params.correctAnswers as string, 10) || 0;
  const totalQuestions = parseInt(params.totalQuestions as string, 10) || 0;
  const recommendation = (params.recommendation as string) || '';
  const certificateNumber = (params.certificateNumber as string) || '';
  const durationSeconds = parseInt(params.durationSeconds as string, 10) || 0;

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 px-6 py-8 gap-8 justify-center items-center">
          <View className={`w-24 h-24 rounded-full items-center justify-center ${passed ? 'bg-success' : 'bg-error'}`}><Text className="text-background font-bold" style={{ fontSize: fontSizes['5xl'] }}>{passed ? '✓' : '✗'}</Text></View>
          <Text className={`font-bold text-center ${passed ? 'text-success' : 'text-error'}`} style={{ fontSize: fontSizes['4xl'], lineHeight: fontSizes['4xl'] * 1.2 }}>{passed ? 'Bestanden!' : 'Nicht bestanden'}</Text>

          <View className="gap-2 items-center">
            <Text className="text-foreground font-bold" style={{ fontSize: fontSizes['5xl'] }}>{score}%</Text>
            <Text className="text-muted" style={{ fontSize: fontSizes.lg }}>{correctAnswers} von {totalQuestions} richtig</Text>
            <Text className="text-muted" style={{ fontSize: fontSizes.base }}>Bearbeitungszeit: {formatDuration(durationSeconds)}</Text>
          </View>

          <View className="bg-surface rounded-2xl p-6 w-full gap-3 border border-border">
            <Text className="text-foreground font-bold" style={{ fontSize: fontSizes.lg }}>Empfehlung</Text>
            <Text className="text-muted" style={{ fontSize: fontSizes.base, lineHeight: fontSizes.base * 1.5 }}>{recommendation || 'Wiederhole die Fehlerfragen und übe danach die passende Kategorie.'}</Text>
          </View>

          {passed ? (
            <View className="bg-primary rounded-2xl p-6 w-full gap-3 items-center">
              <Text className="text-background font-bold" style={{ fontSize: fontSizes.lg }}>🎓 Zertifikat erhalten</Text>
              <Text className="text-background text-center" style={{ fontSize: fontSizes.base, lineHeight: fontSizes.base * 1.5 }}>Du hast die Prüfung bestanden. Zertifikatsnummer: {certificateNumber || 'wird erstellt'}.</Text>
              <Pressable onPress={() => router.push('./certificates')} className="bg-background rounded-lg px-6 py-2 mt-2"><Text className="text-primary font-semibold text-center" style={{ fontSize: fontSizes.base }}>Zertifikat anzeigen</Text></Pressable>
            </View>
          ) : (
            <View className="bg-warning rounded-2xl p-6 w-full gap-2 items-center"><Text className="text-background font-semibold" style={{ fontSize: fontSizes.base }}>Du brauchst mindestens 70% zum Bestehen.</Text><Text className="text-background text-center" style={{ fontSize: fontSizes.sm }}>Konzentriere dich beim nächsten Versuch zuerst auf Wiederholung und schwache Themen.</Text></View>
          )}

          <Pressable onPress={() => router.push('./index')} className="w-full bg-surface rounded-2xl py-4 border-2 border-border items-center mt-4"><Text className="text-foreground font-bold text-center" style={{ fontSize: fontSizes.lg }}>Zurück zum Lernen</Text></Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
