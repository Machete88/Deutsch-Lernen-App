import { View, Text, ScrollView, Pressable, TextInput } from 'react-native';
import { useMemo, useState } from 'react';
import { ScreenContainer } from '@/components/screen-container';
import { conversationScenarios, createConversationReply } from '@/lib/conversation-coach';

type ChatMessage = { id: string; role: 'assistant' | 'user'; text: string };

export default function AIConversationScreen() {
  const [scenarioId, setScenarioId] = useState(conversationScenarios[0].id);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { id: 'welcome', role: 'assistant', text: conversationScenarios[0].openingLine },
  ]);
  const [input, setInput] = useState('');
  const scenario = useMemo(
    () => conversationScenarios.find(item => item.id === scenarioId) || conversationScenarios[0],
    [scenarioId]
  );

  const switchScenario = (id: string) => {
    const selected = conversationScenarios.find(item => item.id === id) || conversationScenarios[0];
    setScenarioId(id);
    setMessages([{ id: `opening-${id}`, role: 'assistant', text: selected.openingLine }]);
    setInput('');
  };

  const send = () => {
    if (!input.trim()) return;
    const userText = input.trim();
    const reply = createConversationReply(userText, scenario.id);
    setMessages((prev) => [
      ...prev,
      { id: `u-${Date.now()}`, role: 'user', text: userText },
      { id: `a-${Date.now() + 1}`, role: 'assistant', text: reply.answer },
      { id: `c-${Date.now() + 2}`, role: 'assistant', text: `Korrektur: ${reply.correction}` },
      { id: `b-${Date.now() + 3}`, role: 'assistant', text: `Besser so: ${reply.betterOption}` },
      { id: `e-${Date.now() + 4}`, role: 'assistant', text: reply.encouragement },
    ]);
    setInput('');
  };

  return (
    <ScreenContainer className="bg-background">
      <View className="flex-1 px-6 py-6 gap-4">
        <View className="gap-2">
          <Text className="text-foreground text-3xl font-bold">KI-Unterhaltung</Text>
          <Text className="text-muted">Trainiere echte Situationen mit sofortigem Sprachfeedback in Textform.</Text>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View className="flex-row gap-3">
            {conversationScenarios.map((item) => (
              <Pressable
                key={item.id}
                onPress={() => switchScenario(item.id)}
                className={`rounded-2xl px-4 py-3 ${item.id === scenario.id ? 'bg-primary' : 'bg-card border border-border'}`}
              >
                <Text className={`${item.id === scenario.id ? 'text-background' : 'text-foreground'} font-semibold`}>
                  {item.title}
                </Text>
                <Text className={`${item.id === scenario.id ? 'text-background' : 'text-muted'} text-xs mt-1`}>
                  {item.level}
                </Text>
              </Pressable>
            ))}
          </View>
        </ScrollView>

        <View className="bg-card rounded-2xl p-4 gap-2 border border-border">
          <Text className="text-foreground font-semibold">{scenario.setting}</Text>
          <Text className="text-muted">Ziel: {scenario.goal}</Text>
          {scenario.hints.map((hint) => (
            <Text key={hint} className="text-muted">• {hint}</Text>
          ))}
        </View>

        <ScrollView className="flex-1 bg-surface rounded-2xl p-4 border border-border">
          <View className="gap-3">
            {messages.map((message) => (
              <View
                key={message.id}
                className={`${message.role === 'user' ? 'self-end bg-primary' : 'self-start bg-card'} rounded-2xl px-4 py-3 max-w-[90%]`}
              >
                <Text className={message.role === 'user' ? 'text-background' : 'text-foreground'}>
                  {message.text}
                </Text>
              </View>
            ))}
          </View>
        </ScrollView>

        <View className="gap-3">
          <TextInput
            value={input}
            onChangeText={setInput}
            placeholder="Schreibe deine Antwort auf Deutsch ..."
            placeholderTextColor="#888"
            multiline
            className="bg-card border border-border rounded-2xl px-4 py-4 text-foreground min-h-[96px]"
          />
          <Pressable onPress={send} className="bg-primary rounded-2xl py-4 items-center">
            <Text className="text-background font-bold">Antwort senden</Text>
          </Pressable>
        </View>
      </View>
    </ScreenContainer>
  );
}
