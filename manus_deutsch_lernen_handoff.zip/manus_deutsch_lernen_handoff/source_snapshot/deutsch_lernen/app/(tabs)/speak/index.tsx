import { View, Text, ScrollView, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useVocabulary } from '@/lib/vocabulary-context';
import { useSpeechRecognition } from '@/lib/speech-recognition-context';
import { useFontSizes } from '@/hooks/use-accessibility';
import { t } from '@/lib/i18n';

export default function SpeakScreen() {
  const router = useRouter();
  const { settings } = useSettings();
  const { learningSets } = useVocabulary();
  const { isLoading } = useSpeechRecognition();
  const fontSizes = useFontSizes(settings.fontSizeLevel);

  const handleStartPractice = async (setName: string) => {
    router.push({
      pathname: './speak-practice',
      params: { setName },
    });
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 px-6 py-8 gap-8">
          <View className="gap-2">
            <Text
              className="text-foreground font-bold"
              style={{ fontSize: fontSizes['5xl'] }}
              accessibilityRole="header"
            >
              {t('speak')}
            </Text>

            <Text
              className="text-muted"
              style={{ fontSize: fontSizes.lg, lineHeight: fontSizes.lg * 1.5 }}
            >
              Aussprache trainieren und echte Dialoge üben
            </Text>
          </View>

          <View className="bg-primary rounded-2xl p-6 gap-2">
            <Text className="text-background font-bold" style={{ fontSize: fontSizes.lg }}>
              Aussprache-Coach
            </Text>

            <Text
              className="text-background"
              style={{ fontSize: fontSizes.base, lineHeight: fontSizes.base * 1.5 }}
            >
              Höre Wörter an, nimm dich auf und erhalte direktes Feedback mit Fokuslauten,
              Rhythmus-Tipps und Shadowing-Übungen.
            </Text>
          </View>

          <Pressable
            onPress={() => router.push('./ai-conversation')}
            className="w-full bg-card rounded-2xl p-5 border border-border"
          >
            <Text className="text-foreground font-bold" style={{ fontSize: fontSizes.xl }}>
              KI-Unterhaltung
            </Text>
            <Text className="text-muted mt-1" style={{ fontSize: fontSizes.base }}>
              Übe Alltagssituationen wie Café, Arzt oder Vorstellungsrunde mit Korrektur und besseren Antwortideen.
            </Text>
          </Pressable>

          {learningSets.length > 0 ? (
            <View className="gap-4">
              <Text className="text-foreground font-semibold" style={{ fontSize: fontSizes.lg }}>
                Kategorie für Aussprache wählen
              </Text>

              <View className="gap-3">
                {learningSets.map((item) => (
                  <Pressable
                    key={item.id}
                    onPress={() => handleStartPractice(item.category)}
                    disabled={isLoading}
                    className="bg-card border border-border rounded-2xl p-5"
                  >
                    <Text className="text-foreground font-bold" style={{ fontSize: fontSizes.lg }}>
                      {item.name}
                    </Text>
                    <Text className="text-muted mt-1">
                      {item.wordCount} Wörter · Aussprache und Nachsprechen
                    </Text>
                  </Pressable>
                ))}
              </View>
            </View>
          ) : (
            <Text className="text-muted">Noch keine Lernkategorien verfügbar.</Text>
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
