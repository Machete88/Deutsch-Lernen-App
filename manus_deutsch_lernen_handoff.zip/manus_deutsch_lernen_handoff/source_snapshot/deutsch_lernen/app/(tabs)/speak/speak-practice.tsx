import { View, Text, ScrollView, Pressable } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useVocabulary } from '@/lib/vocabulary-context';
import { useSpeechRecognition } from '@/lib/speech-recognition-context';
import { useTTS } from '@/lib/tts-context';
import { useFontSizes } from '@/hooks/use-accessibility';
import { useState, useEffect } from 'react';
import { buildPronunciationCoach, PronunciationCoachResult } from '@/lib/pronunciation';

export default function SpeakPracticeScreen() {
  const router = useRouter();
  const { settings } = useSettings();
  const { words } = useVocabulary();
  const { isRecording, startRecording, stopRecording, isLoading, playAudio } = useSpeechRecognition();
  const { speakWord } = useTTS();
  const fontSizes = useFontSizes(settings.fontSizeLevel);
  const params = useLocalSearchParams();
  const setName = params.setName as string;

  const [currentWordIndex, setCurrentWordIndex] = useState(0);
  const [practiceWords, setPracticeWords] = useState<any[]>([]);
  const [recordedUri, setRecordedUri] = useState<string | null>(null);
  const [coachResult, setCoachResult] = useState<PronunciationCoachResult | null>(null);

  useEffect(() => {
    const setWords = words.filter(w => w.category === setName);
    setPracticeWords(setWords);
  }, [setName, words]);

  if (practiceWords.length === 0) {
    return (
      <ScreenContainer className="bg-background">
        <View className="flex-1 justify-center items-center">
          <Text className="text-foreground" style={{ fontSize: fontSizes.lg }}>
            Keine Wörter zum Üben
          </Text>
        </View>
      </ScreenContainer>
    );
  }

  const currentWord = practiceWords[currentWordIndex];
  const progress = Math.round(((currentWordIndex + 1) / practiceWords.length) * 100);
  const isLastWord = currentWordIndex === practiceWords.length - 1;

  const handleStartRecording = async () => {
    setCoachResult(null);
    setRecordedUri(null);
    await startRecording();
  };

  const handleStopRecording = async () => {
    const uri = await stopRecording();
    if (uri) {
      setRecordedUri(uri);
      const analysis = buildPronunciationCoach(currentWord.german, '');
      setCoachResult(analysis);
    }
  };

  const handleNext = () => {
    if (isLastWord) router.back();
    else {
      setCurrentWordIndex(currentWordIndex + 1);
      setRecordedUri(null);
      setCoachResult(null);
    }
  };

  const handlePlayAudio = async () => {
    if (currentWord.audioWordUrl) await playAudio(currentWord.audioWordUrl);
    else await speakWord(currentWord.russian, currentWord.german);
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 px-6 py-8 gap-8 justify-between">
          <View className="gap-2">
            <View className="flex-row justify-between items-center">
              <Text className="text-foreground font-semibold" style={{ fontSize: fontSizes.base }}>
                {setName}
              </Text>
              <Text className="text-primary font-bold" style={{ fontSize: fontSizes.base }}>
                {progress}%
              </Text>
            </View>
            <View className="h-2 bg-border rounded-full overflow-hidden">
              <View className="h-full bg-primary" style={{ width: `${progress}%` }} />
            </View>
            <Text className="text-muted" style={{ fontSize: fontSizes.sm }}>
              Wort {currentWordIndex + 1} von {practiceWords.length}
            </Text>
          </View>

          <View className="gap-6 items-center">
            <Text className="text-foreground font-bold text-center" style={{ fontSize: fontSizes['4xl'] }}>
              {currentWord.german}
            </Text>
            <Text className="text-muted text-center" style={{ fontSize: fontSizes.xl }}>
              {currentWord.russian}
            </Text>
            {currentWord.ipa ? (
              <Text className="text-primary" style={{ fontSize: fontSizes.base }}>
                {currentWord.ipa}
              </Text>
            ) : null}

            <View className="w-full bg-card rounded-2xl p-4 gap-2 border border-border">
              <Text className="text-foreground font-semibold">So übst du richtig</Text>
              <Text className="text-muted">1. Wort anhören</Text>
              <Text className="text-muted">2. In Silben nachsprechen</Text>
              <Text className="text-muted">3. Einmal flüssig sprechen</Text>
              <Text className="text-muted">4. Eigene Aufnahme mit dem Modell vergleichen</Text>
            </View>

            <View className="flex-row gap-3 w-full">
              <Pressable
                onPress={handlePlayAudio}
                className="flex-1 bg-surface rounded-2xl p-4 items-center border border-border"
              >
                <Text className="text-foreground font-semibold">Anhören</Text>
              </Pressable>
              <Pressable
                onPress={isRecording ? handleStopRecording : handleStartRecording}
                className={`flex-1 rounded-2xl p-4 items-center ${isRecording ? 'bg-error' : 'bg-primary'}`}
              >
                <Text className="text-background font-semibold">
                  {isRecording ? 'Aufnahme stoppen' : 'Nachsprechen'}
                </Text>
              </Pressable>
            </View>

            {recordedUri ? (
              <Pressable
                onPress={() => playAudio(recordedUri)}
                className="w-full bg-surface rounded-2xl p-4 items-center border border-border"
              >
                <Text className="text-foreground font-semibold">Eigene Aufnahme anhören</Text>
              </Pressable>
            ) : null}

            {coachResult ? (
              <View className="w-full bg-surface rounded-2xl p-5 border border-border gap-3">
                <Text className="text-foreground font-semibold" style={{ fontSize: fontSizes.lg }}>
                  Aussprache-Coach
                </Text>
                <Text className="text-primary font-bold" style={{ fontSize: fontSizes.xl }}>
                  {coachResult.similarity}% Trainingswert
                </Text>
                <Text className="text-muted" style={{ fontSize: fontSizes.base, lineHeight: fontSizes.base * 1.5 }}>
                  {coachResult.feedback}
                </Text>

                <View className="gap-1">
                  <Text className="text-foreground font-semibold">Achte heute besonders auf:</Text>
                  <Text className="text-muted">{coachResult.focusSounds.join(' · ')}</Text>
                </View>

                <View className="gap-1">
                  <Text className="text-foreground font-semibold">Rhythmus-Tipp</Text>
                  <Text className="text-muted">{coachResult.rhythmTip}</Text>
                </View>

                <View className="gap-1">
                  <Text className="text-foreground font-semibold">Übung</Text>
                  <Text className="text-muted">{coachResult.exercise}</Text>
                </View>

                <View className="gap-1">
                  <Text className="text-foreground font-semibold">Shadowing</Text>
                  {coachResult.shadowingSteps.map((step) => (
                    <Text key={step} className="text-muted">{step}</Text>
                  ))}
                </View>

                <Text className="text-muted text-xs">
                  Hinweis: Das Feedback ist aktuell ein Trainings-Coach auf Basis des Zielworts und ersetzt noch keine echte Spracherkennung.
                </Text>
              </View>
            ) : null}
          </View>

          <Pressable
            onPress={handleNext}
            disabled={isLoading || isRecording}
            className="w-full bg-primary rounded-2xl py-4 items-center"
          >
            <Text className="text-background font-bold" style={{ fontSize: fontSizes.lg }}>
              {isLastWord ? 'Training beenden' : 'Nächstes Wort'}
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
