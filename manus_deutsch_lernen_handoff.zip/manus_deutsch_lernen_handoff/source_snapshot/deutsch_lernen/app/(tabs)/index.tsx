import { ScrollView, Text, View, Pressable } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useSettings } from "@/lib/settings-context";
import { useFontSizes } from "@/hooks/use-accessibility";
import { t } from "@/lib/i18n";

export default function HomeScreen() {
  const router = useRouter();
  const { settings } = useSettings();
  const fontSizes = useFontSizes(settings.fontSizeLevel);

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 px-6 py-8 gap-8 justify-center items-center">
          {/* Hero Section */}
          <View className="items-center gap-4">
            <Text
              className="text-foreground font-bold text-center"
              style={{ fontSize: fontSizes["5xl"] }}
              accessibilityRole="header"
            >
              DEUTSCH LERNEN
            </Text>
            <Text
              className="text-muted text-center"
              style={{ fontSize: fontSizes.lg, lineHeight: fontSizes.lg * 1.5 }}
            >
              {t('welcomeSubtitle')}
            </Text>
          </View>

          {/* Start Button */}
          <Pressable
            onPress={() => router.push('/onboarding/welcome')}
            className="w-full bg-primary rounded-2xl py-4 px-6 items-center"
            style={({ pressed }) => ({
              opacity: pressed ? 0.8 : 1,
            })}
          >
            <Text
              className="text-background font-bold text-center"
              style={{ fontSize: fontSizes.xl }}
            >
              {t('start')}
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
