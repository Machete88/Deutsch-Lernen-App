import { View, Text, ScrollView, Pressable, FlatList } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useVocabulary } from '@/lib/vocabulary-context';
import { useSpacedRepetition } from '@/lib/spaced-repetition-context';
import { useFontSizes } from '@/hooks/use-accessibility';
import { useState, useEffect } from 'react';
import { t } from '@/lib/i18n';

export default function ReviewScreen() {
  const router = useRouter();
  const { settings } = useSettings();
  const { learningSets, words } = useVocabulary();
  const { getDueWords, startReviewSession } = useSpacedRepetition();
  const fontSizes = useFontSizes(settings.fontSizeLevel);
  const [dueStats, setDueStats] = useState<Array<{ setName: string; dueCount: number }>>([]);

  useEffect(() => {
    const stats = learningSets.map(set => {
      const setWords = words.filter(w => w.category === set.category);
      const dueWords = getDueWords(setWords);
      return {
        setName: set.name,
        dueCount: dueWords.length,
      };
    });
    setDueStats(stats);
  }, [learningSets, words]);

  const handleStartReview = async (setName: string) => {
    const set = learningSets.find(s => s.name === setName);
    if (!set) return;

    const setWords = words.filter(w => w.category === set.category);
    await startReviewSession(setWords);
    router.push('./review-quiz');
  };

  const totalDue = dueStats.reduce((sum, stat) => sum + stat.dueCount, 0);

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 px-6 py-8 gap-8">
          {/* Header */}
          <View className="gap-2">
            <Text
              className="text-foreground font-bold"
              style={{ fontSize: fontSizes['5xl'] }}
              accessibilityRole="header"
            >
              {t('review')}
            </Text>
            
            <Text
              className="text-muted"
              style={{ fontSize: fontSizes.lg, lineHeight: fontSizes.lg * 1.5 }}
            >
              {t('reviewCards')} ({totalDue} {totalDue === 1 ? 'слово' : 'слов'})
            </Text>
          </View>

          {/* Stats */}
          {totalDue > 0 && (
            <View className="bg-primary rounded-2xl p-6 gap-2">
              <Text
                className="text-background font-bold"
                style={{ fontSize: fontSizes.xl }}
              >
                {totalDue} {totalDue === 1 ? 'слово' : 'слов'} к повторению
              </Text>
              
              <Text
                className="text-background"
                style={{ fontSize: fontSizes.base }}
              >
                Повторяйте каждый день
              </Text>
            </View>
          )}

          {/* Sets List */}
          {dueStats.length > 0 ? (
            <View className="gap-4">
              <FlatList
                data={dueStats}
                keyExtractor={item => item.setName}
                scrollEnabled={false}
                renderItem={({ item }) => (
                  <Pressable
                    onPress={() => handleStartReview(item.setName)}
                    disabled={item.dueCount === 0}
                    accessible={true}
                    accessibilityRole="button"
                    accessibilityLabel={`${item.setName}, ${item.dueCount} слов`}
                    className={`rounded-2xl p-6 border-2 ${
                      item.dueCount > 0
                        ? 'border-primary bg-surface'
                        : 'border-border bg-surface opacity-50'
                    }`}
                    style={({ pressed }) => ({
                      opacity: pressed && item.dueCount > 0 ? 0.8 : 1,
                      transform: [{ scale: pressed && item.dueCount > 0 ? 0.97 : 1 }],
                    })}
                  >
                    <View className="flex-row justify-between items-center">
                      <Text
                        className="text-foreground font-semibold flex-1"
                        style={{ fontSize: fontSizes.lg }}
                      >
                        {item.setName}
                      </Text>

                      <View
                        className={`rounded-lg px-4 py-2 items-center ${
                          item.dueCount > 0 ? 'bg-primary' : 'bg-border'
                        }`}
                      >
                        <Text
                          className={`font-bold ${
                            item.dueCount > 0 ? 'text-background' : 'text-muted'
                          }`}
                          style={{ fontSize: fontSizes.lg }}
                        >
                          {item.dueCount}
                        </Text>
                      </View>
                    </View>
                  </Pressable>
                )}
              />
            </View>
          ) : (
            <View className="flex-1 justify-center items-center gap-4">
              <Text
                className="text-muted text-center"
                style={{ fontSize: fontSizes.lg, lineHeight: fontSizes.lg * 1.5 }}
              >
                Нет слов для повторения.
              </Text>

              <Text
                className="text-muted text-center"
                style={{ fontSize: fontSizes.base, lineHeight: fontSizes.base * 1.5 }}
              >
                Учите новые слова в разделе «Учить», чтобы повторять их позже.
              </Text>
            </View>
          )}

          {/* Info */}
          <View className="bg-surface rounded-2xl p-6 border border-border gap-2">
            <Text
              className="text-foreground font-semibold"
              style={{ fontSize: fontSizes.lg }}
            >
              Интервальное повторение
            </Text>
            
            <Text
              className="text-muted"
              style={{ fontSize: fontSizes.base, lineHeight: fontSizes.base * 1.5 }}
            >
              Слова автоматически планируются по алгоритму SM-2. Чем лучше вы знаете слово, тем дольше интервал повторения.
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
