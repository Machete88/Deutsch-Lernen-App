import { View, Text, ScrollView, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useSpacedRepetition } from '@/lib/spaced-repetition-context';
import { useFontSizes } from '@/hooks/use-accessibility';
import { useState } from 'react';

export default function ReviewQuizScreen() {
  const router = useRouter();
  const { settings } = useSettings();
  const { currentSession, recordReview, completeSession } = useSpacedRepetition();
  const fontSizes = useFontSizes(settings.fontSizeLevel);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);

  if (!currentSession || currentSession.words.length === 0) {
    return (
      <ScreenContainer className="bg-background">
        <View className="flex-1 justify-center items-center">
          <Text className="text-foreground" style={{ fontSize: fontSizes.lg }}>
            Keine Wörter zum Wiederholen
          </Text>
        </View>
      </ScreenContainer>
    );
  }

  const currentWord = currentSession.words[currentSession.currentIndex];
  const isLastQuestion = currentSession.currentIndex === currentSession.words.length - 1;
  const progress = Math.round(
    ((currentSession.currentIndex + 1) / currentSession.words.length) * 100
  );

  // Generiere Multiple-Choice-Optionen
  const options = [
    currentWord.german,
    ...currentSession.words
      .slice(0, 3)
      .filter(w => w.id !== currentWord.id)
      .map(w => w.german),
  ].sort(() => Math.random() - 0.5);

  const handleSelectAnswer = (answer: string) => {
    setSelectedAnswer(answer);
  };

  const handleNext = async () => {
    if (!selectedAnswer) return;

    const correct = selectedAnswer === currentWord.german;
    await recordReview(currentWord.id, correct);

    if (isLastQuestion) {
      const result = await completeSession();
      router.push({
        pathname: './review-result',
        params: {
          correct: result.correct.toString(),
          total: result.total.toString(),
        },
      });
    } else {
      // Nächste Frage
      setSelectedAnswer(null);
    }
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 px-6 py-8 gap-8">
          {/* Progress */}
          <View className="gap-2">
            <View className="flex-row justify-between items-center">
              <Text
                className="text-foreground font-semibold"
                style={{ fontSize: fontSizes.base }}
              >
                Frage {currentSession.currentIndex + 1} von {currentSession.words.length}
              </Text>
              <Text
                className="text-primary font-bold"
                style={{ fontSize: fontSizes.base }}
              >
                {progress}%
              </Text>
            </View>

            {/* Progress Bar */}
            <View className="h-2 bg-border rounded-full overflow-hidden">
              <View
                className="h-full bg-primary"
                style={{ width: `${progress}%` }}
              />
            </View>
          </View>

          {/* Question */}
          <View className="gap-4">
            <Text
              className="text-foreground font-bold text-center"
              style={{ fontSize: fontSizes['3xl'], lineHeight: fontSizes['3xl'] * 1.3 }}
            >
              Wie heißt das auf Deutsch?
            </Text>

            <View className="bg-primary rounded-2xl p-6 items-center">
              <Text
                className="text-background font-bold text-center"
                style={{ fontSize: fontSizes['4xl'], lineHeight: fontSizes['4xl'] * 1.2 }}
              >
                {currentWord.russian}
              </Text>
            </View>
          </View>

          {/* Answers */}
          <View className="gap-3">
            {options.map((option, index) => (
              <Pressable
                key={index}
                onPress={() => handleSelectAnswer(option)}
                accessible={true}
                accessibilityRole="radio"
                accessibilityState={{ selected: selectedAnswer === option }}
                className={`rounded-2xl p-4 border-2 ${
                  selectedAnswer === option
                    ? 'border-primary bg-primary'
                    : 'border-border bg-surface'
                }`}
                style={({ pressed }) => ({
                  opacity: pressed ? 0.8 : 1,
                  transform: [{ scale: pressed ? 0.97 : 1 }],
                })}
              >
                <Text
                  className={`font-semibold ${
                    selectedAnswer === option ? 'text-background' : 'text-foreground'
                  }`}
                  style={{ fontSize: fontSizes.lg }}
                >
                  {option}
                </Text>
              </Pressable>
            ))}
          </View>

          {/* Next Button */}
          <Pressable
            onPress={handleNext}
            disabled={!selectedAnswer}
            accessible={true}
            accessibilityRole="button"
            accessibilityLabel={isLastQuestion ? 'Quiz beenden' : 'Nächste Frage'}
            className={`rounded-2xl py-4 items-center ${
              selectedAnswer ? 'bg-primary' : 'bg-border'
            }`}
            style={({ pressed }) => ({
              opacity: pressed && selectedAnswer ? 0.8 : 1,
              transform: [{ scale: pressed && selectedAnswer ? 0.97 : 1 }],
            })}
          >
            <Text
              className={`font-bold text-center ${
                selectedAnswer ? 'text-background' : 'text-muted'
              }`}
              style={{ fontSize: fontSizes.lg }}
            >
              {isLastQuestion ? 'Quiz beenden' : 'Nächste Frage'}
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
