import { View, Text, ScrollView, Pressable } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useSettings } from '@/lib/settings-context';
import { useFontSizes } from '@/hooks/use-accessibility';

export default function ReviewResultScreen() {
  const router = useRouter();
  const { settings } = useSettings();
  const fontSizes = useFontSizes(settings.fontSizeLevel);
  const params = useLocalSearchParams();

  const correct = parseInt(params.correct as string, 10) || 0;
  const total = parseInt(params.total as string, 10) || 0;
  const percentage = total > 0 ? Math.round((correct / total) * 100) : 0;

  const handleBackToReview = () => {
    router.push('./index');
  };

  return (
    <ScreenContainer className="bg-background">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} className="flex-1">
        <View className="flex-1 px-6 py-8 gap-8 justify-center items-center">
          {/* Result Icon */}
          <View
            className={`w-24 h-24 rounded-full items-center justify-center ${
              percentage >= 70 ? 'bg-success' : 'bg-warning'
            }`}
          >
            <Text
              className="text-background font-bold"
              style={{ fontSize: fontSizes['5xl'] }}
            >
              {percentage >= 70 ? '✓' : '!'}
            </Text>
          </View>

          {/* Result Title */}
          <Text
            className={`font-bold text-center ${
              percentage >= 70 ? 'text-success' : 'text-warning'
            }`}
            style={{ fontSize: fontSizes['4xl'], lineHeight: fontSizes['4xl'] * 1.2 }}
          >
            {percentage >= 70 ? 'Gut gemacht!' : 'Weiter üben'}
          </Text>

          {/* Score */}
          <View className="gap-2 items-center">
            <Text
              className="text-foreground font-bold"
              style={{ fontSize: fontSizes['5xl'] }}
            >
              {percentage}%
            </Text>

            <Text
              className="text-muted"
              style={{ fontSize: fontSizes.lg }}
            >
              {correct} von {total} richtig
            </Text>
          </View>

          {/* Feedback */}
          <View className="bg-surface rounded-2xl p-6 w-full gap-2 items-center border border-border">
            <Text
              className="text-foreground font-semibold"
              style={{ fontSize: fontSizes.base }}
            >
              Spaced Repetition aktualisiert
            </Text>

            <Text
              className="text-muted text-center"
              style={{ fontSize: fontSizes.sm, lineHeight: fontSizes.sm * 1.5 }}
            >
              Deine Wiederholungsintervalle wurden basierend auf deinen Antworten angepasst.
            </Text>
          </View>

          {/* Back Button */}
          <Pressable
            onPress={handleBackToReview}
            accessible={true}
            accessibilityRole="button"
            className="w-full bg-surface rounded-2xl py-4 border-2 border-border items-center mt-4"
            style={({ pressed }) => ({
              opacity: pressed ? 0.8 : 1,
              transform: [{ scale: pressed ? 0.97 : 1 }],
            })}
          >
            <Text
              className="text-foreground font-bold text-center"
              style={{ fontSize: fontSizes.lg }}
            >
              Zurück zum Wiederholen
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
