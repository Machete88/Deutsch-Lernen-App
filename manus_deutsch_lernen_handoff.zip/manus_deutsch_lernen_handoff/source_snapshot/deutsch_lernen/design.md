# DEUTSCH LERNEN – Design-Dokumentation

## Zielgruppe & Anforderungen

**Zielgruppe:** Russischsprachige Nutzer mit Sehschwäche oder erhöhtem Bedarf an Barrierefreiheit

**Kernprinzipien:**
- Barrierearm und motivierend
- Sehr hohe Lesbarkeit (WCAG AA/AAA)
- Große Typografie (bis 48pt für zentrale Inhalte)
- Hohe Kontraste
- Minimale visuelle Ablenkung
- Einfache Navigation mit großen Touch-Flächen
- Ruhiges, freundliches Design
- Dezentes Glassmorphism (nicht verspielt)

---

## Farbpalette (WCAG AA/AAA konform)

| Token | Light Mode | Dark Mode | Kontrast | Verwendung |
|-------|-----------|-----------|----------|-----------|
| `background` | #FFFFFF | #0F0F0F | 21:1 | Hintergrund, Screens |
| `foreground` | #1A1A1A | #F5F5F5 | 20:1 | Primärer Text |
| `muted` | #5A5A5A | #A0A0A0 | 7:1 | Sekundärer Text |
| `primary` | #0066CC | #4D94FF | 8.5:1 | Buttons, Hervorhebung |
| `surface` | #F8F8F8 | #1A1A1A | 18:1 | Karten, Container |
| `border` | #D0D0D0 | #333333 | 5:1 | Trennlinien |
| `success` | #00AA00 | #00DD00 | 8:1 | Erfolg, Bestätigung |
| `warning` | #FF8800 | #FFAA44 | 7:1 | Warnung |
| `error` | #CC0000 | #FF4444 | 8:1 | Fehler, Ablehnung |

---

## Typografie

| Element | Größe | Gewicht | Zeilenhöhe | Verwendung |
|---------|-------|---------|-----------|-----------|
| **Heading 1** | 48pt | Bold (700) | 1.2 | Screen-Titel |
| **Heading 2** | 36pt | Bold (700) | 1.2 | Abschnitte |
| **Body Large** | 24pt | Regular (400) | 1.5 | Vokabelkarten (Deutsch) |
| **Body Medium** | 20pt | Regular (400) | 1.5 | Vokabelkarten (Russisch) |
| **Body Small** | 18pt | Regular (400) | 1.5 | Beschreibungen |
| **Label** | 16pt | Medium (600) | 1.4 | Button-Text, Labels |
| **Caption** | 14pt | Regular (400) | 1.4 | Hinweise, Metadaten |

**Font-Familie:** System Font Stack (SF Pro Display auf iOS, Roboto auf Android)

---

## Spacing & Layout

| Element | Größe | Verwendung |
|---------|-------|-----------|
| **Padding** | 24pt | Screen-Innenabstand |
| **Gap** | 20pt | Abstand zwischen Elementen |
| **Card Padding** | 20pt | Innenabstand in Karten |
| **Button Height** | 56pt | Mindesthöhe für Touch-Flächen |
| **Radius** | 12pt | Eckenradius für Karten/Buttons |

---

## Screen-Struktur

### 1. **Tab: „Учить" (Lernen)**

**Ziel:** Neue Wörter lernen durch Vokabelkarten

**Komponenten:**
- **Header:** Großer Titel „Учить" (36pt)
- **Vokabelkarte (zentral):**
  - Russisches Wort: 24pt, Bold, oben
  - Deutscher Übersetzung: 28pt, Bold, Mitte
  - Audio-Button: 56pt Durchmesser, große Touch-Fläche
- **Navigation:**
  - Großer „Weiter"-Button (56pt Höhe)
  - Großer „Zurück"-Button (56pt Höhe)
- **Fortschritts-Anzeige:** Einfache Nummer (z.B. „3/50")

**Interaktionen:**
- Wischen nach links/rechts für nächste/vorherige Karte
- Tap auf Audio-Button zum Abspielen der Aussprache
- Tap auf Buttons zum Navigieren

---

### 2. **Tab: „Вспоминать" (Erinnern)**

**Ziel:** Gelernte Wörter wiederholen durch einfache Quiz

**Komponenten:**
- **Header:** Großer Titel „Вспоминать" (36pt)
- **Quiz-Frage:**
  - Russisches Wort: 28pt, Bold, oben
  - 4 Antwort-Buttons (56pt Höhe, großer Abstand)
- **Feedback:**
  - Grün für korrekt, Rot für falsch
  - Große Symbole (✓ / ✗)
- **Fortschritt:** Zähler (z.B. „3/10 richtig")

**Interaktionen:**
- Tap auf Antwort-Button
- Automatischer Übergang zur nächsten Frage nach Feedback

---

### 3. **Tab: „Говорить" (Sprechen)**

**Ziel:** Aussprache üben durch Spracherkennung

**Komponenten:**
- **Header:** Großer Titel „Говорить" (36pt)
- **Wort zum Sprechen:** 28pt, Bold, zentral
- **Großer Mikrofon-Button:** 80pt Durchmesser, deutliche Farbe
- **Status-Text:** „Bereit zum Sprechen", „Höre zu...", „Verarbeite..."
- **Feedback:** Grün für korrekt, Rot für falsch
- **Fortschritt:** Zähler

**Interaktionen:**
- Tap auf Mikrofon-Button zum Starten/Stoppen
- Automatische Verarbeitung der Sprache
- Visuelles Feedback während der Aufnahme

---

## Komponenten

### Button (Groß)
- **Größe:** 56pt Höhe, volle Breite minus Padding
- **Padding:** 16pt horizontal
- **Radius:** 12pt
- **Text:** 18pt, Bold
- **States:** Normal, Pressed (Scale 0.97), Disabled (Opacity 0.5)

### Vokabelkarte
- **Größe:** Volle Breite, min. 280pt Höhe
- **Padding:** 20pt
- **Radius:** 12pt
- **Hintergrund:** Surface-Farbe mit dezenter Glassmorphism
- **Text:** Große Schrift, hoher Kontrast

### Audio-Button
- **Größe:** 56pt Durchmesser
- **Icon:** Großes Lautsprecher-Symbol
- **States:** Normal (Blau), Pressed (Dunkelblau), Playing (Grün)

### Mikrofon-Button
- **Größe:** 80pt Durchmesser
- **Icon:** Großes Mikrofon-Symbol
- **States:** Normal (Blau), Recording (Rot), Processing (Orange)

---

## Barrierefreiheit

### Implementierung
- **Screenreader-Labels:** Alle interaktiven Elemente haben aussagekräftige Labels
- **Fokus-Management:** Klare Fokus-Indikatoren (Outline, 2pt, Primärfarbe)
- **Tastatur-Navigation:** Alle Funktionen über Tastatur erreichbar
- **Reduktion von Animationen:** Respekt für `prefers-reduced-motion`
- **Kontrast:** Alle Texte erfüllen WCAG AAA (7:1 oder besser)

### Testing
- VoiceOver (iOS) und TalkBack (Android) testen
- Tastatur-Navigation durchgehen
- Kontrast mit Tools wie WebAIM überprüfen

---

## Navigationsmuster

**Tab-Bar (unten):**
- 3 Tabs: Учить | Вспоминать | Говорить
- Große Icons (28pt)
- Aktiver Tab: Primärfarbe, Inaktiv: Muted
- Text unter Icons: 12pt

**Screens:**
- Jeder Screen hat einen großen Titel oben
- Einfache, flache Hierarchie
- Keine verschachtelten Navigationen

---

## Animationen (Minimal)

- **Button Press:** Scale 0.97, Duration 80ms
- **Screen Transition:** Fade, Duration 200ms
- **Card Flip:** Keine (zu ablenkend)
- **Respekt für `prefers-reduced-motion`:** Keine Animationen, wenn aktiviert

---

## Dunkler Modus

- **Automatische Unterstützung:** App folgt Systemeinstellung
- **Kontraste:** Auch im dunklen Modus WCAG AA/AAA
- **Farben:** Automatisch über CSS-Variablen (keine `dark:` Klassen nötig)

---

## Zusammenfassung

Die App ist **bewusst minimalistisch** gestaltet:
- Große, lesbare Typografie
- Hohe Kontraste für Sehschwäche
- Einfache, flache Navigation
- Große Touch-Flächen
- Minimale Ablenkung
- Fokus auf Lerninhalt, nicht auf Design-Spielereien
