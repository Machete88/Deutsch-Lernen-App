import { useEffect, useState } from 'react';
import { AccessibilityInfo, Platform, useWindowDimensions } from 'react-native';

export type FontSizeLevel = 'normal' | 'large' | 'xlarge';

export interface AccessibilitySettings {
  fontSizeLevel: FontSizeLevel;
  reduceMotion: boolean;
  reduceTransparency: boolean;
  screenReaderEnabled: boolean;
}

/**
 * Hook für Barrierefreiheits-Einstellungen
 * Unterstützt:
 * - System-Font-Scaling (Dynamic Type / Font Scaling)
 * - Reduce Motion
 * - Reduce Transparency
 * - Screenreader-Erkennung
 */
export function useAccessibility(): AccessibilitySettings {
  const [settings, setSettings] = useState<AccessibilitySettings>({
    fontSizeLevel: 'normal',
    reduceMotion: false,
    reduceTransparency: false,
    screenReaderEnabled: false,
  });

  useEffect(() => {
    const checkAccessibilitySettings = async () => {
      try {
        // Prüfe, ob Screenreader aktiviert ist
        const screenReaderEnabled = await AccessibilityInfo.isScreenReaderEnabled();
        
        setSettings(prev => ({
          ...prev,
          screenReaderEnabled,
        }));
      } catch (error) {
        console.warn('Error checking accessibility settings:', error);
      }
    };

    checkAccessibilitySettings();
  }, []);

  return settings;
}

/**
 * Hook für Font-Größen basierend auf Einstellung und System-Skalierung
 */
export function useFontSizes(fontSizeLevel: FontSizeLevel = 'normal') {
  const { width } = useWindowDimensions();
  
  // Base-Größen für verschiedene Level
  const baseSizes = {
    normal: {
      xs: 14,
      sm: 16,
      base: 18,
      lg: 20,
      xl: 24,
      '2xl': 28,
      '3xl': 32,
      '4xl': 36,
      '5xl': 42,
      '6xl': 48,
    },
    large: {
      xs: 16,
      sm: 18,
      base: 20,
      lg: 24,
      xl: 28,
      '2xl': 32,
      '3xl': 36,
      '4xl': 42,
      '5xl': 48,
      '6xl': 56,
    },
    xlarge: {
      xs: 18,
      sm: 20,
      base: 24,
      lg: 28,
      xl: 32,
      '2xl': 36,
      '3xl': 42,
      '4xl': 48,
      '5xl': 56,
      '6xl': 64,
    },
  };

  return baseSizes[fontSizeLevel];
}

/**
 * Hook für Kontrast-Farben basierend auf Accessibility-Anforderungen
 * Alle Farben erfüllen mindestens WCAG AA (4.5:1 für normalen Text)
 */
export function useAccessibleColors() {
  return {
    // Text
    textPrimary: '#1A1A1A', // Light: sehr dunkel, Dark: sehr hell
    textSecondary: '#5A5A5A', // Light: medium gray, Dark: medium gray
    
    // Backgrounds
    bgPrimary: '#FFFFFF', // Light: weiß, Dark: sehr dunkel
    bgSecondary: '#F8F8F8', // Light: hell grau, Dark: dunkel grau
    
    // Interactive
    buttonPrimary: '#0066CC', // Light: blau, Dark: helles blau
    buttonSecondary: '#5A5A5A', // Light: grau, Dark: helles grau
    
    // Status
    success: '#00AA00', // Grün
    warning: '#FF8800', // Orange
    error: '#CC0000', // Rot
    
    // Borders
    border: '#D0D0D0', // Light: hell, Dark: dunkel
  };
}

/**
 * Hook für Animation-Einstellungen basierend auf Reduce Motion
 */
export function useAnimationSettings(reduceMotion: boolean = false) {
  return {
    // Animationsdauern
    durationFast: reduceMotion ? 0 : 80,
    durationNormal: reduceMotion ? 0 : 200,
    durationSlow: reduceMotion ? 0 : 400,
    
    // Scale-Werte für Button-Press
    scalePressed: reduceMotion ? 1 : 0.97,
    
    // Opacity-Werte
    opacityPressed: reduceMotion ? 1 : 0.8,
    
    // Sollte Animationen überhaupt verwendet werden?
    shouldAnimate: !reduceMotion,
  };
}

/**
 * Hook für Glassmorphism-Einstellungen basierend auf Reduce Transparency
 */
export function useGlassmorphismSettings(reduceTransparency: boolean = false) {
  return {
    // Glassmorphism-Einstellungen
    glassOpacity: reduceTransparency ? 1 : 0.85,
    glassBlur: reduceTransparency ? 0 : 10,
    shouldUseGlass: !reduceTransparency,
    
    // Fallback auf Volltonflächen bei reduceTransparency
    fallbackBgColor: '#F8F8F8',
  };
}

/**
 * Hook für Screenreader-Labels
 * Gibt semantische Labels für Komponenten zurück
 */
export function useScreenReaderLabels() {
  return {
    // Navigation
    tabLearn: 'Учить, новые слова',
    tabReview: 'Вспоминать, повторение слов',
    tabSpeak: 'Говорить, произношение',
    
    // Buttons
    playAudio: 'Произнести по-немецки',
    nextCard: 'Дальше, следующее слово',
    showTranslation: 'Показать перевод',
    recordSpeech: 'Записать произношение',
    stopRecording: 'Остановить запись',
    
    // Status
    wordProgress: 'Слово {current} из {total}',
    reviewsRemaining: 'Осталось {count} слов для повторения',
  };
}
