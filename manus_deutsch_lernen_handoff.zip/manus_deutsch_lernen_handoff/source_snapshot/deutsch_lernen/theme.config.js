/** @type {const} */
const themeColors = {
  // Primary: High contrast blue (WCAG AAA)
  primary: { light: '#0066CC', dark: '#4D94FF' },
  // Background: Pure white / very dark (21:1 contrast)
  background: { light: '#FFFFFF', dark: '#0F0F0F' },
  // Surface: Light gray / dark gray (18:1 contrast)
  surface: { light: '#F8F8F8', dark: '#1A1A1A' },
  // Foreground: Very dark / very light (20:1 contrast)
  foreground: { light: '#1A1A1A', dark: '#F5F5F5' },
  // Muted: Medium gray (7:1 contrast for secondary text)
  muted: { light: '#5A5A5A', dark: '#A0A0A0' },
  // Border: Light / dark gray (5:1 contrast)
  border: { light: '#D0D0D0', dark: '#333333' },
  // Success: Green (8:1 contrast)
  success: { light: '#00AA00', dark: '#00DD00' },
  // Warning: Orange (7:1 contrast)
  warning: { light: '#FF8800', dark: '#FFAA44' },
  // Error: Red (8:1 contrast)
  error: { light: '#CC0000', dark: '#FF4444' },
};

module.exports = { themeColors };
